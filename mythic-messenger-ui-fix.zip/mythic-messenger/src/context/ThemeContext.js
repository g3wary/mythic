import React, { createContext, useContext, useState, useMemo } from 'react';
import { themes } from '../theme';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [mode, setMode] = useState('gray'); // 'gray' | 'white'

  const value = useMemo(
    () => ({
      mode,
      colors: themes[mode],
      toggleTheme: () => setMode((m) => (m === 'gray' ? 'white' : 'gray')),
      setTheme: (m) => setMode(m),
    }),
    [mode]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useAppTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useAppTheme must be used within ThemeProvider');
  return ctx;
}
