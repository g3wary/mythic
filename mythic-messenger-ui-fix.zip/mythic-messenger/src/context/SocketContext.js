import React, { createContext, useContext, useEffect, useRef, useCallback } from 'react';
import { WS_BASE_URL } from '../api';

const SocketContext = createContext(null);

export function SocketProvider({ token, children }) {
  const wsRef = useRef(null);
  const listenersRef = useRef(new Set());
  const reconnectTimer = useRef(null);

  useEffect(() => {
    if (!token) return;
    let cancelled = false;

    function connect() {
      if (cancelled) return;
      const ws = new WebSocket(`${WS_BASE_URL}/ws?token=${encodeURIComponent(token)}`);
      wsRef.current = ws;

      ws.onmessage = (event) => {
        let data;
        try {
          data = JSON.parse(event.data);
        } catch {
          return;
        }
        listenersRef.current.forEach((cb) => cb(data));
      };

      ws.onclose = () => {
        if (cancelled) return;
        // простая переподключалка через 2 секунды
        reconnectTimer.current = setTimeout(connect, 2000);
      };

      ws.onerror = () => {
        ws.close();
      };
    }

    connect();

    return () => {
      cancelled = true;
      clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
    };
  }, [token]);

  const subscribe = useCallback((cb) => {
    listenersRef.current.add(cb);
    return () => listenersRef.current.delete(cb);
  }, []);

  const sendDM = useCallback((toLogin, content, msgType = 'text') => {
    const ws = wsRef.current;
    if (!ws || ws.readyState !== 1) return false;
    ws.send(JSON.stringify({ type: 'dm', toLogin, content, msgType }));
    return true;
  }, []);

  const sendCommunityMessage = useCallback((communityId, content, msgType = 'text') => {
    const ws = wsRef.current;
    if (!ws || ws.readyState !== 1) return false;
    ws.send(JSON.stringify({ type: 'community', communityId, content, msgType }));
    return true;
  }, []);

  return (
    <SocketContext.Provider value={{ subscribe, sendDM, sendCommunityMessage }}>{children}</SocketContext.Provider>
  );
}

export function useSocket() {
  const ctx = useContext(SocketContext);
  if (!ctx) throw new Error('useSocket must be used within SocketProvider');
  return ctx;
}
