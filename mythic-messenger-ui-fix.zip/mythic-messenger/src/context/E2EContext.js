import React, { createContext, useContext, useEffect, useState } from 'react';
import { loadOrCreateKeyPair } from '../utils/e2e';
import { api } from '../api';

const E2EContext = createContext(null);

export function E2EProvider({ token, login, publicKeyOnServer, children }) {
  const [keyPair, setKeyPair] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setReady(false);
    loadOrCreateKeyPair(login).then((kp) => {
      if (cancelled) return;
      setKeyPair(kp);
      setReady(true);
      // Если на сервере ключа ещё нет или он отличается от локального — обновляем
      if (kp.publicKeyB64 !== publicKeyOnServer) {
        api.setPublicKey(token, kp.publicKeyB64).catch(() => {});
      }
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [login, token]);

  return <E2EContext.Provider value={{ keyPair, ready }}>{children}</E2EContext.Provider>;
}

export function useE2E() {
  const ctx = useContext(E2EContext);
  if (!ctx) throw new Error('useE2E must be used within E2EProvider');
  return ctx;
}
