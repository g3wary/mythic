import nacl from 'tweetnacl';
import { decodeUTF8, encodeUTF8, encodeBase64, decodeBase64 } from 'tweetnacl-util';
import * as SecureStore from 'expo-secure-store';

function storageKey(login) {
  // Ключ привязан к логину — на одном устройстве может быть несколько аккаунтов
  return `mythic_e2e_sk_${login}`;
}

// Загружает существующий приватный ключ с устройства или создаёт новый.
// Приватный ключ никогда не покидает устройство и не отправляется на сервер.
export async function loadOrCreateKeyPair(login) {
  const key = storageKey(login);
  const existing = await SecureStore.getItemAsync(key);

  if (existing) {
    const secretKey = decodeBase64(existing);
    const publicKey = nacl.box.keyPair.fromSecretKey(secretKey).publicKey;
    return { secretKey, publicKey, publicKeyB64: encodeBase64(publicKey) };
  }

  const pair = nacl.box.keyPair();
  await SecureStore.setItemAsync(key, encodeBase64(pair.secretKey));
  return { secretKey: pair.secretKey, publicKey: pair.publicKey, publicKeyB64: encodeBase64(pair.publicKey) };
}

// Общий секрет для конкретной переписки. Симметричен: та же пара (мой secretKey +
// публичный ключ собеседника) расшифровывает и входящие, и мои же отправленные сообщения.
export function sharedKeyFor(mySecretKey, theirPublicKeyB64) {
  const theirPublicKey = decodeBase64(theirPublicKeyB64);
  return nacl.box.before(theirPublicKey, mySecretKey);
}

export function encryptText(sharedKey, text) {
  const nonce = nacl.randomBytes(nacl.box.nonceLength);
  const cipher = nacl.box.after(decodeUTF8(text), nonce, sharedKey);
  return JSON.stringify({ e2e: 1, n: encodeBase64(nonce), c: encodeBase64(cipher) });
}

// Возвращает { text, encrypted, failed }. Если content — обычный текст (старое
// сообщение до включения шифрования или сообщение из группы/канала), возвращает его как есть.
export function decryptText(sharedKey, content) {
  let parsed;
  try {
    parsed = JSON.parse(content);
  } catch {
    return { text: content, encrypted: false };
  }
  if (!parsed || parsed.e2e !== 1 || !parsed.n || !parsed.c) {
    return { text: content, encrypted: false };
  }
  if (!sharedKey) {
    return { text: '🔒 Шифрование ещё не готово…', encrypted: true, pending: true };
  }
  try {
    const nonce = decodeBase64(parsed.n);
    const cipher = decodeBase64(parsed.c);
    const plain = nacl.box.open.after(cipher, nonce, sharedKey);
    if (!plain) return { text: '⚠️ Не удалось расшифровать', encrypted: true, failed: true };
    return { text: encodeUTF8(plain), encrypted: true };
  } catch {
    return { text: '⚠️ Не удалось расшифровать', encrypted: true, failed: true };
  }
}

export function looksEncrypted(content) {
  try {
    const parsed = JSON.parse(content);
    return !!parsed && parsed.e2e === 1;
  } catch {
    return false;
  }
}
