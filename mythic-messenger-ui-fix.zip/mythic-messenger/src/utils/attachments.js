import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { Audio } from 'expo-av';
import { useRef, useState, useCallback } from 'react';

// Несколько фото сразу — для создания стикер-пака (нужно ≥2 картинки)
export async function pickMultipleImages() {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('Нет доступа к галерее');

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    quality: 0.8,
    allowsMultipleSelection: true,
  });
  if (result.canceled || !result.assets?.length) return [];

  return result.assets.map((asset, i) => ({
    uri: asset.uri,
    name: asset.fileName || `sticker_${i}.jpg`,
    mimeType: asset.mimeType || 'image/jpeg',
    kind: 'image',
  }));
}

// Фото/видео из галереи
export async function pickMediaFromLibrary() {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('Нет доступа к галерее');

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.All,
    quality: 0.8,
    videoMaxDuration: 120,
  });
  if (result.canceled || !result.assets?.length) return null;

  const asset = result.assets[0];
  const isVideo = asset.type === 'video';
  return {
    uri: asset.uri,
    name: asset.fileName || (isVideo ? 'video.mp4' : 'photo.jpg'),
    mimeType: asset.mimeType || (isVideo ? 'video/mp4' : 'image/jpeg'),
    kind: isVideo ? 'video' : 'image',
  };
}

// Фото/видео с камеры
export async function pickMediaFromCamera() {
  const perm = await ImagePicker.requestCameraPermissionsAsync();
  if (!perm.granted) throw new Error('Нет доступа к камере');

  const result = await ImagePicker.launchCameraAsync({ quality: 0.8 });
  if (result.canceled || !result.assets?.length) return null;

  const asset = result.assets[0];
  const isVideo = asset.type === 'video';
  return {
    uri: asset.uri,
    name: isVideo ? 'video.mp4' : 'photo.jpg',
    mimeType: isVideo ? 'video/mp4' : 'image/jpeg',
    kind: isVideo ? 'video' : 'image',
  };
}

// Любой файл (документы, музыка и т.д.)
export async function pickDocument() {
  const result = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true });
  if (result.canceled || !result.assets?.length) return null;

  const asset = result.assets[0];
  return {
    uri: asset.uri,
    name: asset.name,
    mimeType: asset.mimeType || 'application/octet-stream',
    kind: asset.mimeType?.startsWith('audio/') ? 'audio' : 'file',
  };
}

// Хук записи голосового сообщения
export function useVoiceRecorder() {
  const recordingRef = useRef(null);
  const [isRecording, setIsRecording] = useState(false);

  const start = useCallback(async () => {
    const perm = await Audio.requestPermissionsAsync();
    if (!perm.granted) throw new Error('Нет доступа к микрофону');

    await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
    const { recording } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
    recordingRef.current = recording;
    setIsRecording(true);
  }, []);

  const stop = useCallback(async () => {
    const recording = recordingRef.current;
    if (!recording) return null;

    await recording.stopAndUnloadAsync();
    const uri = recording.getURI();
    const status = await recording.getStatusAsync();
    recordingRef.current = null;
    setIsRecording(false);

    return { uri, name: 'voice.m4a', mimeType: 'audio/m4a', kind: 'voice', duration: status.durationMillis };
  }, []);

  const cancel = useCallback(async () => {
    const recording = recordingRef.current;
    if (!recording) return;
    await recording.stopAndUnloadAsync().catch(() => {});
    recordingRef.current = null;
    setIsRecording(false);
  }, []);

  return { isRecording, start, stop, cancel };
}
