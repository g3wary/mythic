export const themes = {
  gray: {
    name: 'gray',
    bg: '#18181a',
    surface: '#242426',
    surfaceAlt: '#2f2f32',
    surfaceRaised: '#38383b',
    border: '#3a3a3d',
    borderSoft: '#2c2c2e',
    text: '#f3f3f4',
    textDim: '#9a9a9e',
    textFaint: '#6c6c70',
    accent: '#8d8d93',
    accentStrong: '#c4c4c9',
    accentText: '#ffffff',
    danger: '#d9695f',

    // Пузыри сообщений: свои чуть светлее фона чата, чужие — на тон темнее с рамкой
    bubbleMine: '#3a3a3e',
    bubbleTheirs: '#232325',
    bubbleMineText: '#f5f5f6',
    bubbleTheirsText: '#e9e9ea',

    shadow: 'rgba(0,0,0,0.45)',
    overlay: 'rgba(0,0,0,0.6)',
  },
  white: {
    name: 'white',
    bg: '#f2f2f4',
    surface: '#ffffff',
    surfaceAlt: '#ececef',
    surfaceRaised: '#e2e2e6',
    border: '#dcdce1',
    borderSoft: '#e8e8eb',
    text: '#19191b',
    textDim: '#66666b',
    textFaint: '#98989d',
    accent: '#57575c',
    accentStrong: '#28282b',
    accentText: '#ffffff',
    danger: '#b8443b',

    bubbleMine: '#e4e4e8',
    bubbleTheirs: '#ffffff',
    bubbleMineText: '#1c1c1e',
    bubbleTheirsText: '#1c1c1e',

    shadow: 'rgba(30,30,35,0.14)',
    overlay: 'rgba(20,20,25,0.4)',
  },
};

// Единый масштаб скруглений и теней, чтобы карточки/баблы/кнопки не разъезжались по стилю
export const radii = { sm: 8, md: 12, lg: 16, xl: 22, pill: 999 };

export function cardShadow(colors) {
  return {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 3,
  };
}

export function softShadow(colors) {
  return {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 1,
    shadowRadius: 3,
    elevation: 1,
  };
}
