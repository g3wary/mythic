// Поменяй на адрес своего VPS после деплоя mythic-backend
export const API_BASE_URL = 'http://YOUR_SERVER_IP:4000';
export const WS_BASE_URL = 'ws://YOUR_SERVER_IP:4000';

async function request(path, { method = 'GET', body, token } = {}) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Ошибка запроса (${res.status})`);
  }
  return data;
}

async function uploadFile(token, { uri, name, mimeType }) {
  const form = new FormData();
  form.append('file', { uri, name: name || 'file', type: mimeType || 'application/octet-stream' });

  const res = await fetch(`${API_BASE_URL}/upload`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      // Content-Type НЕ ставим руками — RN сам проставит boundary для multipart/form-data
    },
    body: form,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Ошибка загрузки (${res.status})`);
  return data; // { url, kind, name, size, mimeType }
}

export const api = {
  register: (login, username, password, age) =>
    request('/auth/register', { method: 'POST', body: { login, username, password, age } }),
  login: (login, password) =>
    request('/auth/login', { method: 'POST', body: { login, password } }),
  me: (token) => request('/auth/me', { token }),
  wallet: (token) => request('/wallet/me', { token }),

  searchUsers: (token, q) => request(`/users/search?q=${encodeURIComponent(q)}`, { token }),
  getProfile: (token, login) => request(`/users/${encodeURIComponent(login)}`, { token }),
  blockUser: (token, login) => request(`/users/${encodeURIComponent(login)}/block`, { method: 'POST', token }),
  unblockUser: (token, login) => request(`/users/${encodeURIComponent(login)}/block`, { method: 'DELETE', token }),
  reportUser: (token, targetLogin, reason) =>
    request('/reports', { method: 'POST', body: { targetLogin, reason }, token }),

  getConversations: (token) => request('/messages', { token }),
  getHistory: (token, withLogin) => request(`/messages/${encodeURIComponent(withLogin)}`, { token }),
  sendMessageRest: (token, toLogin, content, type) =>
    request(`/messages/${encodeURIComponent(toLogin)}`, { method: 'POST', body: { content, type }, token }),
  editMessage: (token, id, content) =>
    request(`/messages/${id}`, { method: 'PATCH', body: { content }, token }),
  deleteMessage: (token, id) => request(`/messages/${id}`, { method: 'DELETE', token }),

  createCommunity: (token, type, name, description) =>
    request('/communities', { method: 'POST', body: { type, name, description }, token }),
  getMyCommunities: (token) => request('/communities/mine', { token }),
  searchCommunities: (token, q, type) =>
    request(`/communities/search?q=${encodeURIComponent(q)}${type ? `&type=${type}` : ''}`, { token }),
  getCommunity: (token, id) => request(`/communities/${id}`, { token }),
  joinCommunity: (token, id) => request(`/communities/${id}/join`, { method: 'POST', token }),
  leaveCommunity: (token, id) => request(`/communities/${id}/leave`, { method: 'POST', token }),
  deleteCommunity: (token, id) => request(`/communities/${id}`, { method: 'DELETE', token }),
  updateCommunity: (token, id, patch) => request(`/communities/${id}`, { method: 'PATCH', body: patch, token }),
  addCoOwner: (token, id, login) =>
    request(`/communities/${id}/co-owners`, { method: 'POST', body: { login }, token }),
  removeCoOwner: (token, id, login) =>
    request(`/communities/${id}/co-owners/${encodeURIComponent(login)}`, { method: 'DELETE', token }),
  getCommunityMembers: (token, id) => request(`/communities/${id}/members`, { token }),
  getCommunityMessages: (token, id) => request(`/communities/${id}/messages`, { token }),
  sendCommunityMessageRest: (token, id, content, type) =>
    request(`/communities/${id}/messages`, { method: 'POST', body: { content, type }, token }),
  deleteCommunityMessage: (token, id, msgId) =>
    request(`/communities/${id}/messages/${msgId}`, { method: 'DELETE', token }),

  uploadFile,

  createPost: (token, post) => request('/posts', { method: 'POST', body: post, token }),
  getFeed: (token, { hashtag, author, before } = {}) => {
    const params = new URLSearchParams();
    if (hashtag) params.set('hashtag', hashtag);
    if (author) params.set('author', author);
    if (before) params.set('before', before);
    const qs = params.toString();
    return request(`/posts${qs ? `?${qs}` : ''}`, { token });
  },
  getMyPosts: (token) => request('/posts/mine', { token }),
  setPostHidden: (token, id, hidden) => request(`/posts/${id}`, { method: 'PATCH', body: { hidden }, token }),
  deletePost: (token, id) => request(`/posts/${id}`, { method: 'DELETE', token }),

  updateProfile: (token, patch) => request('/account/profile', { method: 'PATCH', body: patch, token }),
  requestEmail: (token, email) => request('/account/email/request', { method: 'POST', body: { email }, token }),
  confirmEmail: (token, code) => request('/account/email/confirm', { method: 'POST', body: { code }, token }),

  adminConsole: (token, command) => request('/admin/console', { method: 'POST', body: { command }, token }),
  adminLogs: (token) => request('/admin/logs', { token }),
  adminSupportTickets: (token) => request('/admin/support-tickets', { token }),

  setPublicKey: (token, publicKey) => request('/account/public-key', { method: 'POST', body: { publicKey }, token }),

  createBot: (token, bot) => request('/bots', { method: 'POST', body: bot, token }),
  getMyBots: (token) => request('/bots/mine', { token }),
  updateBot: (token, id, patch) => request(`/bots/${id}`, { method: 'PATCH', body: patch, token }),
  regenerateBotToken: (token, id) => request(`/bots/${id}/regenerate-token`, { method: 'POST', token }),
  deleteBot: (token, id) => request(`/bots/${id}`, { method: 'DELETE', token }),

  createStickerPack: (token, pack) => request('/sticker-packs', { method: 'POST', body: pack, token }),
  getMyStickerPacks: (token) => request('/sticker-packs/mine', { token }),
  getStickerCollection: (token) => request('/sticker-packs/collection', { token }),
  discoverStickerPacks: (token, q) => request(`/sticker-packs/discover${q ? `?q=${encodeURIComponent(q)}` : ''}`, { token }),
  getStickerPack: (token, id) => request(`/sticker-packs/${id}`, { token }),
  collectStickerPack: (token, id) => request(`/sticker-packs/${id}/collect`, { method: 'POST', token }),
  uncollectStickerPack: (token, id) => request(`/sticker-packs/${id}/collect`, { method: 'DELETE', token }),
  purchaseStickerPack: (token, id) => request(`/sticker-packs/${id}/purchase`, { method: 'POST', token }),
  updateStickerPack: (token, id, patch) => request(`/sticker-packs/${id}`, { method: 'PATCH', body: patch, token }),
  deleteStickerPack: (token, id) => request(`/sticker-packs/${id}`, { method: 'DELETE', token }),
  deleteSticker: (token, packId, stickerId) => request(`/sticker-packs/${packId}/stickers/${stickerId}`, { method: 'DELETE', token }),

  getProStatus: (token) => request('/pro/status', { token }),
  subscribePro: (token) => request('/pro/subscribe', { method: 'POST', token }),
};

export function resolveMediaUrl(url) {
  if (!url) return url;
  if (url.startsWith('http')) return url;
  return `${API_BASE_URL}${url}`;
}
