import React, { useRef, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  TouchableOpacity,
  Dimensions,
  SafeAreaView,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';

const { width } = Dimensions.get('window');

const SLIDES = [
  {
    title: 'Mythic',
    body:
      'Добро пожаловать. Mythic — мессенджер, который строится вокруг одной идеи: твои разговоры принадлежат только тебе.',
  },
  {
    title: 'Шифрование',
    body:
      'Личные сообщения защищены end-to-end шифрованием. Это значит, что переписку между тобой и собеседником не может прочитать никто третий — даже мы.',
  },
  {
    title: 'Анонимность',
    body:
      'Тебе не нужно указывать реальное имя или номер телефона. Логин и юзернейм — вот всё, что видят другие пользователи.',
  },
  {
    title: 'Твои правила',
    body:
      'Каналы, группы, лента, репутация и собственный кошелёк Mythic — всё под твоим контролем. Добро пожаловать в Mythic.',
  },
];

export default function OnboardingScreen({ onDone }) {
  const { colors } = useAppTheme();
  const [index, setIndex] = useState(0);
  const fade = useRef(new Animated.Value(1)).current;
  const slide = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    fade.setValue(0);
    slide.setValue(16);
    Animated.parallel([
      Animated.timing(fade, { toValue: 1, duration: 420, useNativeDriver: true }),
      Animated.spring(slide, { toValue: 0, useNativeDriver: true, friction: 8 }),
    ]).start();
  }, [index]);

  const next = () => {
    if (index < SLIDES.length - 1) {
      setIndex((i) => i + 1);
    } else {
      onDone();
    }
  };

  const current = SLIDES[index];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.bg }]}>
      <TouchableOpacity style={styles.skipBtn} onPress={onDone}>
        <Text style={[styles.skipText, { color: colors.textDim }]}>Пропустить</Text>
      </TouchableOpacity>

      <View style={styles.center}>
        <Animated.View style={{ opacity: fade, transform: [{ translateY: slide }] }}>
          <Text style={[styles.brand, { color: colors.text }]}>
            {index === 0 ? 'Mythic' : current.title}
          </Text>
          <Text style={[styles.body, { color: colors.textDim }]}>{current.body}</Text>
        </Animated.View>
      </View>

      <View style={styles.dotsRow}>
        {SLIDES.map((_, i) => (
          <View
            key={i}
            style={[
              styles.dot,
              {
                backgroundColor: i === index ? colors.text : colors.border,
                width: i === index ? 20 : 8,
              },
            ]}
          />
        ))}
      </View>

      <TouchableOpacity
        style={[styles.nextBtn, { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}
        onPress={next}
        activeOpacity={0.7}
      >
        <Text style={[styles.nextText, { color: colors.text }]}>
          {index < SLIDES.length - 1 ? 'Далее' : 'Начать'}
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 24, paddingBottom: 32 },
  skipBtn: { alignSelf: 'flex-end', paddingVertical: 16 },
  skipText: { fontSize: 15, fontWeight: '500' },
  center: { flex: 1, justifyContent: 'center' },
  brand: { fontSize: 34, fontWeight: '700', marginBottom: 16, letterSpacing: 0.5 },
  body: { fontSize: 16, lineHeight: 24 },
  dotsRow: { flexDirection: 'row', justifyContent: 'center', marginBottom: 24, gap: 6 },
  dot: { height: 8, borderRadius: 4 },
  nextBtn: {
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
    borderWidth: 1,
    width: width - 48,
    alignSelf: 'center',
  },
  nextText: { fontSize: 16, fontWeight: '600' },
});
