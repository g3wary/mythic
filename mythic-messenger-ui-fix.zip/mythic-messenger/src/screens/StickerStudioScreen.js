import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Modal,
  Alert,
  ActivityIndicator,
  Switch,
  ScrollView,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api } from '../api';
import StickerThumb from '../components/StickerThumb';
import { pickMultipleImages, pickMediaFromLibrary } from '../utils/attachments';

const SEGMENTS = [
  { key: 'mine', label: 'Мои' },
  { key: 'collection', label: 'Коллекция' },
  { key: 'discover', label: 'Найти' },
];

function PackCard({ pack, colors, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.card, { borderColor: colors.border, backgroundColor: colors.surface }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
        <Text style={{ color: colors.text, fontWeight: '700', fontSize: 15, flex: 1 }} numberOfLines={1}>
          {pack.kind === 'single' ? '🏷️ ' : '📦 '}
          {pack.name}
        </Text>
        {pack.isPrivate && <Text style={{ color: colors.textDim, fontSize: 11 }}>🔒</Text>}
      </View>
      <View style={{ flexDirection: 'row', gap: 6 }}>
        {pack.stickers.slice(0, 4).map((s) => (
          <StickerThumb key={s.id} url={s.url} size={54} isAnimated={pack.isAnimated} watermarkUsername={pack.needsWatermark ? pack.owner.username : null} />
        ))}
      </View>
      <Text style={{ color: colors.textDim, fontSize: 12, marginTop: 8 }}>
        @{pack.owner.username} · {pack.stickers.length} шт.
        {pack.isPaid ? ` · ${pack.price} мификов` : ' · бесплатно'}
      </Text>
    </TouchableOpacity>
  );
}

function PackDetail({ pack, token, colors, onBack, onChanged }) {
  const [name, setName] = useState(pack.name);
  const [isPrivate, setIsPrivate] = useState(pack.isPrivate);
  const [isPaid, setIsPaid] = useState(pack.isPaid);
  const [price, setPrice] = useState(String(pack.price || ''));
  const [saving, setSaving] = useState(false);
  const [busy, setBusy] = useState(false);

  const save = () => {
    setSaving(true);
    api
      .updateStickerPack(token, pack.id, { name, isPrivate, isPaid, price: isPaid ? Number(price) : 0 })
      .then(onChanged)
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setSaving(false));
  };

  const removeSticker = (stickerId) => {
    api
      .deleteSticker(token, pack.id, stickerId)
      .then(onChanged)
      .catch((e) => Alert.alert('Ошибка', e.message));
  };

  const removePack = () => {
    Alert.alert('Удалить', `Удалить «${pack.name}» безвозвратно?`, [
      { text: 'Отмена', style: 'cancel' },
      {
        text: 'Удалить',
        style: 'destructive',
        onPress: () => api.deleteStickerPack(token, pack.id).then(onBack).catch((e) => Alert.alert('Ошибка', e.message)),
      },
    ]);
  };

  const collect = () => {
    setBusy(true);
    api.collectStickerPack(token, pack.id).then(onChanged).catch((e) => Alert.alert('Ошибка', e.message)).finally(() => setBusy(false));
  };

  const uncollect = () => {
    setBusy(true);
    api.uncollectStickerPack(token, pack.id).then(onChanged).catch((e) => Alert.alert('Ошибка', e.message)).finally(() => setBusy(false));
  };

  const purchase = () => {
    Alert.alert('Купить', `Купить «${pack.name}» за ${pack.price} мификов?`, [
      { text: 'Отмена', style: 'cancel' },
      {
        text: 'Купить',
        onPress: () => {
          setBusy(true);
          api
            .purchaseStickerPack(token, pack.id)
            .then(onChanged)
            .catch((e) => Alert.alert('Ошибка', e.message))
            .finally(() => setBusy(false));
        },
      },
    ]);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.bg, paddingTop: 50 }} contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
      <TouchableOpacity onPress={onBack} style={{ marginBottom: 16 }}>
        <Text style={{ color: colors.text, fontSize: 20 }}>‹ Назад</Text>
      </TouchableOpacity>

      <Text style={{ color: colors.text, fontSize: 18, fontWeight: '700', marginBottom: 4 }}>{pack.name}</Text>
      <Text style={{ color: colors.textDim, fontSize: 13, marginBottom: 16 }}>
        @{pack.owner.username} · {pack.stickers.length} шт.
      </Text>

      <View style={styles.grid}>
        {pack.stickers.map((s) => (
          <View key={s.id} style={{ position: 'relative' }}>
            <StickerThumb url={s.url} isAnimated={pack.isAnimated} watermarkUsername={pack.needsWatermark ? pack.owner.username : null} />
            {pack.isOwner && (
              <TouchableOpacity
                onPress={() => removeSticker(s.id)}
                style={[styles.removeBadge, { backgroundColor: colors.danger }]}
              >
                <Text style={{ color: '#fff', fontSize: 11 }}>✕</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
      </View>

      {pack.isOwner ? (
        <View style={{ marginTop: 24 }}>
          <Text style={[styles.label, { color: colors.textDim }]}>Название</Text>
          <TextInput
            value={name}
            onChangeText={setName}
            style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
          />

          <View style={styles.switchRow}>
            <Text style={{ color: colors.text }}>Приватный (нельзя добавить чужим)</Text>
            <Switch value={isPrivate} onValueChange={setIsPrivate} />
          </View>
          <View style={styles.switchRow}>
            <Text style={{ color: colors.text }}>Платный</Text>
            <Switch value={isPaid} onValueChange={setIsPaid} />
          </View>
          {isPaid && (
            <TextInput
              value={price}
              onChangeText={setPrice}
              placeholder="Цена в мификах"
              placeholderTextColor={colors.textDim}
              keyboardType="numeric"
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text, marginTop: 8 }]}
            />
          )}

          <TouchableOpacity
            onPress={save}
            disabled={saving}
            style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: saving ? 0.6 : 1 }]}
          >
            <Text style={{ color: colors.text, fontWeight: '600' }}>{saving ? 'Сохраняю…' : 'Сохранить'}</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={removePack} style={[styles.btn, { borderColor: colors.danger, marginTop: 10 }]}>
            <Text style={{ color: colors.danger, fontWeight: '600' }}>Удалить пак</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={{ marginTop: 20 }}>
          {pack.isCollected ? (
            <TouchableOpacity onPress={uncollect} disabled={busy} style={[styles.btn, { borderColor: colors.border }]}>
              <Text style={{ color: colors.textDim }}>Убрать из коллекции</Text>
            </TouchableOpacity>
          ) : pack.isPaid && !pack.isPurchased ? (
            <TouchableOpacity
              onPress={purchase}
              disabled={busy}
              style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
            >
              <Text style={{ color: colors.text, fontWeight: '600' }}>Купить за {pack.price} мификов</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={collect}
              disabled={busy}
              style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
            >
              <Text style={{ color: colors.text, fontWeight: '600' }}>Добавить в коллекцию</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </ScrollView>
  );
}

export default function StickerStudioScreen({ token, onBack }) {
  const { colors } = useAppTheme();
  const [segment, setSegment] = useState('mine');
  const [packs, setPacks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [selectedPack, setSelectedPack] = useState(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [isPro, setIsPro] = useState(false);

  useEffect(() => {
    api.getProStatus(token).then((s) => setIsPro(s.isPro)).catch(() => {});
  }, [token]);

  const [createKind, setCreateKind] = useState('pack');
  const [createName, setCreateName] = useState('');
  const [createPrivate, setCreatePrivate] = useState(false);
  const [createPaid, setCreatePaid] = useState(false);
  const [createPrice, setCreatePrice] = useState('');
  const [createAnimated, setCreateAnimated] = useState(false);
  const [pickedImages, setPickedImages] = useState([]);
  const [creating, setCreating] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    const req =
      segment === 'mine'
        ? api.getMyStickerPacks(token)
        : segment === 'collection'
        ? api.getStickerCollection(token)
        : api.discoverStickerPacks(token, query);
    req
      .then((data) => setPacks(data.packs || []))
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setLoading(false));
  }, [token, segment, query]);

  useEffect(load, [load]);

  const openPack = (pack) => {
    api
      .getStickerPack(token, pack.id)
      .then(setSelectedPack)
      .catch((e) => Alert.alert('Ошибка', e.message));
  };

  const refreshSelected = () => {
    if (!selectedPack) return;
    api
      .getStickerPack(token, selectedPack.id)
      .then(setSelectedPack)
      .catch(() => setSelectedPack(null));
    load();
  };

  const pickImages = async () => {
    try {
      if (createAnimated) {
        // Анимированный стикер/пак — короткое видео вместо статичной картинки
        const one = await pickMediaFromLibrary();
        if (one && one.kind === 'video') setPickedImages((prev) => (createKind === 'pack' ? [...prev, one] : [one]));
        else if (one) Alert.alert('Нужно видео', 'Для анимированного стикера выбери короткое видео, не фото');
      } else if (createKind === 'single') {
        const one = await pickMediaFromLibrary();
        if (one && one.kind === 'image') setPickedImages([one]);
        else if (one) Alert.alert('Нужно фото', 'Для стикера выбери картинку, не видео');
      } else {
        const many = await pickMultipleImages();
        if (many.length) setPickedImages(many);
      }
    } catch (e) {
      Alert.alert('Ошибка', e.message);
    }
  };

  const create = async () => {
    if (!createName.trim()) {
      Alert.alert('Ошибка', 'Укажи название');
      return;
    }
    if (pickedImages.length === 0) {
      Alert.alert('Ошибка', 'Выбери картинки');
      return;
    }
    if (createKind === 'pack' && pickedImages.length < 2) {
      Alert.alert('Ошибка', 'В стикер-паке должно быть больше 1 стикера');
      return;
    }
    if (createPaid && (!createPrice || Number(createPrice) <= 0)) {
      Alert.alert('Ошибка', 'Укажи цену');
      return;
    }

    setCreating(true);
    try {
      const uploaded = [];
      for (const img of pickedImages) {
        const res = await api.uploadFile(token, img);
        uploaded.push(res.url);
      }
      await api.createStickerPack(token, {
        kind: createKind,
        name: createName.trim(),
        isPrivate: createPrivate,
        isPaid: createPaid,
        price: createPaid ? Number(createPrice) : 0,
        isAnimated: createAnimated,
        imageUrls: uploaded,
      });
      setCreateOpen(false);
      setCreateName('');
      setCreatePrivate(false);
      setCreatePaid(false);
      setCreatePrice('');
      setCreateAnimated(false);
      setPickedImages([]);
      setSegment('mine');
      load();
    } catch (e) {
      Alert.alert('Ошибка', e.message);
    } finally {
      setCreating(false);
    }
  };

  if (selectedPack) {
    return (
      <PackDetail
        pack={selectedPack}
        token={token}
        colors={colors}
        onBack={() => setSelectedPack(null)}
        onChanged={refreshSelected}
      />
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: 50 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, marginBottom: 10 }}>
        <TouchableOpacity onPress={onBack}>
          <Text style={{ color: colors.text, fontSize: 20 }}>‹ Назад</Text>
        </TouchableOpacity>
        <View style={{ flex: 1 }} />
        <TouchableOpacity
          onPress={() => setCreateOpen(true)}
          style={[styles.addBtn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text, fontSize: 18 }}>+</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.segmentRow}>
        {SEGMENTS.map((s) => (
          <TouchableOpacity
            key={s.key}
            onPress={() => setSegment(s.key)}
            style={[styles.segmentBtn, segment === s.key && { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}
          >
            <Text style={{ color: segment === s.key ? colors.text : colors.textDim, fontSize: 13, fontWeight: segment === s.key ? '700' : '400' }}>
              {s.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {segment === 'discover' && (
        <TextInput
          value={query}
          onChangeText={setQuery}
          onSubmitEditing={load}
          placeholder="Поиск по названию"
          placeholderTextColor={colors.textDim}
          style={[styles.input, { marginHorizontal: 20, marginTop: 10, backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
        />
      )}

      {loading ? (
        <ActivityIndicator color={colors.text} style={{ marginTop: 20 }} />
      ) : (
        <FlatList
          contentContainerStyle={{ padding: 20 }}
          data={packs}
          keyExtractor={(p) => String(p.id)}
          ListEmptyComponent={<Text style={{ color: colors.textDim, textAlign: 'center', marginTop: 20 }}>Пусто</Text>}
          renderItem={({ item }) => <PackCard pack={item} colors={colors} onPress={() => openPack(item)} />}
        />
      )}

      <Modal visible={createOpen} animationType="slide" transparent onRequestClose={() => setCreateOpen(false)}>
        <View style={styles.modalOverlay}>
          <ScrollView style={[styles.modalCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Новый стикер / пак</Text>

            <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
              <TouchableOpacity
                onPress={() => { setCreateKind('single'); setPickedImages([]); }}
                style={[styles.kindBtn, { borderColor: colors.border }, createKind === 'single' && { backgroundColor: colors.surfaceAlt }]}
              >
                <Text style={{ color: colors.text }}>Стикер</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => { setCreateKind('pack'); setPickedImages([]); }}
                style={[styles.kindBtn, { borderColor: colors.border }, createKind === 'pack' && { backgroundColor: colors.surfaceAlt }]}
              >
                <Text style={{ color: colors.text }}>Стикер-пак</Text>
              </TouchableOpacity>
            </View>

            <TextInput
              value={createName}
              onChangeText={setCreateName}
              placeholder="Название"
              placeholderTextColor={colors.textDim}
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
            />

            <TouchableOpacity onPress={pickImages} style={[styles.btn, { borderColor: colors.border, marginTop: 10 }]}>
              <Text style={{ color: colors.text }}>
                {pickedImages.length
                  ? `Выбрано: ${pickedImages.length}`
                  : createAnimated
                  ? 'Загрузить видео'
                  : 'Загрузить картинки'}
              </Text>
            </TouchableOpacity>

            <View style={styles.switchRow}>
              <Text style={{ color: colors.text }}>Приватный</Text>
              <Switch value={createPrivate} onValueChange={setCreatePrivate} />
            </View>
            <View style={styles.switchRow}>
              <Text style={{ color: colors.text }}>Платный</Text>
              <Switch value={createPaid} onValueChange={setCreatePaid} />
            </View>
            <View style={styles.switchRow}>
              <Text style={{ color: isPro ? colors.text : colors.textDim }}>
                Анимированный {!isPro && '(нужен Mythic Pro)'}
              </Text>
              <Switch
                value={createAnimated}
                onValueChange={(v) => {
                  setCreateAnimated(v);
                  setPickedImages([]);
                }}
                disabled={!isPro}
              />
            </View>
            {createPaid && (
              <TextInput
                value={createPrice}
                onChangeText={setCreatePrice}
                placeholder="Цена в мификах"
                placeholderTextColor={colors.textDim}
                keyboardType="numeric"
                style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
              />
            )}

            <View style={{ flexDirection: 'row', marginTop: 16, marginBottom: 20, gap: 10 }}>
              <TouchableOpacity onPress={() => setCreateOpen(false)} style={[styles.btn, { flex: 1, borderColor: colors.border }]}>
                <Text style={{ color: colors.textDim }}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={create}
                disabled={creating}
                style={[styles.btn, { flex: 1, borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: creating ? 0.6 : 1 }]}
              >
                <Text style={{ color: colors.text, fontWeight: '600' }}>{creating ? 'Создаю…' : 'Создать'}</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  addBtn: { width: 38, height: 38, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  segmentRow: { flexDirection: 'row', paddingHorizontal: 20, gap: 8, marginBottom: 4 },
  segmentBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 10, borderWidth: 1, borderColor: 'transparent' },
  card: { borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 14 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  removeBadge: {
    position: 'absolute',
    top: -6,
    right: -6,
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: { fontSize: 12, marginBottom: 6 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
  switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12 },
  btn: { marginTop: 14, borderWidth: 1, borderRadius: 12, paddingVertical: 12, alignItems: 'center' },
  kindBtn: { flex: 1, borderWidth: 1, borderRadius: 10, paddingVertical: 10, alignItems: 'center' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', paddingHorizontal: 24 },
  modalCard: { borderWidth: 1, borderRadius: 16, padding: 20, maxHeight: '85%' },
  modalTitle: { fontSize: 17, fontWeight: '700', marginBottom: 14 },
});
