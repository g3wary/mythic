import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import ChatsListScreen from './ChatsListScreen';
import ChatScreen from './ChatScreen';
import ProfileScreen from './ProfileScreen';
import CommunitiesListScreen from './CommunitiesListScreen';
import CommunityScreen from './CommunityScreen';
import CommunitySettingsScreen from './CommunitySettingsScreen';
import FeedScreen from './FeedScreen';
import SettingsScreen from './SettingsScreen';
import AdminScreen from './AdminScreen';
import ScreenTransition from '../components/ScreenTransition';

const BASE_TABS = [
  { key: 'chats', label: 'Чаты' },
  { key: 'feed', label: 'Лента' },
  { key: 'support', label: 'Поддержка' },
  { key: 'reputation', label: 'Репутация' },
  { key: 'wallet', label: 'Кошелёк' },
  { key: 'settings', label: 'Настройки' },
];

const CHAT_SEGMENTS = [
  { key: 'personal', label: 'Личные' },
  { key: 'group', label: 'Группы' },
  { key: 'channel', label: 'Каналы' },
];

export default function HomeShell({ user, token, onUserUpdate }) {
  const { colors } = useAppTheme();
  const TABS = user.isAdmin ? [...BASE_TABS, { key: 'admin', label: 'Админка' }] : BASE_TABS;
  const [tab, setTab] = useState('chats');
  const [chatSegment, setChatSegment] = useState('personal');
  // Простая локальная навигация внутри вкладки "Чаты" — без react-navigation
  const [chatNav, setChatNav] = useState({ view: 'list' });

  const resetChats = () => {
    setChatSegment('personal');
    setChatNav({ view: 'list' });
  };

  const renderChatsTab = () => {
    if (chatNav.view === 'chat') {
      return (
        <ScreenTransition key={`chat-${chatNav.login}`}>
          <ChatScreen
            token={token}
            myId={user.id}
            myLogin={user.login}
            otherLogin={chatNav.login}
            onBack={() => setChatNav({ view: 'list' })}
            onOpenProfile={(login) => setChatNav({ view: 'profile', login, from: 'chat' })}
          />
        </ScreenTransition>
      );
    }
    if (chatNav.view === 'profile') {
      return (
        <ScreenTransition key={`profile-${chatNav.login}`}>
          <ProfileScreen
            token={token}
            login={chatNav.login}
            onBack={() =>
              setChatNav(
                chatNav.from === 'chat' ? { view: 'chat', login: chatNav.login } : { view: 'list' }
              )
            }
          />
        </ScreenTransition>
      );
    }
    if (chatNav.view === 'community') {
      return (
        <ScreenTransition key={`community-${chatNav.community.id}`}>
          <CommunityScreen
            token={token}
            myLogin={user.login}
            community={chatNav.community}
            onBack={() => setChatNav({ view: 'list' })}
            onOpenSettings={(community) => setChatNav({ view: 'community-settings', community })}
          />
        </ScreenTransition>
      );
    }
    if (chatNav.view === 'community-settings') {
      return (
        <ScreenTransition key={`community-settings-${chatNav.community.id}`}>
          <CommunitySettingsScreen
            token={token}
            community={chatNav.community}
            onBack={() => setChatNav({ view: 'community', community: chatNav.community })}
            onDeleted={() => setChatNav({ view: 'list' })}
          />
        </ScreenTransition>
      );
    }

    // view === 'list'
    if (chatSegment === 'personal') {
      return (
        <ChatsListScreen
          token={token}
          myLogin={user.login}
          onOpenChat={(login) => setChatNav({ view: 'chat', login })}
        />
      );
    }
    return (
      <CommunitiesListScreen
        token={token}
        type={chatSegment}
        onOpen={(community) => setChatNav({ view: 'community', community })}
      />
    );
  };

  const showTabBar = !(tab === 'chats' && chatNav.view !== 'list');
  const showSegments = tab === 'chats' && chatNav.view === 'list';

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.bg }]}>
      {tab === 'chats' ? (
        <View style={{ flex: 1 }}>
          {showSegments && (
            <View style={[styles.segmentRow, { borderBottomColor: colors.border }]}>
              {CHAT_SEGMENTS.map((s) => (
                <TouchableOpacity
                  key={s.key}
                  style={[
                    styles.segmentBtn,
                    chatSegment === s.key && { backgroundColor: colors.surfaceAlt, borderColor: colors.border },
                  ]}
                  onPress={() => setChatSegment(s.key)}
                >
                  <Text
                    style={{
                      color: chatSegment === s.key ? colors.text : colors.textDim,
                      fontSize: 13,
                      fontWeight: chatSegment === s.key ? '700' : '400',
                    }}
                  >
                    {s.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
          {renderChatsTab()}
        </View>
      ) : tab === 'feed' ? (
        <FeedScreen token={token} myLogin={user.login} />
      ) : tab === 'settings' ? (
        <SettingsScreen token={token} user={user} onUserUpdate={onUserUpdate} />
      ) : tab === 'admin' ? (
        <AdminScreen token={token} />
      ) : (
        <View style={styles.content}>
          <Text style={[styles.title, { color: colors.text }]}>
            {TABS.find((t) => t.key === tab)?.label}
          </Text>
          <Text style={[styles.subtitle, { color: colors.textDim }]}>
            Раздел «{TABS.find((t) => t.key === tab)?.label}» — следующий этап разработки.
          </Text>
          <Text style={[styles.subtitle, { color: colors.textDim, marginTop: 8 }]}>
            Вошёл как: {user?.username ? '@' + user.username : user?.login}
          </Text>
          {tab === 'wallet' && (
            <Text style={[styles.subtitle, { color: colors.textDim, marginTop: 8 }]}>
              {user?.walletId} · баланс: {user?.walletBalance ?? 0} мификов
            </Text>
          )}
          {tab === 'reputation' && (
            <Text style={[styles.subtitle, { color: colors.textDim, marginTop: 8 }]}>
              Репутация: {user?.reputation ?? 100}%
            </Text>
          )}
        </View>
      )}

      {showTabBar && (
        <View style={[styles.tabBar, { backgroundColor: colors.surface, borderTopColor: colors.border }]}>
          {TABS.map((t) => (
            <TouchableOpacity
              key={t.key}
              style={styles.tabItem}
              onPress={() => {
                setTab(t.key);
                if (t.key === 'chats') resetChats();
              }}
            >
              <Text
                style={{
                  color: tab === t.key ? colors.text : colors.textDim,
                  fontSize: 11,
                  fontWeight: tab === t.key ? '700' : '400',
                }}
              >
                {t.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 },
  title: { fontSize: 24, fontWeight: '700', marginBottom: 8 },
  subtitle: { fontSize: 14, textAlign: 'center' },
  themeBtn: { marginTop: 24, borderWidth: 1, borderRadius: 12, paddingVertical: 12, paddingHorizontal: 18 },
  tabBar: { flexDirection: 'row', borderTopWidth: 1, paddingVertical: 10 },
  tabItem: { flex: 1, alignItems: 'center' },
  segmentRow: { flexDirection: 'row', paddingHorizontal: 12, paddingTop: 8, paddingBottom: 4, gap: 8, borderBottomWidth: 1 },
  segmentBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 10, borderWidth: 1, borderColor: 'transparent' },
});
