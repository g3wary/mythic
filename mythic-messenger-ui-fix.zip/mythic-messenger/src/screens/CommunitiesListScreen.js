import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Modal,
  Alert,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { useSocket } from '../context/SocketContext';
import { api } from '../api';

const LABELS = {
  group: { singular: 'группа', create: 'Создать группу', empty: 'Пока нет групп' },
  channel: { singular: 'канал', create: 'Создать канал', empty: 'Пока нет каналов' },
};

export default function CommunitiesListScreen({ token, type, onOpen }) {
  const { colors } = useAppTheme();
  const { subscribe } = useSocket();
  const [mine, setMine] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [creating, setCreating] = useState(false);

  const labels = LABELS[type];

  const load = useCallback(() => {
    setLoading(true);
    api
      .getMyCommunities(token)
      .then((data) => setMine((data.communities || []).filter((c) => c.type === type)))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token, type]);

  useEffect(load, [load]);

  useEffect(() => {
    const unsub = subscribe((data) => {
      if (data.type === 'community') load();
    });
    return unsub;
  }, [subscribe, load]);

  useEffect(() => {
    const q = query.trim();
    if (!q) {
      setSearchResults([]);
      return;
    }
    setSearching(true);
    const timeout = setTimeout(() => {
      api
        .searchCommunities(token, q, type)
        .then((data) => setSearchResults(data.communities || []))
        .catch(() => setSearchResults([]))
        .finally(() => setSearching(false));
    }, 300);
    return () => clearTimeout(timeout);
  }, [query, token, type]);

  const join = (community) => {
    api
      .joinCommunity(token, community.id)
      .then(() => {
        load();
        onOpen(community);
      })
      .catch((e) => Alert.alert('Ошибка', e.message));
  };

  const create = () => {
    if (!name.trim()) {
      Alert.alert('Ошибка', 'Укажи название');
      return;
    }
    setCreating(true);
    api
      .createCommunity(token, type, name.trim(), description.trim())
      .then((community) => {
        setCreateOpen(false);
        setName('');
        setDescription('');
        load();
        onOpen(community);
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setCreating(false));
  };

  const showingSearch = query.trim().length > 0;

  const renderRow = (item, joined) => (
    <TouchableOpacity
      key={item.id}
      style={[styles.row, { borderBottomColor: colors.border }]}
      onPress={() => (joined ? onOpen(item) : join(item))}
    >
      <View style={[styles.avatar, { backgroundColor: colors.surfaceAlt }]} />
      <View style={{ flex: 1 }}>
        <Text style={[styles.rowTitle, { color: colors.text }]}>{item.name}</Text>
        <Text style={[styles.rowSub, { color: colors.textDim }]}>
          {item.memberCount} {type === 'channel' ? 'подписчиков' : 'участников'}
          {item.myRole === 'owner' ? ' · вы владелец' : ''}
          {item.myRole === 'co_owner' ? ' · совладелец' : ''}
        </Text>
      </View>
      {!joined && (
        <View style={[styles.joinBadge, { borderColor: colors.border }]}>
          <Text style={{ color: colors.text, fontSize: 12 }}>
            {type === 'channel' ? 'Подписаться' : 'Вступить'}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.topRow}>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder={`Найти ${labels.singular} по названию`}
          placeholderTextColor={colors.textDim}
          style={[
            styles.searchInput,
            { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text },
          ]}
        />
        <TouchableOpacity
          onPress={() => setCreateOpen(true)}
          style={[styles.addBtn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text, fontSize: 18, lineHeight: 20 }}>+</Text>
        </TouchableOpacity>
      </View>

      {showingSearch ? (
        searching ? (
          <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />
        ) : (
          <FlatList
            data={searchResults}
            keyExtractor={(item) => String(item.id)}
            ListEmptyComponent={
              <Text style={[styles.empty, { color: colors.textDim }]}>Ничего не нашлось</Text>
            }
            renderItem={({ item }) => renderRow(item, !!item.myRole)}
          />
        )
      ) : loading ? (
        <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />
      ) : (
        <FlatList
          data={mine}
          keyExtractor={(item) => String(item.id)}
          ListEmptyComponent={
            <Text style={[styles.empty, { color: colors.textDim }]}>
              {labels.empty}. Найди через поиск или создай новую(ый) кнопкой «+».
            </Text>
          }
          renderItem={({ item }) => renderRow(item, true)}
        />
      )}

      <Modal visible={createOpen} animationType="slide" transparent onRequestClose={() => setCreateOpen(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{labels.create}</Text>
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder="Название"
              placeholderTextColor={colors.textDim}
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
            />
            <TextInput
              value={description}
              onChangeText={setDescription}
              placeholder="Описание (необязательно)"
              placeholderTextColor={colors.textDim}
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text, marginTop: 10 }]}
              multiline
            />
            <View style={{ flexDirection: 'row', marginTop: 16, gap: 10 }}>
              <TouchableOpacity
                onPress={() => setCreateOpen(false)}
                style={[styles.modalBtn, { borderColor: colors.border }]}
              >
                <Text style={{ color: colors.textDim }}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={create}
                disabled={creating}
                style={[styles.modalBtn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: creating ? 0.6 : 1 }]}
              >
                <Text style={{ color: colors.text, fontWeight: '600' }}>{creating ? 'Создаю…' : 'Создать'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  topRow: { flexDirection: 'row', paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8, gap: 8 },
  searchInput: { flex: 1, borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, fontSize: 15 },
  addBtn: { width: 42, height: 42, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1 },
  avatar: { width: 44, height: 44, borderRadius: 12, marginRight: 12 },
  rowTitle: { fontSize: 15, fontWeight: '600' },
  rowSub: { fontSize: 12, marginTop: 2 },
  joinBadge: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 },
  empty: { textAlign: 'center', marginTop: 30, fontSize: 14, paddingHorizontal: 24 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', paddingHorizontal: 24 },
  modalCard: { borderWidth: 1, borderRadius: 16, padding: 20 },
  modalTitle: { fontSize: 17, fontWeight: '700', marginBottom: 14 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15 },
  modalBtn: { flex: 1, borderWidth: 1, borderRadius: 12, paddingVertical: 12, alignItems: 'center' },
});
