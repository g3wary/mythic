import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { useSocket } from '../context/SocketContext';
import { api } from '../api';
import MessageContent from '../components/MessageContent';
import { pickMediaFromLibrary, pickMediaFromCamera, pickDocument, useVoiceRecorder } from '../utils/attachments';

export default function CommunityScreen({ token, myLogin, community, onBack, onOpenSettings }) {
  const { colors } = useAppTheme();
  const { subscribe, sendCommunityMessage } = useSocket();
  const [info, setInfo] = useState(community);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [uploading, setUploading] = useState(false);
  const listRef = useRef(null);
  const voice = useVoiceRecorder();

  const canPost =
    info.myRole === 'owner' ||
    (info.type === 'channel' && info.myRole === 'co_owner') ||
    (info.type === 'group' && info.myRole === 'member' && info.writeEnabled);

  useEffect(() => {
    api.getCommunity(token, community.id).then(setInfo).catch(() => {});
  }, [token, community.id]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .getCommunityMessages(token, community.id)
      .then((data) => {
        if (cancelled) return;
        setMessages(
          (data.messages || []).map((m) => ({
            id: m.id,
            mine: m.from_login === myLogin,
            fromLogin: m.from_login,
            fromUsername: m.from_username,
            content: m.content,
            msgType: m.type,
            createdAt: m.created_at,
          }))
        );
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [token, community.id, myLogin]);

  useEffect(() => {
    const unsub = subscribe((data) => {
      if (data.type === 'error') {
        Alert.alert('Ошибка', data.error);
        return;
      }
      if (data.type !== 'community' || data.communityId !== community.id) return;

      setMessages((prev) => {
        if (data.fromLogin === myLogin) {
          const pendingIdx = [...prev].reverse().findIndex((m) => m.pending && m.content === data.content);
          if (pendingIdx !== -1) {
            const realIdx = prev.length - 1 - pendingIdx;
            const copy = [...prev];
            copy[realIdx] = {
              id: data.id,
              mine: true,
              fromLogin: data.fromLogin,
              fromUsername: data.fromUsername,
              content: data.content,
              msgType: data.msgType,
              createdAt: data.createdAt,
            };
            return copy;
          }
        }
        return [
          ...prev,
          {
            id: data.id,
            mine: data.fromLogin === myLogin,
            fromLogin: data.fromLogin,
            fromUsername: data.fromUsername,
            content: data.content,
            msgType: data.msgType,
            createdAt: data.createdAt,
          },
        ];
      });
    });
    return unsub;
  }, [subscribe, community.id, myLogin]);

  const sendMessage = useCallback(
    (content, msgType) => {
      const delivered = sendCommunityMessage(community.id, content, msgType);
      if (delivered) {
        setMessages((prev) => [
          ...prev,
          { id: `pending-${Date.now()}`, mine: true, content, msgType, createdAt: new Date().toISOString(), pending: true },
        ]);
      } else {
        api
          .sendCommunityMessageRest(token, community.id, content, msgType)
          .then((data) => {
            setMessages((prev) => [
              ...prev,
              {
                id: data.message.id,
                mine: true,
                fromLogin: data.message.from_login,
                content: data.message.content,
                msgType: data.message.type,
                createdAt: data.message.created_at,
              },
            ]);
          })
          .catch((e) => Alert.alert('Ошибка отправки', e.message));
      }
    },
    [community.id, sendCommunityMessage, token]
  );

  const send = useCallback(() => {
    const content = text.trim();
    if (!content) return;
    setText('');
    sendMessage(content, 'text');
  }, [text, sendMessage]);

  const uploadAndSend = useCallback(
    async (picked) => {
      if (!picked) return;
      setUploading(true);
      try {
        const uploaded = await api.uploadFile(token, picked);
        const content = JSON.stringify({
          url: uploaded.url,
          name: uploaded.name,
          size: uploaded.size,
          mimeType: uploaded.mimeType,
          duration: picked.duration,
        });
        sendMessage(content, picked.kind);
      } catch (e) {
        Alert.alert('Не удалось загрузить', e.message);
      } finally {
        setUploading(false);
      }
    },
    [token, sendMessage]
  );

  const openAttachMenu = () => {
    Alert.alert('Вложение', undefined, [
      { text: 'Фото / видео из галереи', onPress: () => pickMediaFromLibrary().then(uploadAndSend).catch((e) => Alert.alert('Ошибка', e.message)) },
      { text: 'Камера', onPress: () => pickMediaFromCamera().then(uploadAndSend).catch((e) => Alert.alert('Ошибка', e.message)) },
      { text: 'Файл', onPress: () => pickDocument().then(uploadAndSend).catch((e) => Alert.alert('Ошибка', e.message)) },
      { text: 'Отмена', style: 'cancel' },
    ]);
  };

  const toggleVoice = async () => {
    try {
      if (voice.isRecording) {
        const rec = await voice.stop();
        if (rec) await uploadAndSend(rec);
      } else {
        await voice.start();
      }
    } catch (e) {
      Alert.alert('Ошибка', e.message);
    }
  };

  const onLongPressMessage = (msg) => {
    const canDelete = msg.mine || info.myRole === 'owner';
    if (!canDelete || msg.pending) return;
    Alert.alert('Сообщение', undefined, [
      {
        text: 'Удалить',
        style: 'destructive',
        onPress: () =>
          api
            .deleteCommunityMessage(token, community.id, msg.id)
            .then(() => setMessages((prev) => prev.filter((m) => m.id !== msg.id)))
            .catch((e) => Alert.alert('Ошибка', e.message)),
      },
      { text: 'Отмена', style: 'cancel' },
    ]);
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={onBack} style={{ paddingRight: 12 }}>
          <Text style={{ color: colors.text, fontSize: 20 }}>‹</Text>
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>{info.name}</Text>
          <Text style={{ color: colors.textDim, fontSize: 12 }}>
            {info.memberCount} {info.type === 'channel' ? 'подписчиков' : 'участников'}
          </Text>
        </View>
        {info.myRole === 'owner' ? (
          <TouchableOpacity onPress={() => onOpenSettings(info)} style={{ paddingLeft: 12 }}>
            <Text style={{ color: colors.text, fontSize: 18 }}>⚙︎</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            onPress={() => {
              Alert.alert(
                info.type === 'channel' ? 'Отписаться' : 'Покинуть группу',
                info.type === 'channel' ? 'Отписаться от канала?' : 'Выйти из группы?',
                [
                  { text: 'Отмена', style: 'cancel' },
                  {
                    text: 'Да',
                    style: 'destructive',
                    onPress: () => api.leaveCommunity(token, community.id).then(onBack).catch((e) => Alert.alert('Ошибка', e.message)),
                  },
                ]
              );
            }}
            style={{ paddingLeft: 12 }}
          >
            <Text style={{ color: colors.danger, fontSize: 13 }}>
              {info.type === 'channel' ? 'Отписаться' : 'Выйти'}
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {loading ? (
        <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />
      ) : (
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ padding: 12 }}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          renderItem={({ item }) => (
            <TouchableOpacity
              activeOpacity={0.8}
              onLongPress={() => onLongPressMessage(item)}
              style={[
                styles.bubble,
                item.mine
                  ? { backgroundColor: colors.surfaceAlt, alignSelf: 'flex-end' }
                  : { backgroundColor: colors.surface, alignSelf: 'flex-start', borderWidth: 1, borderColor: colors.border },
                item.pending && { opacity: 0.5 },
              ]}
            >
              {!item.mine && (
                <Text style={{ color: colors.textDim, fontSize: 11, marginBottom: 2 }}>
                  {item.fromUsername ? '@' + item.fromUsername : item.fromLogin}
                </Text>
              )}
              <MessageContent msgType={item.msgType} content={item.content} />
            </TouchableOpacity>
          )}
        />
      )}

      {uploading && (
        <View style={{ paddingHorizontal: 16, paddingBottom: 4 }}>
          <Text style={{ color: colors.textDim, fontSize: 12 }}>Загружаю файл…</Text>
        </View>
      )}

      {canPost ? (
        <View style={[styles.inputRow, { borderTopColor: colors.border }]}>
          <TouchableOpacity onPress={openAttachMenu} style={{ paddingHorizontal: 6 }} disabled={uploading}>
            <Text style={{ color: colors.text, fontSize: 20 }}>📎</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={toggleVoice} style={{ paddingHorizontal: 6 }} disabled={uploading}>
            <Text style={{ color: voice.isRecording ? colors.danger : colors.text, fontSize: 18 }}>
              {voice.isRecording ? '⏺' : '🎤'}
            </Text>
          </TouchableOpacity>
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder={voice.isRecording ? 'Идёт запись…' : info.type === 'channel' ? 'Написать пост' : 'Сообщение'}
            placeholderTextColor={colors.textDim}
            editable={!voice.isRecording}
            style={[styles.input, { backgroundColor: colors.surfaceAlt, color: colors.text, borderColor: colors.border }]}
            multiline
          />
          <TouchableOpacity onPress={send} style={[styles.sendBtn, { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}>
            <Text style={{ color: colors.text, fontWeight: '600' }}>➤</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={[styles.inputRow, { borderTopColor: colors.border, justifyContent: 'center' }]}>
          <Text style={{ color: colors.textDim, fontSize: 13 }}>
            {info.type === 'channel'
              ? 'Постить могут только владелец и совладельцы'
              : 'Владелец отключил сообщения для участников'}
          </Text>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1 },
  headerTitle: { fontSize: 16, fontWeight: '600' },
  bubble: { maxWidth: '78%', borderRadius: 14, paddingHorizontal: 12, paddingVertical: 8, marginBottom: 8 },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 8, paddingVertical: 8, borderTopWidth: 1 },
  input: { flex: 1, borderWidth: 1, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15, maxHeight: 120 },
  sendBtn: { marginLeft: 8, borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10 },
});
