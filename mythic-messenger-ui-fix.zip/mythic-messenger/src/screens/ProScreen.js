import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, ActivityIndicator, ScrollView } from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api } from '../api';

const PERKS = [
  'Анимированные стикеры — создавай и загружай их в Sticker Studio',
  'Публикация постов в Ленте от имени своих групп, ботов и каналов',
];

export default function ProScreen({ token, onBack, onChanged }) {
  const { colors } = useAppTheme();
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [subscribing, setSubscribing] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    api
      .getProStatus(token)
      .then(setStatus)
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(load, [load]);

  const subscribe = () => {
    Alert.alert('Mythic Pro', `Оформить подписку за ${status.price} мификов на ${status.durationDays} дней?`, [
      { text: 'Отмена', style: 'cancel' },
      {
        text: 'Оформить',
        onPress: () => {
          setSubscribing(true);
          api
            .subscribePro(token)
            .then((updated) => {
              setStatus(updated);
              onChanged?.();
              Alert.alert('Готово', 'Mythic Pro активирован');
            })
            .catch((e) => Alert.alert('Ошибка', e.message))
            .finally(() => setSubscribing(false));
        },
      },
    ]);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.bg, paddingTop: 50 }} contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
      <TouchableOpacity onPress={onBack} style={{ marginBottom: 20 }}>
        <Text style={{ color: colors.text, fontSize: 20 }}>‹ Назад</Text>
      </TouchableOpacity>

      <Text style={{ color: colors.text, fontSize: 22, fontWeight: '700', marginBottom: 6 }}>Mythic Pro</Text>

      {loading ? (
        <ActivityIndicator color={colors.text} style={{ marginTop: 20 }} />
      ) : (
        <>
          {status.isPro ? (
            <Text style={{ color: colors.textDim, fontSize: 14, marginBottom: 20 }}>
              Активна до {new Date(status.expiresAt).toLocaleDateString('ru-RU')}
            </Text>
          ) : (
            <Text style={{ color: colors.textDim, fontSize: 14, marginBottom: 20 }}>Подписки нет</Text>
          )}

          <View style={[styles.card, { borderColor: colors.border, backgroundColor: colors.surface }]}>
            {PERKS.map((perk) => (
              <View key={perk} style={{ flexDirection: 'row', marginBottom: 10 }}>
                <Text style={{ color: colors.text, marginRight: 8 }}>✦</Text>
                <Text style={{ color: colors.text, fontSize: 14, flex: 1 }}>{perk}</Text>
              </View>
            ))}
          </View>

          <TouchableOpacity
            onPress={subscribe}
            disabled={subscribing}
            style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: subscribing ? 0.6 : 1 }]}
          >
            <Text style={{ color: colors.text, fontWeight: '700' }}>
              {subscribing ? 'Оформляю…' : status.isPro ? `Продлить за ${status.price} мификов` : `Оформить за ${status.price} мификов`}
            </Text>
          </TouchableOpacity>
          <Text style={{ color: colors.textDim, fontSize: 12, marginTop: 8, textAlign: 'center' }}>
            {status.durationDays} дней, списывается с кошелька Mythic
          </Text>
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 14, padding: 16, marginBottom: 20 },
  btn: { borderWidth: 1, borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
});
