import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api } from '../api';

const AGREEMENT_TEXT = `Пользовательское соглашение Mythic Messenger

1. Регистрируясь в Mythic, пользователь подтверждает, что ознакомлен и согласен с настоящим соглашением в полном объёме.

2. Администрация проекта Mythic имеет исключительное право трактовать любые спорные ситуации, связанные с использованием сервиса, включая (но не ограничиваясь) вопросы репутации, блокировок, жалоб и работы кошелька Mythic.

3. Решения администрации по вопросам модерации (бан, снижение репутации, блокировка канала/группы/бота) являются окончательными и не подлежат пересмотру, за исключением случаев, рассмотренных через раздел «Техподдержка» по усмотрению администрации.

4. Администрация не несёт ответственности за содержание переписки, публикаций в ленте и действия пользователей, но оставляет за собой право модерировать контент по собственному усмотрению.

5. Виртуальная валюта «мифики» не является средством платежа и предоставляется/изымается по усмотрению администрации.

6. Продолжая регистрацию, пользователь принимает все текущие и последующие изменения данного соглашения.`;

function Field({ label, value, onChangeText, colors, secure, keyboardType, placeholder }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={[styles.label, { color: colors.textDim }]}>{label}</Text>
      <TextInput
        style={[
          styles.input,
          { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text },
        ]}
        value={value}
        onChangeText={onChangeText}
        secureTextEntry={secure}
        keyboardType={keyboardType}
        placeholder={placeholder}
        placeholderTextColor={colors.textDim}
        autoCapitalize="none"
      />
    </View>
  );
}

export default function AuthScreen({ onAuthenticated }) {
  const { colors } = useAppTheme();
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [login, setLogin] = useState('');
  const [username, setUsername] = useState('');
  const [age, setAge] = useState('');
  const [password, setPassword] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [showAgreement, setShowAgreement] = useState(false);

  const isRegister = mode === 'register';

  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    if (!login.trim() || !password.trim()) {
      Alert.alert('Ошибка', 'Заполни логин и пароль.');
      return;
    }
    if (isRegister) {
      if (!username.trim()) {
        Alert.alert('Ошибка', 'Придумай юзернейм.');
        return;
      }
      const ageNum = parseInt(age, 10);
      if (!ageNum || ageNum < 13 || ageNum > 120) {
        Alert.alert('Ошибка', 'Укажи корректный возраст.');
        return;
      }
      if (!agreed) {
        Alert.alert('Ошибка', 'Нужно принять пользовательское соглашение.');
        return;
      }
    }

    setSubmitting(true);
    try {
      const data = isRegister
        ? await api.register(login.trim(), username.trim(), password, age)
        : await api.login(login.trim(), password);
      onAuthenticated({ token: data.token, ...data.user });
    } catch (e) {
      Alert.alert('Не получилось', e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <Text style={[styles.brand, { color: colors.text }]}>Mythic</Text>
        <Text style={[styles.subtitle, { color: colors.textDim }]}>
          {isRegister ? 'Создай аккаунт' : 'Вход в аккаунт'}
        </Text>

        <View style={styles.card}>
          <Field
            label="Логин"
            value={login}
            onChangeText={setLogin}
            colors={colors}
            placeholder="Например: dan_ok"
          />
          {isRegister && (
            <>
              <Field
                label="Юзернейм"
                value={username}
                onChangeText={setUsername}
                colors={colors}
                placeholder="@mythic_user"
              />
              <Field
                label="Возраст"
                value={age}
                onChangeText={setAge}
                colors={colors}
                keyboardType="number-pad"
                placeholder="18"
              />
            </>
          )}
          <Field
            label="Пароль"
            value={password}
            onChangeText={setPassword}
            colors={colors}
            secure
            placeholder="••••••••"
          />

          {isRegister && (
            <TouchableOpacity
              style={styles.agreeRow}
              onPress={() => setAgreed((a) => !a)}
              activeOpacity={0.7}
            >
              <View
                style={[
                  styles.checkbox,
                  {
                    borderColor: colors.border,
                    backgroundColor: agreed ? colors.text : 'transparent',
                  },
                ]}
              />
              <Text style={[styles.agreeText, { color: colors.textDim }]}>
                Принимаю{' '}
                <Text
                  style={{ color: colors.text, textDecorationLine: 'underline' }}
                  onPress={() => setShowAgreement(true)}
                >
                  пользовательское соглашение
                </Text>
              </Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            style={[
              styles.submitBtn,
              { backgroundColor: colors.surfaceAlt, borderColor: colors.border, opacity: submitting ? 0.6 : 1 },
            ]}
            onPress={submit}
            activeOpacity={0.75}
            disabled={submitting}
          >
            <Text style={[styles.submitText, { color: colors.text }]}>
              {submitting ? 'Секунду…' : isRegister ? 'Зарегистрироваться' : 'Войти'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setMode(isRegister ? 'login' : 'register')}
            style={{ marginTop: 18, alignItems: 'center' }}
          >
            <Text style={{ color: colors.textDim, fontSize: 14 }}>
              {isRegister ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Зарегистрироваться'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <Modal visible={showAgreement} animationType="slide" onRequestClose={() => setShowAgreement(false)}>
        <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: 60, paddingHorizontal: 20 }}>
          <ScrollView>
            <Text style={{ color: colors.text, fontSize: 20, fontWeight: '700', marginBottom: 16 }}>
              Пользовательское соглашение
            </Text>
            <Text style={{ color: colors.textDim, fontSize: 14, lineHeight: 22 }}>{AGREEMENT_TEXT}</Text>
          </ScrollView>
          <TouchableOpacity
            style={[styles.submitBtn, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, marginVertical: 20 }]}
            onPress={() => {
              setAgreed(true);
              setShowAgreement(false);
            }}
          >
            <Text style={[styles.submitText, { color: colors.text }]}>Принять и закрыть</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scroll: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 24, paddingVertical: 40 },
  brand: { fontSize: 30, fontWeight: '700', textAlign: 'center', marginBottom: 4 },
  subtitle: { fontSize: 15, textAlign: 'center', marginBottom: 28 },
  card: { width: '100%' },
  label: { fontSize: 13, marginBottom: 6, fontWeight: '500' },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15 },
  agreeRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4, marginBottom: 18 },
  checkbox: { width: 20, height: 20, borderWidth: 1.5, borderRadius: 5, marginRight: 10 },
  agreeText: { fontSize: 13, flex: 1, lineHeight: 18 },
  submitBtn: { borderWidth: 1, borderRadius: 14, paddingVertical: 16, alignItems: 'center' },
  submitText: { fontSize: 16, fontWeight: '600' },
});
