import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Modal,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api } from '../api';
import MessageContent from '../components/MessageContent';
import { pickMediaFromLibrary, pickMediaFromCamera, pickDocument } from '../utils/attachments';

function HashtagText({ text, colors, onPressTag }) {
  if (!text) return null;
  const parts = text.split(/(#[\p{L}0-9_]+)/gu);
  return (
    <Text style={{ color: colors.text, fontSize: 15, lineHeight: 21 }}>
      {parts.map((part, i) =>
        part.startsWith('#') ? (
          <Text key={i} style={{ color: colors.text, fontWeight: '700' }} onPress={() => onPressTag(part.slice(1))}>
            {part}
          </Text>
        ) : (
          <Text key={i}>{part}</Text>
        )
      )}
    </Text>
  );
}

export default function FeedScreen({ token, myLogin }) {
  const { colors } = useAppTheme();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [onlyMine, setOnlyMine] = useState(false);
  const [hashtagFilter, setHashtagFilter] = useState('');
  const [hashtagInput, setHashtagInput] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [postText, setPostText] = useState('');
  const [pendingAttachment, setPendingAttachment] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [posting, setPosting] = useState(false);
  const [isPro, setIsPro] = useState(false);
  const [postingAsOptions, setPostingAsOptions] = useState([]); // [{label, kind, id}]
  const [postingAs, setPostingAs] = useState({ label: 'от себя', kind: 'user', id: null });

  const load = useCallback(() => {
    setLoading(true);
    const req = onlyMine
      ? api.getMyPosts(token)
      : api.getFeed(token, { hashtag: hashtagFilter || undefined });
    req
      .then((data) => setPosts(data.posts || []))
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setLoading(false));
  }, [token, onlyMine, hashtagFilter]);

  useEffect(load, [load]);

  useEffect(() => {
    api
      .getProStatus(token)
      .then((status) => {
        setIsPro(status.isPro);
        if (!status.isPro) return;
        Promise.all([api.getMyBots(token), api.getMyCommunities(token)])
          .then(([botsData, communitiesData]) => {
            const bots = (botsData.bots || []).map((b) => ({ label: `🤖 ${b.username}`, kind: 'bot', id: b.id }));
            const communities = (communitiesData.communities || [])
              .filter((c) => c.myRole === 'owner' || c.myRole === 'co_owner')
              .map((c) => ({ label: `${c.type === 'channel' ? '📢' : '👥'} ${c.name}`, kind: 'community', id: c.id }));
            setPostingAsOptions([...bots, ...communities]);
          })
          .catch(() => {});
      })
      .catch(() => {});
  }, [token]);

  const openTag = (tag) => {
    setOnlyMine(false);
    setHashtagFilter(tag);
    setHashtagInput(tag);
  };

  const applyHashtagSearch = () => {
    setHashtagFilter(hashtagInput.trim().replace(/^#/, ''));
  };

  const pickAttachment = async (fn) => {
    try {
      const picked = await fn();
      if (!picked) return;
      setUploading(true);
      const uploaded = await api.uploadFile(token, picked);
      setPendingAttachment({ ...uploaded, kind: picked.kind });
    } catch (e) {
      Alert.alert('Ошибка', e.message);
    } finally {
      setUploading(false);
    }
  };

  const choosePostingAs = () => {
    const options = [
      { text: 'От себя', onPress: () => setPostingAs({ label: 'от себя', kind: 'user', id: null }) },
      ...postingAsOptions.map((o) => ({ text: o.label, onPress: () => setPostingAs(o) })),
      { text: 'Отмена', style: 'cancel' },
    ];
    Alert.alert('Публиковать от имени', undefined, options);
  };

  const publish = () => {
    if (!postText.trim() && !pendingAttachment) {
      Alert.alert('Пусто', 'Напиши текст или прикрепи файл');
      return;
    }
    setPosting(true);
    api
      .createPost(token, {
        content: postText.trim() || null,
        attachmentUrl: pendingAttachment?.url,
        attachmentType: pendingAttachment?.kind,
        attachmentName: pendingAttachment?.name,
        attachmentSize: pendingAttachment?.size,
        asKind: postingAs.kind,
        asId: postingAs.id,
      })
      .then(() => {
        setCreateOpen(false);
        setPostText('');
        setPendingAttachment(null);
        setPostingAs({ label: 'от себя', kind: 'user', id: null });
        load();
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setPosting(false));
  };

  const managePost = (post) => {
    Alert.alert('Пост', undefined, [
      {
        text: post.hidden ? 'Показать' : 'Скрыть',
        onPress: () =>
          api
            .setPostHidden(token, post.id, !post.hidden)
            .then(load)
            .catch((e) => Alert.alert('Ошибка', e.message)),
      },
      {
        text: 'Удалить',
        style: 'destructive',
        onPress: () =>
          api
            .deletePost(token, post.id)
            .then(load)
            .catch((e) => Alert.alert('Ошибка', e.message)),
      },
      { text: 'Отмена', style: 'cancel' },
    ]);
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.filterRow}>
        <TextInput
          value={hashtagInput}
          onChangeText={setHashtagInput}
          onSubmitEditing={applyHashtagSearch}
          placeholder="Фильтр по хештегу, напр. мифики"
          placeholderTextColor={colors.textDim}
          autoCapitalize="none"
          style={[styles.tagInput, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
        />
        <TouchableOpacity
          onPress={() => setCreateOpen(true)}
          style={[styles.addBtn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text, fontSize: 18, lineHeight: 20 }}>+</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.segmentRow}>
        <TouchableOpacity
          onPress={() => setOnlyMine(false)}
          style={[styles.segmentBtn, !onlyMine && { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}
        >
          <Text style={{ color: !onlyMine ? colors.text : colors.textDim, fontSize: 13 }}>Все посты</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setOnlyMine(true)}
          style={[styles.segmentBtn, onlyMine && { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}
        >
          <Text style={{ color: onlyMine ? colors.text : colors.textDim, fontSize: 13 }}>Только мои</Text>
        </TouchableOpacity>
        {hashtagFilter ? (
          <TouchableOpacity
            onPress={() => {
              setHashtagFilter('');
              setHashtagInput('');
            }}
            style={[styles.segmentBtn, { borderColor: colors.border }]}
          >
            <Text style={{ color: colors.textDim, fontSize: 13 }}>✕ #{hashtagFilter}</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {loading ? (
        <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ padding: 12 }}
          ListEmptyComponent={
            <Text style={{ color: colors.textDim, textAlign: 'center', marginTop: 30 }}>
              {onlyMine ? 'У тебя пока нет постов' : 'Пока пусто'}
            </Text>
          }
          renderItem={({ item }) => (
            <TouchableOpacity
              activeOpacity={0.9}
              onLongPress={() => (onlyMine || item.author.login === myLogin ? managePost(item) : null)}
              style={[
                styles.card,
                { backgroundColor: colors.surface, borderColor: colors.border },
                item.hidden && { opacity: 0.5 },
              ]}
            >
              <View style={styles.cardHeader}>
                <Text style={{ color: colors.text, fontWeight: '600', fontSize: 14 }}>
                  {item.author.kind === 'bot' && `🤖 ${item.author.username || item.author.login}`}
                  {item.author.kind === 'community' &&
                    `${item.author.communityType === 'channel' ? '📢' : '👥'} ${item.author.name}`}
                  {(!item.author.kind || item.author.kind === 'user') && `@${item.author.username || item.author.login}`}
                </Text>
                {item.hidden && <Text style={{ color: colors.textDim, fontSize: 11 }}>скрыт</Text>}
              </View>

              {item.content ? (
                <View style={{ marginTop: 6 }}>
                  <HashtagText text={item.content} colors={colors} onPressTag={openTag} />
                </View>
              ) : null}

              {item.attachmentUrl && (
                <View style={{ marginTop: 8 }}>
                  <MessageContent
                    msgType={item.attachmentType}
                    content={JSON.stringify({
                      url: item.attachmentUrl,
                      name: item.attachmentName,
                      size: item.attachmentSize,
                    })}
                  />
                </View>
              )}
            </TouchableOpacity>
          )}
        />
      )}

      <Modal visible={createOpen} animationType="slide" transparent onRequestClose={() => setCreateOpen(false)}>
        <KeyboardAvoidingView
          style={styles.modalOverlay}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <View style={[styles.modalCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Новый пост</Text>

            {isPro && postingAsOptions.length > 0 && (
              <TouchableOpacity onPress={choosePostingAs} style={{ marginBottom: 10 }}>
                <Text style={{ color: colors.textDim, fontSize: 13 }}>
                  Публикую: <Text style={{ color: colors.text, fontWeight: '600' }}>{postingAs.label}</Text> · сменить
                </Text>
              </TouchableOpacity>
            )}

            <TextInput
              value={postText}
              onChangeText={setPostText}
              placeholder="Что нового? Добавь #хештеги"
              placeholderTextColor={colors.textDim}
              multiline
              style={[styles.postInput, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
            />

            {pendingAttachment && (
              <View style={{ marginTop: 10 }}>
                <MessageContent
                  msgType={pendingAttachment.kind}
                  content={JSON.stringify({ url: pendingAttachment.url, name: pendingAttachment.name, size: pendingAttachment.size })}
                />
                <TouchableOpacity onPress={() => setPendingAttachment(null)}>
                  <Text style={{ color: colors.danger, fontSize: 12, marginTop: 4 }}>Убрать вложение</Text>
                </TouchableOpacity>
              </View>
            )}

            {uploading && <ActivityIndicator color={colors.text} style={{ marginTop: 8 }} />}

            <View style={styles.attachRow}>
              <TouchableOpacity onPress={() => pickAttachment(pickMediaFromLibrary)} style={{ paddingHorizontal: 6 }}>
                <Text style={{ fontSize: 20 }}>🖼️</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => pickAttachment(pickMediaFromCamera)} style={{ paddingHorizontal: 6 }}>
                <Text style={{ fontSize: 20 }}>📷</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => pickAttachment(pickDocument)} style={{ paddingHorizontal: 6 }}>
                <Text style={{ fontSize: 20 }}>📎</Text>
              </TouchableOpacity>
            </View>

            <View style={{ flexDirection: 'row', marginTop: 16, gap: 10 }}>
              <TouchableOpacity
                onPress={() => {
                  setCreateOpen(false);
                  setPostText('');
                  setPendingAttachment(null);
                }}
                style={[styles.modalBtn, { borderColor: colors.border }]}
              >
                <Text style={{ color: colors.textDim }}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={publish}
                disabled={posting || uploading}
                style={[styles.modalBtn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: posting ? 0.6 : 1 }]}
              >
                <Text style={{ color: colors.text, fontWeight: '600' }}>{posting ? 'Публикую…' : 'Опубликовать'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  filterRow: { flexDirection: 'row', paddingHorizontal: 16, paddingTop: 12, gap: 8 },
  tagInput: { flex: 1, borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14 },
  addBtn: { width: 42, height: 42, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  segmentRow: { flexDirection: 'row', paddingHorizontal: 16, paddingTop: 10, gap: 8 },
  segmentBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10, borderWidth: 1, borderColor: 'transparent' },
  card: { borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 12 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', paddingHorizontal: 24 },
  modalCard: { borderWidth: 1, borderRadius: 16, padding: 20 },
  modalTitle: { fontSize: 17, fontWeight: '700', marginBottom: 14 },
  postInput: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15, minHeight: 90, textAlignVertical: 'top' },
  attachRow: { flexDirection: 'row', marginTop: 10 },
  modalBtn: { flex: 1, borderWidth: 1, borderRadius: 12, paddingVertical: 12, alignItems: 'center' },
});
