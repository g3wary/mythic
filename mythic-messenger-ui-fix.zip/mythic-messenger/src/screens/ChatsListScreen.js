import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { useSocket } from '../context/SocketContext';
import { api } from '../api';
import { looksEncrypted } from '../utils/e2e';

function previewText(item) {
  if (item.lastMessageType !== 'text') return `[${item.lastMessageType}]`;
  if (looksEncrypted(item.lastMessage)) return '🔒 Зашифрованное сообщение';
  return item.lastMessage;
}

export default function ChatsListScreen({ token, myLogin, onOpenChat }) {
  const { colors } = useAppTheme();
  const { subscribe } = useSocket();
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);

  const loadConversations = useCallback(() => {
    setLoading(true);
    api
      .getConversations(token)
      .then((data) => setConversations(data.conversations || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  // Обновляем список при входящем/исходящем сообщении в реальном времени
  useEffect(() => {
    const unsub = subscribe((data) => {
      if (data.type !== 'dm') return;
      loadConversations();
    });
    return unsub;
  }, [subscribe, loadConversations]);

  useEffect(() => {
    const q = query.trim();
    if (!q) {
      setSearchResults([]);
      return;
    }
    setSearching(true);
    const timeout = setTimeout(() => {
      api
        .searchUsers(token, q)
        .then((data) => setSearchResults(data.users || []))
        .catch(() => setSearchResults([]))
        .finally(() => setSearching(false));
    }, 300);
    return () => clearTimeout(timeout);
  }, [query, token]);

  const showingSearch = query.trim().length > 0;

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.searchWrap}>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Найти по логину или юзернейму"
          placeholderTextColor={colors.textDim}
          autoCapitalize="none"
          style={[
            styles.searchInput,
            { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text },
          ]}
        />
      </View>

      {showingSearch ? (
        searching ? (
          <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />
        ) : (
          <FlatList
            data={searchResults}
            keyExtractor={(item) => item.login}
            ListEmptyComponent={
              <Text style={[styles.empty, { color: colors.textDim }]}>Никого не нашлось</Text>
            }
            renderItem={({ item }) => (
              <TouchableOpacity
                style={[styles.row, { borderBottomColor: colors.border }]}
                onPress={() => onOpenChat(item.login)}
              >
                <View style={[styles.avatar, { backgroundColor: colors.surfaceAlt }]} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.rowTitle, { color: colors.text }]}>@{item.username}</Text>
                  <Text style={[styles.rowSub, { color: colors.textDim }]}>{item.login}</Text>
                </View>
              </TouchableOpacity>
            )}
          />
        )
      ) : loading ? (
        <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={(item) => item.login}
          ListEmptyComponent={
            <Text style={[styles.empty, { color: colors.textDim }]}>
              Пока нет диалогов. Найди пользователя через поиск выше.
            </Text>
          }
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.row, { borderBottomColor: colors.border }]}
              onPress={() => onOpenChat(item.login)}
            >
              <View style={[styles.avatar, { backgroundColor: colors.surfaceAlt }]} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.rowTitle, { color: colors.text }]}>
                  @{item.username || item.login}
                </Text>
                <Text style={[styles.rowSub, { color: colors.textDim }]} numberOfLines={1}>
                  {item.lastMessageMine ? 'Вы: ' : ''}
                  {previewText(item)}
                </Text>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  searchWrap: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8 },
  searchInput: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, fontSize: 15 },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1 },
  avatar: { width: 44, height: 44, borderRadius: 22, marginRight: 12 },
  rowTitle: { fontSize: 15, fontWeight: '600' },
  rowSub: { fontSize: 13, marginTop: 2 },
  empty: { textAlign: 'center', marginTop: 30, fontSize: 14, paddingHorizontal: 24 },
});
