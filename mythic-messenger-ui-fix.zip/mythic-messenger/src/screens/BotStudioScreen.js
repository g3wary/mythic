import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Modal,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api, resolveMediaUrl } from '../api';
import { pickMediaFromLibrary, pickMediaFromCamera } from '../utils/attachments';

function BotCard({ bot, token, colors, onChanged }) {
  const [showToken, setShowToken] = useState(false);
  const [nickname, setNickname] = useState(bot.username);
  const [username, setUsername] = useState(bot.login);
  const [saving, setSaving] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);

  const save = () => {
    setSaving(true);
    api
      .updateBot(token, bot.id, { nickname, username })
      .then(onChanged)
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setSaving(false));
  };

  const changeAvatar = (fn) => {
    fn()
      .then((picked) => {
        if (!picked) return null;
        setAvatarUploading(true);
        return api.uploadFile(token, picked).then((uploaded) => api.updateBot(token, bot.id, { avatarUrl: uploaded.url }));
      })
      .then((updated) => updated && onChanged())
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setAvatarUploading(false));
  };

  const regenerate = () => {
    Alert.alert('Новый токен', 'Старый токен перестанет работать — обнови его в коде бота. Продолжить?', [
      { text: 'Отмена', style: 'cancel' },
      {
        text: 'Сгенерировать',
        style: 'destructive',
        onPress: () =>
          api
            .regenerateBotToken(token, bot.id)
            .then(() => {
              setShowToken(true);
              onChanged();
            })
            .catch((e) => Alert.alert('Ошибка', e.message)),
      },
    ]);
  };

  const remove = () => {
    Alert.alert('Удалить бота', `«${bot.username}» и вся его переписка будут удалены безвозвратно.`, [
      { text: 'Отмена', style: 'cancel' },
      {
        text: 'Удалить',
        style: 'destructive',
        onPress: () => api.deleteBot(token, bot.id).then(onChanged).catch((e) => Alert.alert('Ошибка', e.message)),
      },
    ]);
  };

  return (
    <View style={[styles.card, { borderColor: colors.border, backgroundColor: colors.surface }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
        <TouchableOpacity
          onPress={() =>
            Alert.alert('Аватар бота', undefined, [
              { text: 'Из галереи', onPress: () => changeAvatar(pickMediaFromLibrary) },
              { text: 'Камера', onPress: () => changeAvatar(pickMediaFromCamera) },
              { text: 'Отмена', style: 'cancel' },
            ])
          }
        >
          {bot.avatarUrl ? (
            <Image source={{ uri: resolveMediaUrl(bot.avatarUrl) }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatar, { backgroundColor: colors.surfaceAlt, alignItems: 'center', justifyContent: 'center' }]}>
              <Text style={{ fontSize: 18 }}>🤖</Text>
            </View>
          )}
        </TouchableOpacity>
        <View style={{ marginLeft: 12, flex: 1 }}>
          <Text style={{ color: colors.text, fontWeight: '700', fontSize: 15 }}>{bot.username}</Text>
          <Text style={{ color: colors.textDim, fontSize: 12 }}>@{bot.login}</Text>
        </View>
        {avatarUploading && <ActivityIndicator color={colors.text} />}
      </View>

      {bot.description ? <Text style={{ color: colors.textDim, fontSize: 13, marginBottom: 10 }}>{bot.description}</Text> : null}

      <Text style={[styles.label, { color: colors.textDim }]}>Ник (отображаемое имя)</Text>
      <TextInput
        value={nickname}
        onChangeText={setNickname}
        style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
      />
      <Text style={[styles.label, { color: colors.textDim, marginTop: 10 }]}>Юзернейм</Text>
      <TextInput
        value={username}
        onChangeText={setUsername}
        autoCapitalize="none"
        style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
      />
      <TouchableOpacity
        onPress={save}
        disabled={saving}
        style={[styles.smallBtn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: saving ? 0.6 : 1 }]}
      >
        <Text style={{ color: colors.text, fontWeight: '600' }}>{saving ? 'Сохраняю…' : 'Сохранить'}</Text>
      </TouchableOpacity>

      <Text style={[styles.label, { color: colors.textDim, marginTop: 14 }]}>Токен (вставь в код бота)</Text>
      <TouchableOpacity onPress={() => setShowToken((v) => !v)}>
        <Text selectable style={{ color: colors.text, fontFamily: 'monospace', fontSize: 13 }}>
          {showToken ? bot.token : '•'.repeat(24) + ' (тап, чтобы показать)'}
        </Text>
      </TouchableOpacity>

      <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
        <TouchableOpacity onPress={regenerate} style={[styles.smallBtn, { flex: 1, borderColor: colors.border }]}>
          <Text style={{ color: colors.textDim, fontSize: 13 }}>Новый токен</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={remove} style={[styles.smallBtn, { flex: 1, borderColor: colors.danger }]}>
          <Text style={{ color: colors.danger, fontSize: 13 }}>Удалить</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function BotStudioScreen({ token, onBack }) {
  const { colors } = useAppTheme();
  const [bots, setBots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [username, setUsername] = useState('');
  const [creating, setCreating] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    api
      .getMyBots(token)
      .then((data) => setBots(data.bots || []))
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(load, [load]);

  const create = () => {
    if (!name.trim() || !username.trim()) {
      Alert.alert('Ошибка', 'Укажи имя и юзернейм бота');
      return;
    }
    setCreating(true);
    api
      .createBot(token, { name: name.trim(), description: description.trim(), username: username.trim() })
      .then(() => {
        setCreateOpen(false);
        setName('');
        setDescription('');
        setUsername('');
        load();
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setCreating(false));
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: 50 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, marginBottom: 12 }}>
        <TouchableOpacity onPress={onBack}>
          <Text style={{ color: colors.text, fontSize: 20 }}>‹ Назад</Text>
        </TouchableOpacity>
        <View style={{ flex: 1 }} />
        <TouchableOpacity
          onPress={() => setCreateOpen(true)}
          style={[styles.addBtn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text, fontSize: 18 }}>+</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <ActivityIndicator color={colors.text} style={{ marginTop: 20 }} />
      ) : (
        <FlatList
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}
          data={bots}
          keyExtractor={(b) => String(b.id)}
          ListEmptyComponent={
            <Text style={{ color: colors.textDim, textAlign: 'center', marginTop: 30 }}>
              У тебя пока нет ботов. Создай первого кнопкой «+».
            </Text>
          }
          renderItem={({ item }) => <BotCard bot={item} token={token} colors={colors} onChanged={load} />}
        />
      )}

      <Modal visible={createOpen} animationType="slide" transparent onRequestClose={() => setCreateOpen(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Новый бот</Text>
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder="Имя бота"
              placeholderTextColor={colors.textDim}
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
            />
            <TextInput
              value={description}
              onChangeText={setDescription}
              placeholder="Описание (необязательно)"
              placeholderTextColor={colors.textDim}
              multiline
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text, marginTop: 10 }]}
            />
            <TextInput
              value={username}
              onChangeText={setUsername}
              placeholder="Юзернейм, например mythic123botik"
              placeholderTextColor={colors.textDim}
              autoCapitalize="none"
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text, marginTop: 10 }]}
            />
            <View style={{ flexDirection: 'row', marginTop: 16, gap: 10 }}>
              <TouchableOpacity onPress={() => setCreateOpen(false)} style={[styles.smallBtn, { flex: 1, borderColor: colors.border }]}>
                <Text style={{ color: colors.textDim }}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={create}
                disabled={creating}
                style={[styles.smallBtn, { flex: 1, borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: creating ? 0.6 : 1 }]}
              >
                <Text style={{ color: colors.text, fontWeight: '600' }}>{creating ? 'Создаю…' : 'Создать'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  addBtn: { width: 38, height: 38, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  card: { borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 14 },
  avatar: { width: 48, height: 48, borderRadius: 12 },
  label: { fontSize: 12, marginBottom: 5 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9, fontSize: 14 },
  smallBtn: { borderWidth: 1, borderRadius: 10, paddingVertical: 10, alignItems: 'center', marginTop: 8 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', paddingHorizontal: 24 },
  modalCard: { borderWidth: 1, borderRadius: 16, padding: 20 },
  modalTitle: { fontSize: 17, fontWeight: '700', marginBottom: 14 },
});
