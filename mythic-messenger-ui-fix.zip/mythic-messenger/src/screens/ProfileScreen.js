import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api } from '../api';

export default function ProfileScreen({ token, login, onBack }) {
  const { colors } = useAppTheme();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    api
      .getProfile(token, login)
      .then(setProfile)
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setLoading(false));
  };

  useEffect(load, [token, login]);

  const toggleBlock = () => {
    const action = profile?.blockedByMe ? api.unblockUser : api.blockUser;
    action(token, login)
      .then(load)
      .catch((e) => Alert.alert('Ошибка', e.message));
  };

  const report = () => {
    Alert.alert('Пожаловаться', `Отправить жалобу на ${login}?`, [
      { text: 'Отмена', style: 'cancel' },
      {
        text: 'Отправить',
        style: 'destructive',
        onPress: () =>
          api
            .reportUser(token, login)
            .then(() => Alert.alert('Готово', 'Жалоба отправлена администрации'))
            .catch((e) => Alert.alert('Ошибка', e.message)),
      },
    ]);
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.bg, justifyContent: 'center' }]}>
        <ActivityIndicator color={colors.text} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.bg }]}>
      <TouchableOpacity onPress={onBack} style={{ marginBottom: 20 }}>
        <Text style={{ color: colors.text, fontSize: 20 }}>‹ Назад</Text>
      </TouchableOpacity>

      <View style={[styles.avatar, { backgroundColor: colors.surfaceAlt }]} />
      <Text style={[styles.username, { color: colors.text }]}>
        @{profile?.username} {profile?.hasCheckmark ? '✓' : ''}
      </Text>
      <Text style={[styles.login, { color: colors.textDim }]}>{login}</Text>
      <Text style={[styles.reputation, { color: colors.textDim }]}>
        Репутация: {profile?.reputation}%
      </Text>

      <View style={{ marginTop: 32, gap: 12 }}>
        <TouchableOpacity
          onPress={toggleBlock}
          style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text }}>
            {profile?.blockedByMe ? 'Разблокировать' : 'Заблокировать'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={report} style={[styles.btn, { borderColor: colors.danger }]}>
          <Text style={{ color: colors.danger }}>Пожаловаться</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, paddingTop: 60 },
  avatar: { width: 88, height: 88, borderRadius: 44, alignSelf: 'center', marginBottom: 16 },
  username: { fontSize: 20, fontWeight: '700', textAlign: 'center' },
  login: { fontSize: 14, textAlign: 'center', marginTop: 4 },
  reputation: { fontSize: 14, textAlign: 'center', marginTop: 10 },
  btn: { borderWidth: 1, borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
});
