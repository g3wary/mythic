import React, { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { useSocket } from '../context/SocketContext';
import { useE2E } from '../context/E2EContext';
import { api } from '../api';
import MessageContent from '../components/MessageContent';
import { pickMediaFromLibrary, pickMediaFromCamera, pickDocument, useVoiceRecorder } from '../utils/attachments';
import { sharedKeyFor, encryptText, decryptText } from '../utils/e2e';
import StickerPicker from '../components/StickerPicker';
import { radii, cardShadow, softShadow } from '../theme';

function formatTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

function initialOf(login) {
  return (login || '?').trim().charAt(0).toUpperCase();
}

export default function ChatScreen({ token, myId, myLogin, otherLogin, onBack, onOpenProfile }) {
  const { colors } = useAppTheme();
  const { subscribe, sendDM } = useSocket();
  const { keyPair } = useE2E();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  // undefined = ещё грузится, null = у собеседника нет ключа, строка = есть ключ
  const [otherPublicKey, setOtherPublicKey] = useState(undefined);
  const listRef = useRef(null);
  const voice = useVoiceRecorder();

  useEffect(() => {
    api
      .getProfile(token, otherLogin)
      .then((p) => setOtherPublicKey(p.publicKey || null))
      .catch(() => setOtherPublicKey(null));
  }, [token, otherLogin]);

  // Общий секрет для этой переписки — расшифровывает и входящие, и мои же отправленные сообщения
  const sharedKey = useMemo(() => {
    if (!keyPair || !otherPublicKey) return null;
    return sharedKeyFor(keyPair.secretKey, otherPublicKey);
  }, [keyPair, otherPublicKey]);

  const decrypt = useCallback(
    (content) => decryptText(sharedKey, content),
    [sharedKey]
  );

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .getHistory(token, otherLogin)
      .then((data) => {
        if (cancelled) return;
        const mapped = (data.messages || []).map((m) => ({
          id: m.id,
          mine: m.from_id === myId,
          content: m.content,
          msgType: m.type,
          createdAt: m.created_at,
          edited: !!m.edited,
        }));
        setMessages(mapped);
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [token, otherLogin, myId]);

  useEffect(() => {
    const unsub = subscribe((data) => {
      if (data.type === 'error') {
        Alert.alert('Ошибка', data.error);
        return;
      }
      if (data.type !== 'dm') return;
      const belongsHere =
        (data.fromLogin === otherLogin && data.toLogin === myLogin) ||
        (data.fromLogin === myLogin && data.toLogin === otherLogin);
      if (!belongsHere) return;

      setMessages((prev) => {
        if (data.fromLogin === myLogin) {
          const pendingIdx = [...prev].reverse().findIndex((m) => m.pending && m.content === data.content);
          if (pendingIdx !== -1) {
            const realIdx = prev.length - 1 - pendingIdx;
            const copy = [...prev];
            copy[realIdx] = {
              id: data.id,
              mine: true,
              content: data.content,
              msgType: data.msgType,
              createdAt: data.createdAt,
              edited: false,
            };
            return copy;
          }
        }
        return [
          ...prev,
          {
            id: data.id,
            mine: data.fromLogin === myLogin,
            content: data.content,
            msgType: data.msgType,
            createdAt: data.createdAt,
            edited: false,
          },
        ];
      });
    });
    return unsub;
  }, [subscribe, otherLogin, myLogin]);

  // Общая отправка — используется и для текста, и для вложений
  const sendMessage = useCallback(
    (content, msgType) => {
      const delivered = sendDM(otherLogin, content, msgType);
      if (delivered) {
        setMessages((prev) => [
          ...prev,
          { id: `pending-${Date.now()}`, mine: true, content, msgType, createdAt: new Date().toISOString(), pending: true },
        ]);
      } else {
        api
          .sendMessageRest(token, otherLogin, content, msgType)
          .then((data) => {
            setMessages((prev) => [
              ...prev,
              {
                id: data.message.id,
                mine: true,
                content: data.message.content,
                msgType: data.message.type,
                createdAt: data.message.created_at,
              },
            ]);
          })
          .catch((e) => Alert.alert('Ошибка отправки', e.message));
      }
    },
    [otherLogin, sendDM, token]
  );

  const send = useCallback(() => {
    const plain = text.trim();
    if (!plain) return;

    if (editingId) {
      const outgoing = sharedKey ? encryptText(sharedKey, plain) : plain;
      api
        .editMessage(token, editingId, outgoing)
        .then(() => {
          setMessages((prev) =>
            prev.map((m) => (m.id === editingId ? { ...m, content: outgoing, edited: true } : m))
          );
          setEditingId(null);
          setText('');
        })
        .catch((e) => Alert.alert('Ошибка', e.message));
      return;
    }

    setText('');
    const outgoing = sharedKey ? encryptText(sharedKey, plain) : plain;
    sendMessage(outgoing, 'text');
  }, [text, editingId, token, sendMessage, sharedKey]);

  const uploadAndSend = useCallback(
    async (picked) => {
      if (!picked) return;
      setUploading(true);
      try {
        const uploaded = await api.uploadFile(token, picked);
        const content = JSON.stringify({
          url: uploaded.url,
          name: uploaded.name,
          size: uploaded.size,
          mimeType: uploaded.mimeType,
          duration: picked.duration,
        });
        sendMessage(content, picked.kind);
      } catch (e) {
        Alert.alert('Не удалось загрузить', e.message);
      } finally {
        setUploading(false);
      }
    },
    [token, sendMessage]
  );

  const pickSticker = (sticker) => {
    setShowStickerPicker(false);
    sendMessage(JSON.stringify({ url: sticker.url, isAnimated: sticker.isAnimated }), 'sticker');
  };

  const openAttachMenu = () => {
    Alert.alert('Вложение', undefined, [
      { text: 'Фото / видео из галереи', onPress: () => pickMediaFromLibrary().then(uploadAndSend).catch((e) => Alert.alert('Ошибка', e.message)) },
      { text: 'Камера', onPress: () => pickMediaFromCamera().then(uploadAndSend).catch((e) => Alert.alert('Ошибка', e.message)) },
      { text: 'Файл', onPress: () => pickDocument().then(uploadAndSend).catch((e) => Alert.alert('Ошибка', e.message)) },
      { text: 'Отмена', style: 'cancel' },
    ]);
  };

  const toggleVoice = async () => {
    try {
      if (voice.isRecording) {
        const rec = await voice.stop();
        if (rec) await uploadAndSend(rec);
      } else {
        await voice.start();
      }
    } catch (e) {
      Alert.alert('Ошибка', e.message);
    }
  };

  const onLongPressMessage = (msg) => {
    if (!msg.mine || msg.pending) return;
    const options = [
      {
        text: 'Удалить',
        style: 'destructive',
        onPress: () =>
          api
            .deleteMessage(token, msg.id)
            .then(() => setMessages((prev) => prev.filter((m) => m.id !== msg.id)))
            .catch((e) => Alert.alert('Ошибка', e.message)),
      },
      { text: 'Отмена', style: 'cancel' },
    ];
    if (msg.msgType === 'text' || !msg.msgType) {
      options.unshift({
        text: 'Изменить',
        onPress: () => {
          setEditingId(msg.id);
          setText(decrypt(msg.content).text);
        },
      });
    }
    Alert.alert('Сообщение', undefined, options);
  };

  const showNoKeyBanner = otherPublicKey === null;
  const canSend = text.trim().length > 0;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.borderSoft }, softShadow(colors)]}>
        <TouchableOpacity onPress={onBack} style={[styles.backBtn, { backgroundColor: colors.surfaceAlt }]} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Text style={{ color: colors.text, fontSize: 19, marginLeft: -2 }}>‹</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => onOpenProfile(otherLogin)} style={styles.headerIdentity} activeOpacity={0.7}>
          <View style={[styles.avatar, { backgroundColor: colors.surfaceRaised }]}>
            <Text style={{ color: colors.textDim, fontSize: 15, fontWeight: '700' }}>{initialOf(otherLogin)}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.headerTitle, { color: colors.text }]} numberOfLines={1}>{otherLogin}</Text>
            <View style={styles.statusRow}>
              {sharedKey ? (
                <>
                  <View style={[styles.statusDot, { backgroundColor: colors.accentStrong }]} />
                  <Text style={{ color: colors.textDim, fontSize: 11.5 }}>Сквозное шифрование</Text>
                </>
              ) : showNoKeyBanner ? (
                <Text style={{ color: colors.textFaint, fontSize: 11.5 }}>Без шифрования</Text>
              ) : null}
            </View>
          </View>
        </TouchableOpacity>
      </View>

      {showNoKeyBanner && (
        <View style={styles.noticeWrap}>
          <View style={[styles.notice, { backgroundColor: colors.surfaceAlt }]}>
            <Text style={{ color: colors.textDim, fontSize: 12, lineHeight: 17 }}>
              Собеседник ещё не заходил в приложение после обновления — сообщения пока идут без шифрования.
            </Text>
          </View>
        </View>
      )}

      {loading ? (
        <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />
      ) : (
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ padding: 14, paddingBottom: 6 }}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          renderItem={({ item }) => {
            const isText = item.msgType === 'text' || !item.msgType;
            const isSticker = item.msgType === 'sticker';
            const resolved = isText ? decrypt(item.content) : null;

            if (isSticker) {
              return (
                <TouchableOpacity
                  activeOpacity={0.85}
                  onLongPress={() => onLongPressMessage(item)}
                  style={[styles.stickerRow, item.mine ? { alignSelf: 'flex-end' } : { alignSelf: 'flex-start' }, item.pending && { opacity: 0.5 }]}
                >
                  <MessageContent msgType={item.msgType} content={item.content} />
                </TouchableOpacity>
              );
            }

            const tailStyle = item.mine
              ? { borderBottomRightRadius: 5 }
              : { borderBottomLeftRadius: 5 };

            return (
              <TouchableOpacity
                activeOpacity={0.85}
                onLongPress={() => onLongPressMessage(item)}
                style={[
                  styles.bubble,
                  tailStyle,
                  item.mine
                    ? { alignSelf: 'flex-end', backgroundColor: colors.bubbleMine }
                    : { alignSelf: 'flex-start', backgroundColor: colors.bubbleTheirs, borderWidth: 1, borderColor: colors.borderSoft },
                  item.mine && cardShadow(colors),
                  item.pending && { opacity: 0.55 },
                ]}
              >
                {isText ? (
                  <Text style={{ color: resolved?.failed ? colors.danger : (item.mine ? colors.bubbleMineText : colors.bubbleTheirsText), fontSize: 15.5, lineHeight: 21 }}>
                    {resolved.text}
                  </Text>
                ) : (
                  <MessageContent msgType={item.msgType} content={item.content} />
                )}
                <View style={styles.metaRow}>
                  {item.edited && <Text style={{ color: colors.textFaint, fontSize: 10.5, marginRight: 6 }}>изменено</Text>}
                  <Text style={{ color: colors.textFaint, fontSize: 10.5 }}>
                    {item.pending ? '…' : formatTime(item.createdAt)}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      )}

      {uploading && (
        <View style={{ paddingHorizontal: 16, paddingBottom: 4 }}>
          <Text style={{ color: colors.textDim, fontSize: 12 }}>Загружаю файл…</Text>
        </View>
      )}

      <View style={[styles.inputBar, { backgroundColor: colors.surface, borderTopColor: colors.borderSoft }]}>
        {editingId ? (
          <TouchableOpacity onPress={() => { setEditingId(null); setText(''); }} style={[styles.iconBtn, { backgroundColor: colors.surfaceAlt }]}>
            <Text style={{ color: colors.danger, fontSize: 15 }}>✕</Text>
          </TouchableOpacity>
        ) : (
          <>
            <TouchableOpacity onPress={openAttachMenu} style={[styles.iconBtn, { backgroundColor: colors.surfaceAlt }]} disabled={uploading} activeOpacity={0.7}>
              <Text style={{ fontSize: 17 }}>📎</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setShowStickerPicker(true)} style={[styles.iconBtn, { backgroundColor: colors.surfaceAlt }]} disabled={uploading} activeOpacity={0.7}>
              <Text style={{ fontSize: 16 }}>😊</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={toggleVoice} style={[styles.iconBtn, { backgroundColor: voice.isRecording ? colors.danger : colors.surfaceAlt }]} disabled={uploading} activeOpacity={0.7}>
              <Text style={{ fontSize: 15 }}>{voice.isRecording ? '⏺' : '🎤'}</Text>
            </TouchableOpacity>
          </>
        )}
        <TextInput
          value={text}
          onChangeText={setText}
          placeholder={editingId ? 'Редактирование…' : voice.isRecording ? 'Идёт запись…' : 'Сообщение'}
          placeholderTextColor={colors.textFaint}
          editable={!voice.isRecording}
          style={[styles.input, { backgroundColor: colors.surfaceAlt, color: colors.text }]}
          multiline
        />
        <TouchableOpacity
          onPress={send}
          disabled={!editingId && !canSend}
          activeOpacity={0.75}
          style={[
            styles.sendBtn,
            { backgroundColor: editingId || canSend ? colors.accentStrong : colors.surfaceAlt },
          ]}
        >
          <Text style={{ color: editingId || canSend ? colors.bg : colors.textFaint, fontWeight: '700', fontSize: 15 }}>
            {editingId ? '✓' : '➤'}
          </Text>
        </TouchableOpacity>
      </View>

      <StickerPicker
        visible={showStickerPicker}
        token={token}
        colors={colors}
        onClose={() => setShowStickerPicker(false)}
        onPick={pickSticker}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth },
  backBtn: { width: 34, height: 34, borderRadius: radii.pill, alignItems: 'center', justifyContent: 'center', marginRight: 8 },
  headerIdentity: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  avatar: { width: 38, height: 38, borderRadius: radii.pill, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  headerTitle: { fontSize: 16, fontWeight: '700', letterSpacing: 0.1 },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginTop: 2 },
  statusDot: { width: 5, height: 5, borderRadius: 3, marginRight: 5 },
  noticeWrap: { paddingHorizontal: 14, paddingTop: 10 },
  notice: { borderRadius: radii.md, paddingHorizontal: 12, paddingVertical: 9 },
  bubble: { maxWidth: '80%', borderRadius: radii.lg, paddingHorizontal: 13, paddingVertical: 9, marginBottom: 9 },
  stickerRow: { marginBottom: 9 },
  metaRow: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', marginTop: 3 },
  inputBar: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 10, paddingVertical: 10, borderTopWidth: StyleSheet.hairlineWidth, gap: 6 },
  iconBtn: { width: 38, height: 38, borderRadius: radii.pill, alignItems: 'center', justifyContent: 'center' },
  input: { flex: 1, borderRadius: radii.xl, paddingHorizontal: 15, paddingVertical: 10, fontSize: 15.5, maxHeight: 120 },
  sendBtn: { width: 38, height: 38, borderRadius: radii.pill, alignItems: 'center', justifyContent: 'center' },
});
