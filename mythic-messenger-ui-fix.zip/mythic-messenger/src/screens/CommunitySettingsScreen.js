import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Switch,
  Alert,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api } from '../api';

export default function CommunitySettingsScreen({ token, community, onBack, onDeleted }) {
  const { colors } = useAppTheme();
  const [name, setName] = useState(community.name);
  const [description, setDescription] = useState(community.description || '');
  const [writeEnabled, setWriteEnabled] = useState(community.writeEnabled);
  const [saving, setSaving] = useState(false);
  const [members, setMembers] = useState([]);
  const [loadingMembers, setLoadingMembers] = useState(true);
  const [newCoOwner, setNewCoOwner] = useState('');

  const loadMembers = () => {
    setLoadingMembers(true);
    api
      .getCommunityMembers(token, community.id)
      .then((data) => setMembers(data.members || []))
      .catch(() => {})
      .finally(() => setLoadingMembers(false));
  };

  useEffect(loadMembers, [token, community.id]);

  const save = () => {
    setSaving(true);
    api
      .updateCommunity(token, community.id, {
        name,
        description,
        ...(community.type === 'group' ? { writeEnabled } : {}),
      })
      .then(() => Alert.alert('Готово', 'Настройки сохранены'))
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setSaving(false));
  };

  const addCoOwner = () => {
    const login = newCoOwner.trim();
    if (!login) return;
    api
      .addCoOwner(token, community.id, login)
      .then(() => {
        setNewCoOwner('');
        loadMembers();
      })
      .catch((e) => Alert.alert('Ошибка', e.message));
  };

  const removeCoOwner = (login) => {
    api
      .removeCoOwner(token, community.id, login)
      .then(loadMembers)
      .catch((e) => Alert.alert('Ошибка', e.message));
  };

  const remove = () => {
    Alert.alert(
      'Удалить безвозвратно',
      `Удалить ${community.type === 'channel' ? 'канал' : 'группу'} «${community.name}»? Это действие необратимо.`,
      [
        { text: 'Отмена', style: 'cancel' },
        {
          text: 'Удалить',
          style: 'destructive',
          onPress: () =>
            api
              .deleteCommunity(token, community.id)
              .then(onDeleted)
              .catch((e) => Alert.alert('Ошибка', e.message)),
        },
      ]
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: 50 }}>
      <TouchableOpacity onPress={onBack} style={{ paddingHorizontal: 20, marginBottom: 12 }}>
        <Text style={{ color: colors.text, fontSize: 20 }}>‹ Назад</Text>
      </TouchableOpacity>

      <FlatList
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}
        ListHeaderComponent={
          <>
            <Text style={[styles.label, { color: colors.textDim }]}>Название</Text>
            <TextInput
              value={name}
              onChangeText={setName}
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
            />

            <Text style={[styles.label, { color: colors.textDim, marginTop: 14 }]}>Описание</Text>
            <TextInput
              value={description}
              onChangeText={setDescription}
              multiline
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
            />

            {community.type === 'group' && (
              <View style={styles.switchRow}>
                <Text style={{ color: colors.text, fontSize: 15 }}>Разрешить всем участникам писать</Text>
                <Switch value={writeEnabled} onValueChange={setWriteEnabled} />
              </View>
            )}

            <TouchableOpacity
              onPress={save}
              disabled={saving}
              style={[styles.saveBtn, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, opacity: saving ? 0.6 : 1 }]}
            >
              <Text style={{ color: colors.text, fontWeight: '600' }}>{saving ? 'Сохраняю…' : 'Сохранить'}</Text>
            </TouchableOpacity>

            {community.type === 'channel' && (
              <>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Совладельцы</Text>
                <Text style={{ color: colors.textDim, fontSize: 12, marginBottom: 10 }}>
                  Совладелец может постить в канал, но не может назначать других совладельцев.
                </Text>
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <TextInput
                    value={newCoOwner}
                    onChangeText={setNewCoOwner}
                    placeholder="Логин пользователя"
                    placeholderTextColor={colors.textDim}
                    autoCapitalize="none"
                    style={[styles.input, { flex: 1, backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
                  />
                  <TouchableOpacity
                    onPress={addCoOwner}
                    style={[styles.saveBtn, { marginTop: 0, borderColor: colors.border, backgroundColor: colors.surfaceAlt, paddingHorizontal: 16 }]}
                  >
                    <Text style={{ color: colors.text }}>Добавить</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}

            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              {community.type === 'channel' ? 'Подписчики' : 'Участники'} ({members.length})
            </Text>
            {loadingMembers && <ActivityIndicator color={colors.text} />}
          </>
        }
        data={members}
        keyExtractor={(m) => m.login}
        renderItem={({ item }) => (
          <View style={[styles.memberRow, { borderBottomColor: colors.border }]}>
            <Text style={{ color: colors.text, fontSize: 14 }}>
              @{item.username || item.login}{' '}
              {item.role === 'owner' && <Text style={{ color: colors.textDim }}>· владелец</Text>}
              {item.role === 'co_owner' && <Text style={{ color: colors.textDim }}>· совладелец</Text>}
            </Text>
            {item.role === 'co_owner' && (
              <TouchableOpacity onPress={() => removeCoOwner(item.login)}>
                <Text style={{ color: colors.danger, fontSize: 13 }}>Снять</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
        ListFooterComponent={
          <TouchableOpacity onPress={remove} style={[styles.deleteBtn, { borderColor: colors.danger }]}>
            <Text style={{ color: colors.danger, fontWeight: '600' }}>
              Удалить {community.type === 'channel' ? 'канал' : 'группу'} безвозвратно
            </Text>
          </TouchableOpacity>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  label: { fontSize: 13, marginBottom: 6, fontWeight: '500' },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15 },
  switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 18 },
  saveBtn: { marginTop: 20, borderWidth: 1, borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
  sectionTitle: { fontSize: 16, fontWeight: '700', marginTop: 28, marginBottom: 8 },
  memberRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1 },
  deleteBtn: { marginTop: 30, borderWidth: 1, borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
});
