import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api, resolveMediaUrl } from '../api';
import { pickMediaFromLibrary, pickMediaFromCamera } from '../utils/attachments';
import BotStudioScreen from './BotStudioScreen';
import StickerStudioScreen from './StickerStudioScreen';
import ProScreen from './ProScreen';

function Section({ title, colors, children }) {
  return (
    <View style={{ marginBottom: 26 }}>
      <Text style={[styles.sectionTitle, { color: colors.text }]}>{title}</Text>
      {children}
    </View>
  );
}

export default function SettingsScreen({ token, user, onUserUpdate }) {
  const { colors, mode, toggleTheme } = useAppTheme();
  const [showBotStudio, setShowBotStudio] = useState(false);
  const [showStickerStudio, setShowStickerStudio] = useState(false);
  const [showPro, setShowPro] = useState(false);

  const [login, setLogin] = useState(user.login);
  const [username, setUsername] = useState(user.username || '');
  const [savingProfile, setSavingProfile] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);

  const [avatarUploading, setAvatarUploading] = useState(false);

  const [emailInput, setEmailInput] = useState('');
  const [codeInput, setCodeInput] = useState('');
  const [emailBusy, setEmailBusy] = useState(false);

  const saveProfile = () => {
    setSavingProfile(true);
    api
      .updateProfile(token, { login: login.trim(), username: username.trim() })
      .then((updated) => {
        onUserUpdate(updated);
        Alert.alert('Готово', 'Профиль обновлён');
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setSavingProfile(false));
  };

  const savePassword = () => {
    if (!currentPassword || !newPassword) {
      Alert.alert('Ошибка', 'Заполни оба поля');
      return;
    }
    setSavingPassword(true);
    api
      .updateProfile(token, { currentPassword, newPassword })
      .then(() => {
        setCurrentPassword('');
        setNewPassword('');
        Alert.alert('Готово', 'Пароль изменён');
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setSavingPassword(false));
  };

  const changeAvatar = async (fn) => {
    try {
      const picked = await fn();
      if (!picked) return;
      setAvatarUploading(true);
      const uploaded = await api.uploadFile(token, picked);
      const updated = await api.updateProfile(token, { avatarUrl: uploaded.url });
      onUserUpdate(updated);
    } catch (e) {
      Alert.alert('Ошибка', e.message);
    } finally {
      setAvatarUploading(false);
    }
  };

  const requestEmail = () => {
    if (!emailInput.trim()) {
      Alert.alert('Ошибка', 'Укажи почту');
      return;
    }
    setEmailBusy(true);
    api
      .requestEmail(token, emailInput.trim())
      .then(() => {
        onUserUpdate({ pendingEmail: emailInput.trim() });
        Alert.alert('Заявка отправлена', 'Администратор вышлет код на указанную почту');
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setEmailBusy(false));
  };

  const confirmEmail = () => {
    if (!codeInput.trim()) return;
    setEmailBusy(true);
    api
      .confirmEmail(token, codeInput.trim())
      .then((updated) => {
        onUserUpdate(updated);
        setCodeInput('');
        Alert.alert('Готово', 'Почта подтверждена');
      })
      .catch((e) => Alert.alert('Ошибка', e.message))
      .finally(() => setEmailBusy(false));
  };

  if (showBotStudio) {
    return <BotStudioScreen token={token} onBack={() => setShowBotStudio(false)} />;
  }
  if (showStickerStudio) {
    return <StickerStudioScreen token={token} onBack={() => setShowStickerStudio(false)} />;
  }
  if (showPro) {
    return <ProScreen token={token} onBack={() => setShowPro(false)} />;
  }

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
      <View style={{ alignItems: 'center', marginBottom: 26 }}>
        <TouchableOpacity
          onPress={() =>
            Alert.alert('Аватар', undefined, [
              { text: 'Из галереи', onPress: () => changeAvatar(pickMediaFromLibrary) },
              { text: 'Камера', onPress: () => changeAvatar(pickMediaFromCamera) },
              { text: 'Отмена', style: 'cancel' },
            ])
          }
        >
          {user.avatarUrl ? (
            <Image source={{ uri: resolveMediaUrl(user.avatarUrl) }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatar, { backgroundColor: colors.surfaceAlt, alignItems: 'center', justifyContent: 'center' }]}>
              <Text style={{ color: colors.textDim, fontSize: 12 }}>Фото</Text>
            </View>
          )}
        </TouchableOpacity>
        {avatarUploading && <ActivityIndicator color={colors.text} style={{ marginTop: 8 }} />}
      </View>

      <Section title="Mythic Pro" colors={colors}>
        <Text style={{ color: colors.textDim, fontSize: 13, marginBottom: 10 }}>
          Анимированные стикеры и публикация постов от имени твоих групп, ботов и каналов.
        </Text>
        <TouchableOpacity
          onPress={() => setShowPro(true)}
          style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text, fontWeight: '600' }}>Открыть Mythic Pro</Text>
        </TouchableOpacity>
      </Section>

      <Section title="Профиль" colors={colors}>
        <Text style={[styles.label, { color: colors.textDim }]}>Логин</Text>
        <TextInput
          value={login}
          onChangeText={setLogin}
          autoCapitalize="none"
          style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
        />
        <Text style={[styles.label, { color: colors.textDim, marginTop: 12 }]}>Юзернейм</Text>
        <TextInput
          value={username}
          onChangeText={setUsername}
          autoCapitalize="none"
          style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
        />
        <TouchableOpacity
          onPress={saveProfile}
          disabled={savingProfile}
          style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: savingProfile ? 0.6 : 1 }]}
        >
          <Text style={{ color: colors.text, fontWeight: '600' }}>{savingProfile ? 'Сохраняю…' : 'Сохранить'}</Text>
        </TouchableOpacity>
      </Section>

      <Section title="Пароль" colors={colors}>
        <TextInput
          value={currentPassword}
          onChangeText={setCurrentPassword}
          placeholder="Текущий пароль"
          placeholderTextColor={colors.textDim}
          secureTextEntry
          style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
        />
        <TextInput
          value={newPassword}
          onChangeText={setNewPassword}
          placeholder="Новый пароль"
          placeholderTextColor={colors.textDim}
          secureTextEntry
          style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text, marginTop: 10 }]}
        />
        <TouchableOpacity
          onPress={savePassword}
          disabled={savingPassword}
          style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: savingPassword ? 0.6 : 1 }]}
        >
          <Text style={{ color: colors.text, fontWeight: '600' }}>{savingPassword ? 'Сохраняю…' : 'Сменить пароль'}</Text>
        </TouchableOpacity>
      </Section>

      <Section title="Почта" colors={colors}>
        {user.emailVerified ? (
          <Text style={{ color: colors.textDim, fontSize: 14 }}>Подтверждена: {user.email}</Text>
        ) : user.pendingEmail ? (
          <>
            <Text style={{ color: colors.textDim, fontSize: 13, marginBottom: 10 }}>
              Заявка на {user.pendingEmail} отправлена администрации. Введи код, когда его пришлют.
            </Text>
            <TextInput
              value={codeInput}
              onChangeText={setCodeInput}
              placeholder="Код из письма"
              placeholderTextColor={colors.textDim}
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
            />
            <TouchableOpacity
              onPress={confirmEmail}
              disabled={emailBusy}
              style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: emailBusy ? 0.6 : 1 }]}
            >
              <Text style={{ color: colors.text, fontWeight: '600' }}>Подтвердить</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <TextInput
              value={emailInput}
              onChangeText={setEmailInput}
              placeholder="Твоя почта"
              placeholderTextColor={colors.textDim}
              autoCapitalize="none"
              keyboardType="email-address"
              style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
            />
            <TouchableOpacity
              onPress={requestEmail}
              disabled={emailBusy}
              style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt, opacity: emailBusy ? 0.6 : 1 }]}
            >
              <Text style={{ color: colors.text, fontWeight: '600' }}>Отправить заявку</Text>
            </TouchableOpacity>
          </>
        )}
      </Section>

      <Section title="Тема" colors={colors}>
        <TouchableOpacity
          onPress={toggleTheme}
          style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text }}>
            Сменить тему (сейчас: {mode === 'gray' ? 'серая' : 'белая'})
          </Text>
        </TouchableOpacity>
      </Section>

      <Section title="Бот-студия" colors={colors}>
        <Text style={{ color: colors.textDim, fontSize: 13, marginBottom: 10 }}>
          Создавай и настраивай своих ботов — юзернейм, ник, аватар, токен для подключения твоего кода.
        </Text>
        <TouchableOpacity
          onPress={() => setShowBotStudio(true)}
          style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text, fontWeight: '600' }}>Открыть бот-студию</Text>
        </TouchableOpacity>
      </Section>

      <Section title="Mythic Sticker Studio" colors={colors}>
        <Text style={{ color: colors.textDim, fontSize: 13, marginBottom: 10 }}>
          Создавай стикеры и стикер-паки, делай их приватными или платными, собирай чужие в коллекцию.
        </Text>
        <TouchableOpacity
          onPress={() => setShowStickerStudio(true)}
          style={[styles.btn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text, fontWeight: '600' }}>Открыть Sticker Studio</Text>
        </TouchableOpacity>
      </Section>

      <Section title="Кошелёк" colors={colors}>
        <Text style={{ color: colors.textDim, fontSize: 13 }}>{user.walletId}</Text>
      </Section>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  avatar: { width: 88, height: 88, borderRadius: 44 },
  sectionTitle: { fontSize: 15, fontWeight: '700', marginBottom: 10 },
  label: { fontSize: 12, marginBottom: 6 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15 },
  btn: { marginTop: 14, borderWidth: 1, borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
});
