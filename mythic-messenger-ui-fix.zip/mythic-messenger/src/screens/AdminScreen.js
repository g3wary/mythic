import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useAppTheme } from '../context/ThemeContext';
import { api } from '../api';

const SEGMENTS = [
  { key: 'console', label: 'Консоль' },
  { key: 'logs', label: 'Логи' },
  { key: 'tickets', label: 'Тикеты' },
];

const COMMAND_HINTS = [
  '/give <login|wallet> <сумма>',
  '/ban <login>',
  '/unban <login>',
  '/repup <login> <сумма>',
  '/repdown <login> <сумма>',
  '/verify <login>',
  '/checkmark <login> on|off',
  '/emailcode <login> <код>',
  '/pro <login> on|off [дней]',
];

function ConsoleTab({ token }) {
  const { colors } = useAppTheme();
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState([]); // { command, result, error, at }
  const [sending, setSending] = useState(false);

  const run = () => {
    const cmd = command.trim();
    if (!cmd) return;
    setSending(true);
    api
      .adminConsole(token, cmd)
      .then((data) => {
        setHistory((prev) => [{ command: cmd, result: data.result, at: new Date() }, ...prev]);
        setCommand('');
      })
      .catch((e) => {
        setHistory((prev) => [{ command: cmd, error: e.message, at: new Date() }, ...prev]);
      })
      .finally(() => setSending(false));
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <FlatList
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 16 }}
        data={history}
        keyExtractor={(_, i) => String(i)}
        inverted={history.length > 0}
        ListEmptyComponent={
          <View>
            <Text style={{ color: colors.textDim, fontSize: 13, marginBottom: 8 }}>Доступные команды:</Text>
            {COMMAND_HINTS.map((h) => (
              <Text key={h} style={{ color: colors.textDim, fontSize: 12, fontFamily: 'monospace', marginBottom: 3 }}>
                {h}
              </Text>
            ))}
          </View>
        }
        renderItem={({ item }) => (
          <View style={{ marginBottom: 14 }}>
            <Text style={{ color: colors.text, fontSize: 13, fontFamily: 'monospace' }}>{'> ' + item.command}</Text>
            <Text style={{ color: item.error ? colors.danger : colors.textDim, fontSize: 13, marginTop: 2 }}>
              {item.error || item.result}
            </Text>
          </View>
        )}
      />
      <View style={[styles.inputRow, { borderTopColor: colors.border }]}>
        <TextInput
          value={command}
          onChangeText={setCommand}
          onSubmitEditing={run}
          placeholder="/give login 100"
          placeholderTextColor={colors.textDim}
          autoCapitalize="none"
          style={[styles.input, { backgroundColor: colors.surfaceAlt, borderColor: colors.border, color: colors.text }]}
        />
        <TouchableOpacity
          onPress={run}
          disabled={sending}
          style={[styles.sendBtn, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}
        >
          <Text style={{ color: colors.text, fontWeight: '600' }}>➤</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

function LogsTab({ token }) {
  const { colors } = useAppTheme();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    api
      .adminLogs(token)
      .then((data) => setLogs(data.logs || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(load, [load]);

  if (loading) return <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />;

  return (
    <FlatList
      contentContainerStyle={{ padding: 16 }}
      data={logs}
      keyExtractor={(item) => String(item.id)}
      onRefresh={load}
      refreshing={loading}
      ListEmptyComponent={<Text style={{ color: colors.textDim, textAlign: 'center' }}>Пусто</Text>}
      renderItem={({ item }) => (
        <View style={[styles.logRow, { borderBottomColor: colors.border }]}>
          <Text style={{ color: colors.textDim, fontSize: 11 }}>
            {item.admin_login} · {new Date(item.created_at).toLocaleString('ru-RU')}
          </Text>
          <Text style={{ color: colors.text, fontSize: 13, fontFamily: 'monospace', marginTop: 2 }}>
            {item.command}
          </Text>
          <Text style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>{item.result}</Text>
        </View>
      )}
    />
  );
}

function TicketsTab({ token }) {
  const { colors } = useAppTheme();
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    api
      .adminSupportTickets(token)
      .then((data) => setTickets(data.tickets || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(load, [load]);

  if (loading) return <ActivityIndicator style={{ marginTop: 20 }} color={colors.text} />;

  return (
    <FlatList
      contentContainerStyle={{ padding: 16 }}
      data={tickets}
      keyExtractor={(item) => String(item.id)}
      onRefresh={load}
      refreshing={loading}
      ListEmptyComponent={<Text style={{ color: colors.textDim, textAlign: 'center' }}>Обращений нет</Text>}
      renderItem={({ item }) => (
        <View style={[styles.logRow, { borderBottomColor: colors.border }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: colors.text, fontWeight: '600', fontSize: 13 }}>
              {item.login} {item.subject ? `· ${item.subject}` : ''}
            </Text>
            <Text style={{ color: colors.textDim, fontSize: 11 }}>{item.status}</Text>
          </View>
          <Text style={{ color: colors.textDim, fontSize: 13, marginTop: 4 }}>{item.message}</Text>
          <Text style={{ color: colors.textDim, fontSize: 11, marginTop: 4 }}>
            {new Date(item.created_at).toLocaleString('ru-RU')}
          </Text>
        </View>
      )}
    />
  );
}

export default function AdminScreen({ token }) {
  const { colors } = useAppTheme();
  const [segment, setSegment] = useState('console');

  return (
    <View style={{ flex: 1 }}>
      <View style={[styles.segmentRow, { borderBottomColor: colors.border }]}>
        {SEGMENTS.map((s) => (
          <TouchableOpacity
            key={s.key}
            onPress={() => setSegment(s.key)}
            style={[
              styles.segmentBtn,
              segment === s.key && { backgroundColor: colors.surfaceAlt, borderColor: colors.border },
            ]}
          >
            <Text style={{ color: segment === s.key ? colors.text : colors.textDim, fontSize: 13, fontWeight: segment === s.key ? '700' : '400' }}>
              {s.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {segment === 'console' && <ConsoleTab token={token} />}
      {segment === 'logs' && <LogsTab token={token} />}
      {segment === 'tickets' && <TicketsTab token={token} />}
    </View>
  );
}

const styles = StyleSheet.create({
  segmentRow: { flexDirection: 'row', paddingHorizontal: 12, paddingTop: 12, paddingBottom: 8, gap: 8, borderBottomWidth: 1 },
  segmentBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 10, borderWidth: 1, borderColor: 'transparent' },
  inputRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 8, borderTopWidth: 1 },
  input: { flex: 1, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
  sendBtn: { marginLeft: 8, borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10 },
  logRow: { paddingVertical: 10, borderBottomWidth: 1 },
});
