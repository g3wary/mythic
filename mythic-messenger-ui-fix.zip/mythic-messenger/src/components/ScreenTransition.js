import React, { useRef, useEffect } from 'react';
import { Animated, Easing, StyleSheet } from 'react-native';

// Лёгкая замена push-перехода без react-navigation: экран въезжает справа с лёгким
// фейдом при монтировании. Работает с любой моделью навигации, где компонент
// экрана монтируется/размонтируется по условию (как в этом проекте).
export default function ScreenTransition({ children, distance = 36, duration = 260 }) {
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(progress, {
      toValue: 1,
      duration,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, []);

  const translateX = progress.interpolate({ inputRange: [0, 1], outputRange: [distance, 0] });
  const opacity = progress;

  return (
    <Animated.View style={[styles.fill, { opacity, transform: [{ translateX }] }]}>
      {children}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
});
