import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Linking } from 'react-native';
import { Video, Audio } from 'expo-av';
import { useAppTheme } from '../context/ThemeContext';
import { resolveMediaUrl } from '../api';

function parseAttachment(content) {
  try {
    return JSON.parse(content);
  } catch {
    return null;
  }
}

function formatSize(bytes) {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

function formatDuration(ms) {
  if (!ms) return '';
  const totalSec = Math.round(ms / 1000);
  const min = Math.floor(totalSec / 60);
  const sec = totalSec % 60;
  return `${min}:${String(sec).padStart(2, '0')}`;
}

function VoicePlayer({ url, duration }) {
  const { colors } = useAppTheme();
  const soundRef = useRef(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => () => {
    soundRef.current?.unloadAsync();
  }, []);

  const toggle = async () => {
    if (playing) {
      await soundRef.current?.pauseAsync();
      setPlaying(false);
      return;
    }
    if (!soundRef.current) {
      const { sound } = await Audio.Sound.createAsync(
        { uri: resolveMediaUrl(url) },
        { shouldPlay: true },
        (status) => {
          if (status.didJustFinish) {
            setPlaying(false);
            soundRef.current?.setPositionAsync(0);
          }
        }
      );
      soundRef.current = sound;
    } else {
      await soundRef.current.playAsync();
    }
    setPlaying(true);
  };

  return (
    <TouchableOpacity onPress={toggle} style={styles.voiceRow}>
      <View style={[styles.playBtn, { backgroundColor: colors.border }]}>
        <Text style={{ color: colors.text }}>{playing ? '⏸' : '▶'}</Text>
      </View>
      <Text style={{ color: colors.text, fontSize: 13 }}>Голосовое · {formatDuration(duration)}</Text>
    </TouchableOpacity>
  );
}

export default function MessageContent({ msgType, content }) {
  const { colors } = useAppTheme();

  if (msgType === 'text' || !msgType) {
    return <Text style={{ color: colors.text, fontSize: 15 }}>{content}</Text>;
  }

  const attachment = parseAttachment(content);
  if (!attachment) {
    return <Text style={{ color: colors.text, fontSize: 15 }}>{content}</Text>;
  }

  const url = resolveMediaUrl(attachment.url);

  if (msgType === 'image') {
    return <Image source={{ uri: url }} style={styles.image} resizeMode="cover" />;
  }

  if (msgType === 'sticker') {
    if (attachment.isAnimated) {
      return (
        <Video
          source={{ uri: url }}
          style={styles.sticker}
          resizeMode="contain"
          isLooping
          shouldPlay
          isMuted
          useNativeControls={false}
        />
      );
    }
    return <Image source={{ uri: url }} style={styles.sticker} resizeMode="contain" />;
  }

  if (msgType === 'video') {
    return (
      <Video
        source={{ uri: url }}
        style={styles.video}
        useNativeControls
        resizeMode="contain"
      />
    );
  }

  if (msgType === 'voice') {
    return <VoicePlayer url={attachment.url} duration={attachment.duration} />;
  }

  // file / audio (музыка и прочие документы)
  return (
    <TouchableOpacity onPress={() => Linking.openURL(url)} style={styles.fileRow}>
      <View style={[styles.fileIcon, { backgroundColor: colors.border }]}>
        <Text>{msgType === 'audio' ? '🎵' : '📄'}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ color: colors.text, fontSize: 14 }} numberOfLines={1}>
          {attachment.name || 'Файл'}
        </Text>
        <Text style={{ color: colors.textDim, fontSize: 12 }}>{formatSize(attachment.size)}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  image: { width: 200, height: 200, borderRadius: 10 },
  sticker: { width: 128, height: 128 },
  video: { width: 220, height: 220, borderRadius: 10, backgroundColor: '#000' },
  voiceRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 2 },
  playBtn: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  fileRow: { flexDirection: 'row', alignItems: 'center', gap: 10, minWidth: 160 },
  fileIcon: { width: 34, height: 34, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
});
