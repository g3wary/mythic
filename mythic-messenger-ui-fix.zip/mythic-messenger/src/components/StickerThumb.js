import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { Video } from 'expo-av';
import { resolveMediaUrl } from '../api';

export default function StickerThumb({ url, watermarkUsername, size = 84, isAnimated = false }) {
  return (
    <View style={[styles.wrap, { width: size, height: size }]}>
      {isAnimated ? (
        <Video
          source={{ uri: resolveMediaUrl(url) }}
          style={{ width: size, height: size, borderRadius: 10 }}
          resizeMode="cover"
          isLooping
          shouldPlay
          isMuted
          useNativeControls={false}
        />
      ) : (
        <Image source={{ uri: resolveMediaUrl(url) }} style={{ width: size, height: size, borderRadius: 10 }} resizeMode="cover" />
      )}
      {watermarkUsername ? (
        <View style={styles.watermarkOverlay} pointerEvents="none">
          <Text style={styles.watermarkText} numberOfLines={1}>
            @{watermarkUsername}
          </Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { borderRadius: 10, overflow: 'hidden' },
  watermarkOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingVertical: 3,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
  },
  watermarkText: { color: '#fff', fontSize: 10, fontWeight: '600' },
});
