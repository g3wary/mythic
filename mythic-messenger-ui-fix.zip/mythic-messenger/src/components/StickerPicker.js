import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, ScrollView, ActivityIndicator, StyleSheet } from 'react-native';
import { api } from '../api';
import StickerThumb from './StickerThumb';

export default function StickerPicker({ visible, token, colors, onClose, onPick }) {
  const [packs, setPacks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!visible) return;
    setLoading(true);
    api
      .getStickerCollection(token)
      .then((data) => setPacks(data.packs || []))
      .catch(() => setPacks([]))
      .finally(() => setLoading(false));
  }, [visible, token]);

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={onClose}>
        <View style={[styles.sheet, { backgroundColor: colors.surface, borderColor: colors.border }]} onStartShouldSetResponder={() => true}>
          <Text style={{ color: colors.text, fontWeight: '700', fontSize: 15, marginBottom: 10 }}>Стикеры</Text>
          {loading ? (
            <ActivityIndicator color={colors.text} />
          ) : packs.length === 0 ? (
            <Text style={{ color: colors.textDim, fontSize: 13 }}>
              В коллекции пока пусто. Добавь стикеры в Настройках → Mythic Sticker Studio.
            </Text>
          ) : (
            <ScrollView style={{ maxHeight: 320 }}>
              {packs.map((pack) => (
                <View key={pack.id} style={{ marginBottom: 14 }}>
                  <Text style={{ color: colors.textDim, fontSize: 12, marginBottom: 6 }}>{pack.name}</Text>
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                    {pack.stickers.map((s) => (
                      <TouchableOpacity
                        key={s.id}
                        onPress={() => onPick({ packId: pack.id, url: s.url, isAnimated: pack.isAnimated })}
                      >
                        <StickerThumb url={s.url} size={64} isAnimated={pack.isAnimated} watermarkUsername={pack.needsWatermark ? pack.owner.username : null} />
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              ))}
            </ScrollView>
          )}
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 18, borderTopRightRadius: 18, borderWidth: 1, padding: 20, paddingBottom: 30 },
});
