import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { ThemeProvider, useAppTheme } from './src/context/ThemeContext';
import { SocketProvider } from './src/context/SocketContext';
import { E2EProvider } from './src/context/E2EContext';
import OnboardingScreen from './src/screens/OnboardingScreen';
import AuthScreen from './src/screens/AuthScreen';
import HomeShell from './src/screens/HomeShell';

function Root() {
  const { mode } = useAppTheme();
  const [stage, setStage] = useState('onboarding'); // onboarding -> auth -> home
  const [user, setUser] = useState(null);

  return (
    <>
      <StatusBar style={mode === 'gray' ? 'light' : 'dark'} />
      {stage === 'onboarding' && <OnboardingScreen onDone={() => setStage('auth')} />}
      {stage === 'auth' && (
        <AuthScreen
          onAuthenticated={(u) => {
            setUser(u);
            setStage('home');
          }}
        />
      )}
      {stage === 'home' && user && (
        <SocketProvider token={user.token}>
          <E2EProvider token={user.token} login={user.login} publicKeyOnServer={user.publicKey}>
            <HomeShell
              user={user}
              token={user.token}
              onUserUpdate={(patch) => setUser((prev) => ({ ...prev, ...patch }))}
            />
          </E2EProvider>
        </SocketProvider>
      )}
    </>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <Root />
    </ThemeProvider>
  );
}
