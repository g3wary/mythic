const express = require('express');
const db = require('../db');
const { auth, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(auth, requireAdmin);

function logCommand(adminId, command, result) {
  db.prepare('INSERT INTO admin_logs (admin_id, command, result) VALUES (?, ?, ?)').run(
    adminId,
    command,
    typeof result === 'string' ? result : JSON.stringify(result)
  );
}

function findUserByLoginOrWallet(token) {
  return (
    db.prepare('SELECT * FROM users WHERE login = ?').get(token) ||
    db.prepare('SELECT * FROM users WHERE wallet_id = ?').get(token)
  );
}

// Команды: /give <wallet|login> <amount> | /ban <login> | /unban <login>
// /repup <login> <amount> | /repdown <login> <amount> | /verify <login>
// /checkmark <login> on|off
router.post('/console', (req, res) => {
  const raw = String(req.body?.command || '').trim();
  if (!raw.startsWith('/')) {
    return res.status(400).json({ error: 'Команда должна начинаться с /' });
  }
  const [cmd, ...args] = raw.slice(1).split(/\s+/);

  try {
    switch (cmd) {
      case 'give': {
        const [target, amountStr] = args;
        const amount = Number(amountStr);
        const user = findUserByLoginOrWallet(target);
        if (!user) return respond(404, 'Пользователь/кошелёк не найден');
        if (!amount || amount <= 0) return respond(400, 'Некорректная сумма');
        db.prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?').run(
          amount,
          user.id
        );
        return respond(200, `Начислено ${amount} мификов на ${user.wallet_id} (${user.login})`);
      }
      case 'ban': {
        const user = findUserByLoginOrWallet(args[0]);
        if (!user) return respond(404, 'Пользователь не найден');
        db.prepare('UPDATE users SET is_banned = 1 WHERE id = ?').run(user.id);
        return respond(200, `Пользователь ${user.login} забанен`);
      }
      case 'unban': {
        const user = findUserByLoginOrWallet(args[0]);
        if (!user) return respond(404, 'Пользователь не найден');
        db.prepare('UPDATE users SET is_banned = 0 WHERE id = ?').run(user.id);
        return respond(200, `Пользователь ${user.login} разбанен`);
      }
      case 'repup':
      case 'repdown': {
        const [target, amountStr] = args;
        const amount = Number(amountStr);
        const user = findUserByLoginOrWallet(target);
        if (!user) return respond(404, 'Пользователь не найден');
        if (!amount || amount <= 0) return respond(400, 'Некорректное значение');
        const delta = cmd === 'repup' ? amount : -amount;
        const newRep = Math.min(100, Math.max(0, user.reputation + delta));
        db.prepare('UPDATE users SET reputation = ? WHERE id = ?').run(newRep, user.id);
        return respond(200, `Репутация ${user.login} теперь ${newRep}%`);
      }
      case 'pro': {
        const [target, state, daysStr] = args;
        const user = findUserByLoginOrWallet(target);
        if (!user) return respond(404, 'Пользователь не найден');
        if (state === 'off') {
          db.prepare('UPDATE users SET is_pro = 0, pro_expires_at = NULL WHERE id = ?').run(user.id);
          return respond(200, `Mythic Pro у ${user.login} отключён`);
        }
        const days = Number(daysStr) || 30;
        const expiry = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
        db.prepare('UPDATE users SET is_pro = 1, pro_expires_at = ? WHERE id = ?').run(expiry, user.id);
        return respond(200, `Mythic Pro для ${user.login} активен до ${expiry}`);
      }
      case 'emailcode': {
        const [target, code] = args;
        const user = findUserByLoginOrWallet(target);
        if (!user) return respond(404, 'Пользователь не найден');
        if (!user.pending_email) return respond(400, `У ${user.login} нет заявки на привязку почты`);
        if (!code) return respond(400, 'Укажи код');
        db.prepare('UPDATE users SET email_code = ? WHERE id = ?').run(code, user.id);
        return respond(200, `Код для ${user.login} (${user.pending_email}) сохранён — сообщи ему код лично`);
      }
      case 'verify': {
        const user = findUserByLoginOrWallet(args[0]);
        if (!user) return respond(404, 'Пользователь не найден');
        db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(user.id);
        return respond(200, `Почта ${user.login} подтверждена`);
      }
      case 'checkmark': {
        const [target, state] = args;
        const user = findUserByLoginOrWallet(target);
        if (!user) return respond(404, 'Пользователь не найден');
        const on = state === 'on';
        db.prepare('UPDATE users SET has_checkmark = ? WHERE id = ?').run(on ? 1 : 0, user.id);
        return respond(200, `Галочка у ${user.login}: ${on ? 'выдана' : 'снята'}`);
      }
      default:
        return respond(400, `Неизвестная команда: /${cmd}`);
    }
  } catch (e) {
    logCommand(req.user.id, raw, `error: ${e.message}`);
    return res.status(500).json({ error: 'Ошибка выполнения команды' });
  }

  function respond(status, message) {
    logCommand(req.user.id, raw, message);
    res.status(status).json({ result: message });
  }
});

router.get('/logs', (req, res) => {
  const logs = db
    .prepare(
      `SELECT admin_logs.*, users.login as admin_login FROM admin_logs
       JOIN users ON users.id = admin_logs.admin_id
       ORDER BY admin_logs.created_at DESC LIMIT 200`
    )
    .all();
  res.json({ logs });
});

router.get('/support-tickets', (req, res) => {
  const tickets = db
    .prepare(
      `SELECT support_tickets.*, users.login FROM support_tickets
       JOIN users ON users.id = support_tickets.user_id
       ORDER BY support_tickets.created_at DESC`
    )
    .all();
  res.json({ tickets });
});

module.exports = router;
