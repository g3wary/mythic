const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');
const { isProActive } = require('./pro');

const router = express.Router();

function extractHashtags(text) {
  if (!text) return [];
  const matches = text.match(/#([\p{L}0-9_]+)/gu) || [];
  const tags = matches.map((t) => t.slice(1).toLowerCase());
  return [...new Set(tags)];
}

function getHashtags(postId) {
  return db
    .prepare('SELECT tag FROM post_hashtags WHERE post_id = ?')
    .all(postId)
    .map((r) => r.tag);
}

// Возвращает данные "лица", от которого выложен пост: сам автор, либо (для Mythic Pro)
// бот/группа/канал, которым автор владеет.
function resolveDisplayedAuthor(post) {
  if (post.author_kind === 'bot' && post.author_ref_id) {
    const bot = db.prepare('SELECT login, username FROM users WHERE id = ? AND is_bot = 1').get(post.author_ref_id);
    if (bot) return { kind: 'bot', login: bot.login, username: bot.username };
  }
  if (post.author_kind === 'community' && post.author_ref_id) {
    const community = db.prepare('SELECT id, name, type FROM communities WHERE id = ?').get(post.author_ref_id);
    if (community) return { kind: 'community', communityId: community.id, name: community.name, communityType: community.type };
  }
  const user = db.prepare('SELECT login, username FROM users WHERE id = ?').get(post.author_id);
  return { kind: 'user', login: user?.login, username: user?.username };
}

function serialize(post) {
  return {
    id: post.id,
    author: resolveDisplayedAuthor(post),
    content: post.content,
    attachmentUrl: post.attachment_url,
    attachmentType: post.attachment_type,
    attachmentName: post.attachment_name,
    attachmentSize: post.attachment_size,
    hashtags: getHashtags(post.id),
    hidden: !!post.hidden,
    createdAt: post.created_at,
  };
}

// Проверяет право текущего пользователя постить как бот/группа/канал — только Mythic Pro
// и только если он реально владелец этой сущности.
function resolvePostingAs(req, asKind, asId) {
  if (!asKind || asKind === 'user') return { kind: 'user', refId: null };

  if (!isProActive(req.user)) {
    throw Object.assign(new Error('Публикация от имени бота/группы/канала доступна только с Mythic Pro'), { status: 402 });
  }

  if (asKind === 'bot') {
    const bot = db.prepare('SELECT * FROM users WHERE id = ? AND is_bot = 1 AND bot_owner_id = ?').get(asId, req.user.id);
    if (!bot) throw Object.assign(new Error('Бот не найден или тебе не принадлежит'), { status: 404 });
    return { kind: 'bot', refId: bot.id };
  }

  if (asKind === 'community') {
    const membership = db
      .prepare("SELECT role FROM community_members WHERE community_id = ? AND user_id = ? AND role IN ('owner','co_owner')")
      .get(asId, req.user.id);
    if (!membership) throw Object.assign(new Error('Постить от имени этой группы/канала можно только владельцу или совладельцу'), { status: 403 });
    return { kind: 'community', refId: Number(asId) };
  }

  throw Object.assign(new Error('Неизвестный тип автора'), { status: 400 });
}

// Создать пост
router.post('/', auth, (req, res) => {
  const { content, attachmentUrl, attachmentType, attachmentName, attachmentSize, asKind, asId } = req.body || {};
  if (!content?.trim() && !attachmentUrl) {
    return res.status(400).json({ error: 'Пост не может быть пустым' });
  }

  let postingAs;
  try {
    postingAs = resolvePostingAs(req, asKind, asId);
  } catch (e) {
    return res.status(e.status || 400).json({ error: e.message });
  }

  const hashtags = extractHashtags(content);

  const create = db.transaction(() => {
    const info = db
      .prepare(
        `INSERT INTO posts (author_id, content, attachment_url, attachment_type, attachment_name, attachment_size, author_kind, author_ref_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        req.user.id,
        content?.trim() || null,
        attachmentUrl || null,
        attachmentType || null,
        attachmentName || null,
        attachmentSize || null,
        postingAs.kind,
        postingAs.refId
      );

    const insertTag = db.prepare('INSERT INTO post_hashtags (post_id, tag) VALUES (?, ?)');
    hashtags.forEach((tag) => insertTag.run(info.lastInsertRowid, tag));

    return info.lastInsertRowid;
  });

  const id = create();
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(id);
  res.status(201).json(serialize(post));
});

// Публичная лента: ?hashtag=xxx фильтрует по хештегу, ?author=login — посты конкретного автора
// ?before=<id> — пагинация "загрузить ещё" (посты старше указанного id)
router.get('/', auth, (req, res) => {
  const { hashtag, author, before } = req.query;
  const conditions = ['posts.hidden = 0'];
  const params = [];

  if (author) {
    const authorUser = db.prepare('SELECT id, is_bot FROM users WHERE login = ?').get(author);
    if (authorUser?.is_bot) {
      conditions.push('posts.author_kind = ? AND posts.author_ref_id = ?');
      params.push('bot', authorUser.id);
    } else {
      conditions.push("posts.author_id = ? AND (posts.author_kind = 'user' OR posts.author_kind IS NULL)");
      params.push(authorUser ? authorUser.id : -1);
    }
  }
  if (before) {
    conditions.push('posts.id < ?');
    params.push(Number(before));
  }

  let sql = `SELECT posts.* FROM posts`;
  if (hashtag) {
    sql += ` JOIN post_hashtags ON post_hashtags.post_id = posts.id AND post_hashtags.tag = ?`;
    params.unshift(String(hashtag).toLowerCase());
  }
  sql += ` WHERE ${conditions.join(' AND ')} ORDER BY posts.created_at DESC, posts.id DESC LIMIT 30`;

  const rows = db.prepare(sql).all(...params);
  res.json({ posts: rows.map(serialize) });
});

// Мои посты — включая скрытые, для экрана управления. Отдаёт и посты, выложенные от
// имени своих ботов/групп/каналов (author_id всё равно остаётся реальным автором).
router.get('/mine', auth, (req, res) => {
  const rows = db
    .prepare('SELECT * FROM posts WHERE author_id = ? ORDER BY created_at DESC, id DESC')
    .all(req.user.id);
  res.json({ posts: rows.map(serialize) });
});

router.get('/:id', auth, (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'Пост не найден' });
  res.json(serialize(post));
});

// Скрыть/показать свой пост
router.patch('/:id', auth, (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'Пост не найден' });
  if (post.author_id !== req.user.id) return res.status(403).json({ error: 'Это не твой пост' });

  const { hidden } = req.body || {};
  if (typeof hidden === 'boolean') {
    db.prepare('UPDATE posts SET hidden = ? WHERE id = ?').run(hidden ? 1 : 0, post.id);
  }

  const updated = db.prepare('SELECT * FROM posts WHERE id = ?').get(post.id);
  res.json(serialize(updated));
});

router.delete('/:id', auth, (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'Пост не найден' });
  if (post.author_id !== req.user.id) return res.status(403).json({ error: 'Это не твой пост' });

  const del = db.transaction(() => {
    db.prepare('DELETE FROM post_hashtags WHERE post_id = ?').run(post.id);
    db.prepare('DELETE FROM posts WHERE id = ?').run(post.id);
  });
  del();

  res.json({ ok: true });
});

module.exports = router;
