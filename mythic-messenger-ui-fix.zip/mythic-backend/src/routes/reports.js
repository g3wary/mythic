const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');

const router = express.Router();

// Пожаловаться на пользователя: -0.5% репутации, 1 жалоба с аккаунта на цель
router.post('/', auth, (req, res) => {
  const { targetLogin, reason } = req.body || {};
  if (!targetLogin) return res.status(400).json({ error: 'Укажи логин пользователя' });

  const target = db.prepare('SELECT * FROM users WHERE login = ?').get(targetLogin);
  if (!target) return res.status(404).json({ error: 'Пользователь не найден' });
  if (target.id === req.user.id) return res.status(400).json({ error: 'Нельзя пожаловаться на себя' });

  const already = db
    .prepare('SELECT id FROM reports WHERE reporter_id = ? AND target_id = ?')
    .get(req.user.id, target.id);
  if (already) return res.status(409).json({ error: 'Ты уже жаловался на этого пользователя' });

  const runReport = db.transaction(() => {
    db.prepare(
      'INSERT INTO reports (reporter_id, target_id, reason) VALUES (?, ?, ?)'
    ).run(req.user.id, target.id, reason || null);

    const newRep = Math.max(0, target.reputation - 0.5);
    db.prepare(
      "UPDATE users SET reputation = ?, last_reputation_hit_at = datetime('now') WHERE id = ?"
    ).run(newRep, target.id);
  });

  runReport();
  res.status(201).json({ ok: true });
});

// Ежедневное восстановление репутации: если за сутки не было новых жалоб — +1%
// Вызывается по крону на сервере (см. README), не напрямую пользователем
router.post('/reputation/tick', auth, (req, res) => {
  if (!req.user.is_admin) return res.status(403).json({ error: 'Только для администратора / крона' });

  const affected = db
    .prepare(
      `UPDATE users
       SET reputation = MIN(100, reputation + 1)
       WHERE reputation < 100
         AND (last_reputation_hit_at IS NULL OR last_reputation_hit_at < datetime('now', '-1 day'))`
    )
    .run();

  res.json({ updated: affected.changes });
});

module.exports = router;
