const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { auth } = require('../middleware/auth');

const router = express.Router();

function publicUser(u) {
  return {
    id: u.id,
    login: u.login,
    username: u.username,
    age: u.age,
    walletId: u.wallet_id,
    walletBalance: u.wallet_balance,
    reputation: u.reputation,
    isAdmin: !!u.is_admin,
    hasCheckmark: !!u.has_checkmark,
    email: u.email,
    emailVerified: !!u.email_verified,
    pendingEmail: u.pending_email,
    avatarUrl: u.avatar_url,
    publicKey: u.public_key,
  };
}

// Смена логина/юзернейма/пароля/аватарки. Пароль меняется только с указанием текущего.
router.patch('/profile', auth, (req, res) => {
  const { login, username, newPassword, currentPassword, avatarUrl } = req.body || {};

  if (login && login !== req.user.login) {
    const taken = db.prepare('SELECT id FROM users WHERE login = ? AND id != ?').get(login, req.user.id);
    if (taken) return res.status(409).json({ error: 'Такой логин уже занят' });
  }
  if (username && username !== req.user.username) {
    const taken = db.prepare('SELECT id FROM users WHERE username = ? AND id != ?').get(username, req.user.id);
    if (taken) return res.status(409).json({ error: 'Такой юзернейм уже занят' });
  }

  let newHash = null;
  if (newPassword) {
    if (!currentPassword || !bcrypt.compareSync(currentPassword, req.user.password_hash)) {
      return res.status(403).json({ error: 'Текущий пароль указан неверно' });
    }
    if (String(newPassword).length < 6) {
      return res.status(400).json({ error: 'Новый пароль должен быть от 6 символов' });
    }
    newHash = bcrypt.hashSync(newPassword, 10);
  }

  db.prepare(
    `UPDATE users SET
       login = COALESCE(?, login),
       username = COALESCE(?, username),
       password_hash = COALESCE(?, password_hash),
       avatar_url = COALESCE(?, avatar_url)
     WHERE id = ?`
  ).run(login || null, username || null, newHash, avatarUrl || null, req.user.id);

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json(publicUser(updated));
});

// Шаг 1: пользователь запрашивает привязку почты.
// Заявка падает администрации через тикет техподдержки — админ вручную отправляет код
// со своей почты и вбивает его в консоль командой /emailcode <login> <code>.
router.post('/email/request', auth, (req, res) => {
  const { email } = req.body || {};
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Укажи корректный email' });
  }

  db.prepare('UPDATE users SET pending_email = ?, email_code = NULL WHERE id = ?').run(
    email,
    req.user.id
  );
  db.prepare(
    `INSERT INTO support_tickets (user_id, subject, message) VALUES (?, ?, ?)`
  ).run(
    req.user.id,
    'Привязка почты',
    `Запрос на привязку почты ${email}. Отправь код на эту почту и выполни в консоли: /emailcode ${req.user.login} <код>`
  );

  res.json({ ok: true });
});

// Шаг 2: пользователь вводит код, который админ отправил ему на почту
router.post('/email/confirm', auth, (req, res) => {
  const { code } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (!user.pending_email) {
    return res.status(400).json({ error: 'Сначала запроси привязку почты' });
  }
  if (!user.email_code) {
    return res.status(400).json({ error: 'Администратор ещё не выслал код — подожди' });
  }
  if (String(code).trim() !== user.email_code) {
    return res.status(400).json({ error: 'Неверный код' });
  }

  db.prepare(
    `UPDATE users SET email = pending_email, email_verified = 1, pending_email = NULL, email_code = NULL WHERE id = ?`
  ).run(req.user.id);

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json(publicUser(updated));
});

// Публичный ключ E2E-шифрования (X25519). Приватный ключ никогда не покидает устройство.
router.post('/public-key', auth, (req, res) => {
  const { publicKey } = req.body || {};
  if (!publicKey || typeof publicKey !== 'string') {
    return res.status(400).json({ error: 'Укажи publicKey' });
  }
  db.prepare('UPDATE users SET public_key = ? WHERE id = ?').run(publicKey, req.user.id);
  res.json({ ok: true });
});

module.exports = { router, publicUser };
