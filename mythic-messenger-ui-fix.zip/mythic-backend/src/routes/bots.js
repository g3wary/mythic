const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../db');
const { auth } = require('../middleware/auth');
const { generateWalletId, generateBotToken } = require('../utils/wallet');

const router = express.Router();

function serialize(bot) {
  return {
    id: bot.id,
    login: bot.login,
    username: bot.username,
    description: bot.bot_description,
    avatarUrl: bot.avatar_url,
    token: bot.bot_token,
    walletId: bot.wallet_id,
    createdAt: bot.created_at,
  };
}

// Создать бота: имя (username), описание, юзернейм (login, например mythic123botik)
router.post('/', auth, (req, res) => {
  const { name, description, username } = req.body || {};
  if (!name?.trim() || !username?.trim()) {
    return res.status(400).json({ error: 'Укажи имя бота и юзернейм' });
  }

  const login = username.trim().replace(/^@/, '');
  if (!/^[a-zA-Z0-9_]{3,32}$/.test(login)) {
    return res.status(400).json({ error: 'Юзернейм бота: только латиница, цифры и _, от 3 до 32 символов' });
  }

  const taken = db.prepare('SELECT id FROM users WHERE login = ? OR username = ?').get(login, login);
  if (taken) return res.status(409).json({ error: 'Такой юзернейм уже занят' });

  const token = generateBotToken();
  // Пароль боту не нужен — он никогда не логинится обычным способом, но поле NOT NULL в схеме
  const dummyHash = bcrypt.hashSync(crypto.randomBytes(24).toString('hex'), 10);
  const walletId = generateWalletId();

  const info = db
    .prepare(
      `INSERT INTO users (login, username, password_hash, age, wallet_id, is_bot, bot_owner_id, bot_token, bot_description)
       VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)`
    )
    .run(login, name.trim(), dummyHash, 0, walletId, req.user.id, token, description || null);

  const bot = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(serialize(bot));
});

router.get('/mine', auth, (req, res) => {
  const rows = db.prepare('SELECT * FROM users WHERE is_bot = 1 AND bot_owner_id = ?').all(req.user.id);
  res.json({ bots: rows.map(serialize) });
});

function getOwnedBot(id, ownerId) {
  return db.prepare('SELECT * FROM users WHERE id = ? AND is_bot = 1 AND bot_owner_id = ?').get(id, ownerId);
}

// Сменить юзернейм / ник / описание / аватарку
router.patch('/:id', auth, (req, res) => {
  const bot = getOwnedBot(req.params.id, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Бот не найден' });

  const { username, nickname, description, avatarUrl } = req.body || {};

  if (username) {
    const login = username.trim().replace(/^@/, '');
    if (!/^[a-zA-Z0-9_]{3,32}$/.test(login)) {
      return res.status(400).json({ error: 'Юзернейм бота: только латиница, цифры и _, от 3 до 32 символов' });
    }
    const taken = db.prepare('SELECT id FROM users WHERE login = ? AND id != ?').get(login, bot.id);
    if (taken) return res.status(409).json({ error: 'Такой юзернейм уже занят' });
    db.prepare('UPDATE users SET login = ? WHERE id = ?').run(login, bot.id);
  }

  db.prepare(
    `UPDATE users SET
       username = COALESCE(?, username),
       bot_description = COALESCE(?, bot_description),
       avatar_url = COALESCE(?, avatar_url)
     WHERE id = ?`
  ).run(nickname?.trim() || null, description ?? null, avatarUrl || null, bot.id);

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(bot.id);
  res.json(serialize(updated));
});

router.post('/:id/regenerate-token', auth, (req, res) => {
  const bot = getOwnedBot(req.params.id, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Бот не найден' });

  const token = generateBotToken();
  db.prepare('UPDATE users SET bot_token = ? WHERE id = ?').run(token, bot.id);
  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(bot.id);
  res.json(serialize(updated));
});

// Удалить бота целиком, вместе с его перепиской и постами
router.delete('/:id', auth, (req, res) => {
  const bot = getOwnedBot(req.params.id, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Бот не найден' });

  const del = db.transaction(() => {
    db.prepare('DELETE FROM messages WHERE from_id = ? OR to_id = ?').run(bot.id, bot.id);
    db.prepare('DELETE FROM community_members WHERE user_id = ?').run(bot.id);
    db.prepare('DELETE FROM community_messages WHERE from_id = ?').run(bot.id);
    const postIds = db.prepare('SELECT id FROM posts WHERE author_id = ?').all(bot.id).map((p) => p.id);
    postIds.forEach((pid) => db.prepare('DELETE FROM post_hashtags WHERE post_id = ?').run(pid));
    db.prepare('DELETE FROM posts WHERE author_id = ?').run(bot.id);
    db.prepare('DELETE FROM blocks WHERE blocker_id = ? OR blocked_id = ?').run(bot.id, bot.id);
    db.prepare('DELETE FROM users WHERE id = ?').run(bot.id);
  });
  del();

  res.json({ ok: true });
});

module.exports = router;
