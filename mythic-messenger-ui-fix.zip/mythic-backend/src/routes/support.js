const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');

const router = express.Router();

router.post('/', auth, (req, res) => {
  const { subject, message } = req.body || {};
  if (!message) return res.status(400).json({ error: 'Опиши свою проблему или запрос' });

  const info = db
    .prepare('INSERT INTO support_tickets (user_id, subject, message) VALUES (?, ?, ?)')
    .run(req.user.id, subject || null, message);

  res.status(201).json({ id: info.lastInsertRowid });
});

router.get('/mine', auth, (req, res) => {
  const tickets = db
    .prepare('SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC')
    .all(req.user.id);
  res.json({ tickets });
});

module.exports = router;
