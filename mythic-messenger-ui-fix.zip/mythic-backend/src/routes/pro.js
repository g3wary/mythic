const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');
const { generateTxId } = require('../utils/wallet');

const router = express.Router();

const PRICE = Number(process.env.PRO_PRICE_MIFIKS || 500);
const DURATION_DAYS = Number(process.env.PRO_DURATION_DAYS || 30);

function status(user) {
  const active = !!user.is_pro && user.pro_expires_at && new Date(user.pro_expires_at) > new Date();
  return {
    isPro: active,
    expiresAt: active ? user.pro_expires_at : null,
    price: PRICE,
    durationDays: DURATION_DAYS,
  };
}

router.get('/status', auth, (req, res) => {
  res.json(status(req.user));
});

// Оплата подпиской продлевает от текущей даты истечения, если подписка ещё активна,
// либо от сейчас, если она истекла или отсутствует — покупка впрок не теряется
router.post('/subscribe', auth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (user.wallet_balance < PRICE) {
    return res.status(400).json({ error: `Недостаточно мификов. Нужно ${PRICE}, на балансе ${user.wallet_balance}` });
  }

  const currentExpiry = user.pro_expires_at && new Date(user.pro_expires_at) > new Date() ? new Date(user.pro_expires_at) : new Date();
  const newExpiry = new Date(currentExpiry.getTime() + DURATION_DAYS * 24 * 60 * 60 * 1000);
  const txId = generateTxId();

  const run = db.transaction(() => {
    db.prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?').run(PRICE, user.id);
    db.prepare('UPDATE users SET is_pro = 1, pro_expires_at = ? WHERE id = ?').run(newExpiry.toISOString(), user.id);
    // Мифики за подписку уходят "в систему" — фиксируем как перевод на служебный кошелёк MYT-SYSTEM
    db.prepare(
      'INSERT INTO wallet_transfers (tx_id, from_wallet, to_wallet, amount) VALUES (?, ?, ?, ?)'
    ).run(txId, user.wallet_id, 'MYT-SYSTEM', PRICE);
  });
  run();

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
  res.json(status(updated));
});

module.exports = { router, isProActive: (user) => !!user.is_pro && user.pro_expires_at && new Date(user.pro_expires_at) > new Date() };
