const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');

const router = express.Router();

function publicProfile(u) {
  return {
    login: u.login,
    username: u.username,
    reputation: u.reputation,
    hasCheckmark: !!u.has_checkmark,
    avatarUrl: u.avatar_url,
    publicKey: u.public_key,
  };
}

// Поиск по логину/юзернейму для строки поиска в разделе "Чаты"
router.get('/search', auth, (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) return res.json({ users: [] });

  const rows = db
    .prepare(
      `SELECT login, username, reputation, has_checkmark FROM users
       WHERE (login LIKE ? OR username LIKE ?) AND id != ? AND is_banned = 0
       LIMIT 20`
    )
    .all(`%${q}%`, `%${q}%`, req.user.id);

  res.json({ users: rows.map(publicProfile) });
});

router.get('/:login', auth, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE login = ?').get(req.params.login);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });

  const blockedByMe = db
    .prepare('SELECT id FROM blocks WHERE blocker_id = ? AND blocked_id = ?')
    .get(req.user.id, u.id);

  res.json({ ...publicProfile(u), blockedByMe: !!blockedByMe });
});

router.post('/:login/block', auth, (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE login = ?').get(req.params.login);
  if (!target) return res.status(404).json({ error: 'Пользователь не найден' });
  if (target.id === req.user.id) return res.status(400).json({ error: 'Нельзя заблокировать себя' });

  db.prepare('INSERT OR IGNORE INTO blocks (blocker_id, blocked_id) VALUES (?, ?)').run(
    req.user.id,
    target.id
  );
  res.json({ ok: true });
});

router.delete('/:login/block', auth, (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE login = ?').get(req.params.login);
  if (!target) return res.status(404).json({ error: 'Пользователь не найден' });

  db.prepare('DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?').run(
    req.user.id,
    target.id
  );
  res.json({ ok: true });
});

module.exports = router;
