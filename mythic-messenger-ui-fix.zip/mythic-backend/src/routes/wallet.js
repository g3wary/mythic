const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');
const { generateTxId } = require('../utils/wallet');

const router = express.Router();

router.get('/me', auth, (req, res) => {
  res.json({ walletId: req.user.wallet_id, balance: req.user.wallet_balance });
});

router.get('/transfers', auth, (req, res) => {
  const rows = db
    .prepare(
      `SELECT * FROM wallet_transfers WHERE from_wallet = ? OR to_wallet = ? ORDER BY created_at DESC LIMIT 100`
    )
    .all(req.user.wallet_id, req.user.wallet_id);
  res.json({ transfers: rows });
});

router.post('/transfer', auth, (req, res) => {
  const { toWalletId, amount } = req.body || {};
  const amt = Number(amount);

  if (!toWalletId || !amt || amt <= 0) {
    return res.status(400).json({ error: 'Укажи корректный адрес кошелька и сумму' });
  }
  if (toWalletId === req.user.wallet_id) {
    return res.status(400).json({ error: 'Нельзя перевести самому себе' });
  }
  if (amt > req.user.wallet_balance) {
    return res.status(400).json({ error: 'Недостаточно мификов на балансе' });
  }

  const recipient = db.prepare('SELECT * FROM users WHERE wallet_id = ?').get(toWalletId);
  if (!recipient) {
    return res.status(404).json({ error: 'Кошелёк получателя не найден' });
  }

  const txId = generateTxId();

  const runTransfer = db.transaction(() => {
    db.prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?').run(
      amt,
      req.user.id
    );
    db.prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?').run(
      amt,
      recipient.id
    );
    db.prepare(
      'INSERT INTO wallet_transfers (tx_id, from_wallet, to_wallet, amount) VALUES (?, ?, ?, ?)'
    ).run(txId, req.user.wallet_id, toWalletId, amt);
  });

  runTransfer();

  const updated = db.prepare('SELECT wallet_balance FROM users WHERE id = ?').get(req.user.id);
  res.json({ txId, newBalance: updated.wallet_balance });
});

module.exports = router;
