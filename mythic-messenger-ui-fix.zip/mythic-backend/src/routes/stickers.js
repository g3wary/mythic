const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');
const { generateTxId } = require('../utils/wallet');
const { isProActive } = require('./pro');

const router = express.Router();

function getStickers(packId) {
  return db.prepare('SELECT * FROM stickers WHERE pack_id = ? ORDER BY id ASC').all(packId);
}

function isCollected(userId, packId) {
  return !!db.prepare('SELECT id FROM sticker_collection WHERE user_id = ? AND pack_id = ?').get(userId, packId);
}

function isPurchased(userId, packId) {
  return !!db.prepare('SELECT id FROM sticker_purchases WHERE user_id = ? AND pack_id = ?').get(userId, packId);
}

function serialize(pack, viewerId) {
  const owner = db.prepare('SELECT login, username FROM users WHERE id = ?').get(pack.owner_id);
  const isOwner = pack.owner_id === viewerId;
  const purchased = isOwner || isPurchased(viewerId, pack.id);
  // Водяной знак показываем на клиенте, если пак платный и ещё не куплен/не свой
  const needsWatermark = !!pack.is_paid && !purchased;

  return {
    id: pack.id,
    kind: pack.kind,
    name: pack.name,
    owner: { login: owner?.login, username: owner?.username },
    isPrivate: !!pack.is_private,
    isPaid: !!pack.is_paid,
    price: pack.price,
    isAnimated: !!pack.is_animated,
    createdAt: pack.created_at,
    isOwner,
    isPurchased: purchased,
    isCollected: isOwner || purchased || isCollected(viewerId, pack.id),
    needsWatermark,
    stickers: getStickers(pack.id).map((s) => ({ id: s.id, url: s.image_url })),
  };
}

// Создать стикер-пак (kind='pack', нужно ≥2 картинок) или одиночный стикер (kind='single', 1 картинка)
router.post('/', auth, (req, res) => {
  const { kind, name, isPrivate, isPaid, price, imageUrls, isAnimated } = req.body || {};
  if (!['pack', 'single'].includes(kind)) {
    return res.status(400).json({ error: 'kind должен быть "pack" или "single"' });
  }
  if (!name?.trim()) return res.status(400).json({ error: 'Укажи название' });
  if (!Array.isArray(imageUrls) || imageUrls.length === 0) {
    return res.status(400).json({ error: 'Загрузи хотя бы одну картинку' });
  }
  if (kind === 'pack' && imageUrls.length < 2) {
    return res.status(400).json({ error: 'В стикер-паке должно быть больше 1 стикера' });
  }
  if (isAnimated && !isProActive(req.user)) {
    return res.status(402).json({ error: 'Анимированные стикеры доступны только с подпиской Mythic Pro' });
  }
  const paid = !!isPaid;
  const finalPrice = paid ? Number(price) : 0;
  if (paid && (!finalPrice || finalPrice <= 0)) {
    return res.status(400).json({ error: 'Укажи цену для платного пака' });
  }

  const create = db.transaction(() => {
    const info = db
      .prepare(
        `INSERT INTO sticker_packs (owner_id, kind, name, is_private, is_paid, price, is_animated)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(req.user.id, kind, name.trim(), isPrivate ? 1 : 0, paid ? 1 : 0, finalPrice, isAnimated ? 1 : 0);

    const insertSticker = db.prepare('INSERT INTO stickers (pack_id, image_url) VALUES (?, ?)');
    imageUrls.forEach((url) => insertSticker.run(info.lastInsertRowid, url));

    return info.lastInsertRowid;
  });

  const id = create();
  const pack = db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(id);
  res.status(201).json(serialize(pack, req.user.id));
});

router.get('/mine', auth, (req, res) => {
  const rows = db.prepare('SELECT * FROM sticker_packs WHERE owner_id = ? ORDER BY created_at DESC').all(req.user.id);
  res.json({ packs: rows.map((p) => serialize(p, req.user.id)) });
});

// Всё, что доступно для использования: свои + добавленные в коллекцию + купленные
router.get('/collection', auth, (req, res) => {
  const rows = db
    .prepare(
      `SELECT DISTINCT sticker_packs.* FROM sticker_packs
       LEFT JOIN sticker_collection ON sticker_collection.pack_id = sticker_packs.id AND sticker_collection.user_id = ?
       LEFT JOIN sticker_purchases ON sticker_purchases.pack_id = sticker_packs.id AND sticker_purchases.user_id = ?
       WHERE sticker_packs.owner_id = ? OR sticker_collection.id IS NOT NULL OR sticker_purchases.id IS NOT NULL
       ORDER BY sticker_packs.created_at DESC`
    )
    .all(req.user.id, req.user.id, req.user.id);
  res.json({ packs: rows.map((p) => serialize(p, req.user.id)) });
});

// Поиск публичных паков (не приватных) — для добавления в коллекцию
router.get('/discover', auth, (req, res) => {
  const q = String(req.query.q || '').trim();
  const rows = q
    ? db.prepare('SELECT * FROM sticker_packs WHERE is_private = 0 AND name LIKE ? ORDER BY created_at DESC LIMIT 30').all(`%${q}%`)
    : db.prepare('SELECT * FROM sticker_packs WHERE is_private = 0 ORDER BY created_at DESC LIMIT 30').all();
  res.json({ packs: rows.map((p) => serialize(p, req.user.id)) });
});

router.get('/:id', auth, (req, res) => {
  const pack = db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(req.params.id);
  if (!pack) return res.status(404).json({ error: 'Не найдено' });
  if (pack.is_private && pack.owner_id !== req.user.id && !isPurchased(req.user.id, pack.id) && !isCollected(req.user.id, pack.id)) {
    return res.status(403).json({ error: 'Этот стикер-пак приватный' });
  }
  res.json(serialize(pack, req.user.id));
});

// Добавить бесплатный публичный пак в коллекцию
router.post('/:id/collect', auth, (req, res) => {
  const pack = db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(req.params.id);
  if (!pack) return res.status(404).json({ error: 'Не найдено' });
  if (pack.owner_id === req.user.id) return res.status(400).json({ error: 'Это твой собственный пак' });
  if (pack.is_private) return res.status(403).json({ error: 'Пак приватный — добавить нельзя' });
  if (pack.is_paid && !isPurchased(req.user.id, pack.id)) {
    return res.status(402).json({ error: 'Пак платный — сначала купи' });
  }

  db.prepare('INSERT OR IGNORE INTO sticker_collection (user_id, pack_id) VALUES (?, ?)').run(req.user.id, pack.id);
  res.json(serialize(pack, req.user.id));
});

router.delete('/:id/collect', auth, (req, res) => {
  db.prepare('DELETE FROM sticker_collection WHERE user_id = ? AND pack_id = ?').run(req.user.id, req.params.id);
  res.json({ ok: true });
});

// Купить платный пак — перевод мификов автору + запись покупки + автоматически в коллекцию
router.post('/:id/purchase', auth, (req, res) => {
  const pack = db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(req.params.id);
  if (!pack) return res.status(404).json({ error: 'Не найдено' });
  if (pack.owner_id === req.user.id) return res.status(400).json({ error: 'Это твой собственный пак' });
  if (!pack.is_paid) return res.status(400).json({ error: 'Этот пак бесплатный — просто добавь в коллекцию' });
  if (isPurchased(req.user.id, pack.id)) return res.status(409).json({ error: 'Уже куплено' });

  const buyer = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (buyer.wallet_balance < pack.price) {
    return res.status(400).json({ error: 'Недостаточно мификов на балансе' });
  }

  const owner = db.prepare('SELECT * FROM users WHERE id = ?').get(pack.owner_id);
  const txId = generateTxId();

  const runPurchase = db.transaction(() => {
    db.prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?').run(pack.price, buyer.id);
    db.prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?').run(pack.price, owner.id);
    db.prepare(
      'INSERT INTO wallet_transfers (tx_id, from_wallet, to_wallet, amount) VALUES (?, ?, ?, ?)'
    ).run(txId, buyer.wallet_id, owner.wallet_id, pack.price);
    db.prepare(
      'INSERT INTO sticker_purchases (user_id, pack_id, tx_id, amount) VALUES (?, ?, ?, ?)'
    ).run(buyer.id, pack.id, txId, pack.price);
  });
  runPurchase();

  res.json(serialize(pack, req.user.id));
});

// Настройки пака: название, приватность, платность/цена — только владелец
router.patch('/:id', auth, (req, res) => {
  const pack = db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(req.params.id);
  if (!pack) return res.status(404).json({ error: 'Не найдено' });
  if (pack.owner_id !== req.user.id) return res.status(403).json({ error: 'Менять настройки может только владелец' });

  const { name, isPrivate, isPaid, price } = req.body || {};
  const paid = typeof isPaid === 'boolean' ? isPaid : !!pack.is_paid;
  const finalPrice = paid ? Number(price ?? pack.price) : 0;
  if (paid && (!finalPrice || finalPrice <= 0)) {
    return res.status(400).json({ error: 'Укажи цену для платного пака' });
  }

  db.prepare(
    `UPDATE sticker_packs SET
       name = COALESCE(?, name),
       is_private = COALESCE(?, is_private),
       is_paid = ?,
       price = ?
     WHERE id = ?`
  ).run(
    name?.trim() || null,
    typeof isPrivate === 'boolean' ? (isPrivate ? 1 : 0) : null,
    paid ? 1 : 0,
    finalPrice,
    pack.id
  );

  const updated = db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(pack.id);
  res.json(serialize(updated, req.user.id));
});

router.delete('/:id/stickers/:stickerId', auth, (req, res) => {
  const pack = db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(req.params.id);
  if (!pack) return res.status(404).json({ error: 'Не найдено' });
  if (pack.owner_id !== req.user.id) return res.status(403).json({ error: 'Удалить может только владелец' });

  db.prepare('DELETE FROM stickers WHERE id = ? AND pack_id = ?').run(req.params.stickerId, pack.id);
  res.json(serialize(db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(pack.id), req.user.id));
});

router.delete('/:id', auth, (req, res) => {
  const pack = db.prepare('SELECT * FROM sticker_packs WHERE id = ?').get(req.params.id);
  if (!pack) return res.status(404).json({ error: 'Не найдено' });
  if (pack.owner_id !== req.user.id) return res.status(403).json({ error: 'Удалить может только владелец' });

  const del = db.transaction(() => {
    db.prepare('DELETE FROM stickers WHERE pack_id = ?').run(pack.id);
    db.prepare('DELETE FROM sticker_collection WHERE pack_id = ?').run(pack.id);
    db.prepare('DELETE FROM sticker_purchases WHERE pack_id = ?').run(pack.id);
    db.prepare('DELETE FROM sticker_packs WHERE id = ?').run(pack.id);
  });
  del();

  res.json({ ok: true });
});

module.exports = router;
