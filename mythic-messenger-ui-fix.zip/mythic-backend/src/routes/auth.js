const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { generateWalletId } = require('../utils/wallet');

const router = express.Router();

function publicUser(u) {
  return {
    id: u.id,
    login: u.login,
    username: u.username,
    age: u.age,
    walletId: u.wallet_id,
    walletBalance: u.wallet_balance,
    reputation: u.reputation,
    isAdmin: !!u.is_admin,
    hasCheckmark: !!u.has_checkmark,
    email: u.email,
    emailVerified: !!u.email_verified,
    pendingEmail: u.pending_email,
    avatarUrl: u.avatar_url,
    publicKey: u.public_key,
  };
}

function signToken(user) {
  return jwt.sign({ uid: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' });
}

router.post('/register', (req, res) => {
  const { login, username, password, age } = req.body || {};

  if (!login || !username || !password || !age) {
    return res.status(400).json({ error: 'Заполни логин, юзернейм, пароль и возраст' });
  }
  const ageNum = parseInt(age, 10);
  if (!ageNum || ageNum < 13 || ageNum > 120) {
    return res.status(400).json({ error: 'Некорректный возраст' });
  }
  if (String(password).length < 6) {
    return res.status(400).json({ error: 'Пароль должен быть от 6 символов' });
  }

  const existing = db
    .prepare('SELECT id FROM users WHERE login = ? OR username = ?')
    .get(login, username);
  if (existing) {
    return res.status(409).json({ error: 'Логин или юзернейм уже заняты' });
  }

  const hash = bcrypt.hashSync(password, 10);
  const walletId = generateWalletId();

  const info = db
    .prepare(
      `INSERT INTO users (login, username, password_hash, age, wallet_id)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(login, username, hash, ageNum, walletId);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  const token = signToken(user);
  res.status(201).json({ token, user: publicUser(user) });
});

router.post('/login', (req, res) => {
  const { login, password } = req.body || {};
  if (!login || !password) {
    return res.status(400).json({ error: 'Укажи логин и пароль' });
  }

  const user = db.prepare('SELECT * FROM users WHERE login = ?').get(login);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Неверный логин или пароль' });
  }
  if (user.is_banned) {
    return res.status(403).json({ error: 'Аккаунт заблокирован администрацией' });
  }

  const token = signToken(user);
  res.json({ token, user: publicUser(user) });
});

router.get('/me', require('../middleware/auth').auth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

module.exports = { router, publicUser };
