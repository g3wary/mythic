const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');

const router = express.Router();

function getMembership(communityId, userId) {
  return db
    .prepare('SELECT * FROM community_members WHERE community_id = ? AND user_id = ?')
    .get(communityId, userId);
}

function memberCount(communityId) {
  return db
    .prepare('SELECT COUNT(*) as c FROM community_members WHERE community_id = ?')
    .get(communityId).c;
}

function serialize(community, membership) {
  return {
    id: community.id,
    type: community.type,
    name: community.name,
    description: community.description,
    avatarUrl: community.avatar_url,
    writeEnabled: !!community.write_enabled,
    memberCount: memberCount(community.id),
    myRole: membership ? membership.role : null,
  };
}

// Создать группу/канал — создатель сразу становится владельцем
router.post('/', auth, (req, res) => {
  const { type, name, description } = req.body || {};
  if (!['group', 'channel'].includes(type)) {
    return res.status(400).json({ error: 'type должен быть "group" или "channel"' });
  }
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Укажи название' });
  }

  const create = db.transaction(() => {
    const info = db
      .prepare('INSERT INTO communities (type, name, description, owner_id) VALUES (?, ?, ?, ?)')
      .run(type, name.trim(), description || null, req.user.id);
    db.prepare(
      'INSERT INTO community_members (community_id, user_id, role) VALUES (?, ?, ?)'
    ).run(info.lastInsertRowid, req.user.id, 'owner');
    return info.lastInsertRowid;
  });

  const id = create();
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(id);
  res.status(201).json(serialize(community, { role: 'owner' }));
});

// Мои группы/каналы (где я состою)
router.get('/mine', auth, (req, res) => {
  const rows = db
    .prepare(
      `SELECT communities.*, community_members.role as my_role
       FROM community_members
       JOIN communities ON communities.id = community_members.community_id
       WHERE community_members.user_id = ?
       ORDER BY communities.created_at DESC`
    )
    .all(req.user.id);

  res.json({
    communities: rows.map((c) => serialize(c, { role: c.my_role })),
  });
});

// Поиск публичных групп/каналов по названию
router.get('/search', auth, (req, res) => {
  const q = String(req.query.q || '').trim();
  const type = req.query.type;
  if (!q) return res.json({ communities: [] });

  const rows = db
    .prepare(
      `SELECT * FROM communities WHERE name LIKE ? ${type ? 'AND type = ?' : ''} LIMIT 30`
    )
    .all(...(type ? [`%${q}%`, type] : [`%${q}%`]));

  res.json({
    communities: rows.map((c) => serialize(c, getMembership(c.id, req.user.id))),
  });
});

router.get('/:id', auth, (req, res) => {
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(req.params.id);
  if (!community) return res.status(404).json({ error: 'Не найдено' });
  res.json(serialize(community, getMembership(community.id, req.user.id)));
});

// Вступить в группу / подписаться на канал
router.post('/:id/join', auth, (req, res) => {
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(req.params.id);
  if (!community) return res.status(404).json({ error: 'Не найдено' });

  const existing = getMembership(community.id, req.user.id);
  if (existing) return res.status(409).json({ error: 'Ты уже состоишь' });

  db.prepare(
    'INSERT INTO community_members (community_id, user_id, role) VALUES (?, ?, ?)'
  ).run(community.id, req.user.id, 'member');

  res.json(serialize(community, { role: 'member' }));
});

// Выйти из группы / отписаться от канала
router.post('/:id/leave', auth, (req, res) => {
  const membership = getMembership(req.params.id, req.user.id);
  if (!membership) return res.status(404).json({ error: 'Ты не состоишь в этой группе/канале' });
  if (membership.role === 'owner') {
    return res.status(400).json({ error: 'Владелец не может выйти — удали группу/канал или передай владение' });
  }

  db.prepare('DELETE FROM community_members WHERE id = ?').run(membership.id);
  res.json({ ok: true });
});

// Удалить группу/канал целиком — только владелец
router.delete('/:id', auth, (req, res) => {
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(req.params.id);
  if (!community) return res.status(404).json({ error: 'Не найдено' });
  if (community.owner_id !== req.user.id) {
    return res.status(403).json({ error: 'Удалить может только владелец' });
  }

  const del = db.transaction(() => {
    db.prepare('DELETE FROM community_messages WHERE community_id = ?').run(community.id);
    db.prepare('DELETE FROM community_members WHERE community_id = ?').run(community.id);
    db.prepare('DELETE FROM communities WHERE id = ?').run(community.id);
  });
  del();

  res.json({ ok: true });
});

// Настройки — переименование, описание, для групп — вкл/выкл запись всем участникам
router.patch('/:id', auth, (req, res) => {
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(req.params.id);
  if (!community) return res.status(404).json({ error: 'Не найдено' });
  if (community.owner_id !== req.user.id) {
    return res.status(403).json({ error: 'Менять настройки может только владелец' });
  }

  const { name, description, writeEnabled } = req.body || {};
  db.prepare(
    `UPDATE communities SET
       name = COALESCE(?, name),
       description = COALESCE(?, description),
       write_enabled = COALESCE(?, write_enabled)
     WHERE id = ?`
  ).run(
    name?.trim() || null,
    description ?? null,
    typeof writeEnabled === 'boolean' ? (writeEnabled ? 1 : 0) : null,
    community.id
  );

  const updated = db.prepare('SELECT * FROM communities WHERE id = ?').get(community.id);
  res.json(serialize(updated, { role: 'owner' }));
});

// Назначить совладельца канала — только владелец, совладелец не может назначать других
router.post('/:id/co-owners', auth, (req, res) => {
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(req.params.id);
  if (!community) return res.status(404).json({ error: 'Не найдено' });
  if (community.type !== 'channel') {
    return res.status(400).json({ error: 'Совладельцы есть только у каналов' });
  }
  if (community.owner_id !== req.user.id) {
    return res.status(403).json({ error: 'Назначать совладельцев может только владелец' });
  }

  const { login } = req.body || {};
  const target = db.prepare('SELECT * FROM users WHERE login = ?').get(login);
  if (!target) return res.status(404).json({ error: 'Пользователь не найден' });

  let membership = getMembership(community.id, target.id);
  if (!membership) {
    db.prepare(
      'INSERT INTO community_members (community_id, user_id, role) VALUES (?, ?, ?)'
    ).run(community.id, target.id, 'co_owner');
  } else if (membership.role === 'owner') {
    return res.status(400).json({ error: 'Владелец не может стать совладельцем' });
  } else {
    db.prepare('UPDATE community_members SET role = ? WHERE id = ?').run('co_owner', membership.id);
  }

  res.json({ ok: true });
});

router.delete('/:id/co-owners/:login', auth, (req, res) => {
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(req.params.id);
  if (!community) return res.status(404).json({ error: 'Не найдено' });
  if (community.owner_id !== req.user.id) {
    return res.status(403).json({ error: 'Снимать совладельцев может только владелец' });
  }

  const target = db.prepare('SELECT * FROM users WHERE login = ?').get(req.params.login);
  if (!target) return res.status(404).json({ error: 'Пользователь не найден' });

  db.prepare(
    `UPDATE community_members SET role = 'member' WHERE community_id = ? AND user_id = ? AND role = 'co_owner'`
  ).run(community.id, target.id);

  res.json({ ok: true });
});

// Список участников (для экрана настроек/участников)
router.get('/:id/members', auth, (req, res) => {
  const rows = db
    .prepare(
      `SELECT users.login, users.username, community_members.role FROM community_members
       JOIN users ON users.id = community_members.user_id
       WHERE community_members.community_id = ?
       ORDER BY CASE community_members.role WHEN 'owner' THEN 0 WHEN 'co_owner' THEN 1 ELSE 2 END, users.username`
    )
    .all(req.params.id);
  res.json({ members: rows });
});

// История сообщений — доступна любому участнику/подписчику
router.get('/:id/messages', auth, (req, res) => {
  const membership = getMembership(req.params.id, req.user.id);
  if (!membership) return res.status(403).json({ error: 'Нужно вступить в группу или подписаться на канал' });

  const rows = db
    .prepare(
      `SELECT community_messages.*, users.login as from_login, users.username as from_username
       FROM community_messages
       JOIN users ON users.id = community_messages.from_id
       WHERE community_messages.community_id = ? AND community_messages.deleted = 0
       ORDER BY community_messages.created_at ASC LIMIT 300`
    )
    .all(req.params.id);

  res.json({ messages: rows });
});

function canPost(community, membership) {
  if (!membership) return false;
  if (community.type === 'channel') return membership.role === 'owner' || membership.role === 'co_owner';
  // группа: владелец всегда может, участник — если запись не отключена
  return membership.role === 'owner' || !!community.write_enabled;
}

router.post('/:id/messages', auth, (req, res) => {
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(req.params.id);
  if (!community) return res.status(404).json({ error: 'Не найдено' });
  const membership = getMembership(community.id, req.user.id);

  if (!canPost(community, membership)) {
    return res.status(403).json({
      error:
        community.type === 'channel'
          ? 'Постить в канал могут только владелец и совладельцы'
          : 'Владелец группы отключил сообщения для участников',
    });
  }

  const { content, type } = req.body || {};
  if (!content) return res.status(400).json({ error: 'Пустое сообщение' });

  const info = db
    .prepare(
      'INSERT INTO community_messages (community_id, from_id, type, content) VALUES (?, ?, ?, ?)'
    )
    .run(community.id, req.user.id, type || 'text', content);

  const msg = db.prepare('SELECT * FROM community_messages WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ message: { ...msg, from_login: req.user.login, from_username: req.user.username } });
});

router.delete('/:id/messages/:msgId', auth, (req, res) => {
  const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(req.params.id);
  if (!community) return res.status(404).json({ error: 'Не найдено' });
  const msg = db.prepare('SELECT * FROM community_messages WHERE id = ?').get(req.params.msgId);
  if (!msg) return res.status(404).json({ error: 'Сообщение не найдено' });

  const isAuthor = msg.from_id === req.user.id;
  const isOwner = community.owner_id === req.user.id;
  if (!isAuthor && !isOwner) {
    return res.status(403).json({ error: 'Удалить может только автор или владелец' });
  }

  db.prepare('UPDATE community_messages SET deleted = 1 WHERE id = ?').run(msg.id);
  res.json({ ok: true });
});

module.exports = router;
module.exports.getMembership = getMembership;
module.exports.canPost = canPost;
