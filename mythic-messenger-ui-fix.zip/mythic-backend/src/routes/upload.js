const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { auth } = require('../middleware/auth');

const router = express.Router();

const UPLOAD_ROOT = path.resolve(process.env.UPLOAD_DIR || './uploads');
const MAX_FILE_MB = Number(process.env.MAX_UPLOAD_MB || 50);

function kindFromMime(mime) {
  if (!mime) return 'file';
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('video/')) return 'video';
  if (mime.startsWith('audio/')) return 'audio';
  return 'file';
}

// Раскладываем по подпапкам image/video/audio/file, чтобы не искать иголку в стоге сена
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const kind = kindFromMime(file.mimetype);
    const dir = path.join(UPLOAD_ROOT, kind);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '';
    const safeName = crypto.randomBytes(16).toString('hex') + ext;
    cb(null, safeName);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_MB * 1024 * 1024 },
});

router.post('/', auth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Файл не получен' });

  const kind = kindFromMime(req.file.mimetype);
  const publicPath = `/uploads/${kind}/${req.file.filename}`;

  res.status(201).json({
    url: publicPath,
    kind,
    name: req.file.originalname,
    size: req.file.size,
    mimeType: req.file.mimetype,
  });
});

// Ловим ошибки multer (например, превышен размер файла) отдельным обработчиком
router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ error: `Файл больше ${MAX_FILE_MB} МБ` });
    }
    return res.status(400).json({ error: err.message });
  }
  next(err);
});

module.exports = { router, UPLOAD_ROOT };
