const express = require('express');
const db = require('../db');

const router = express.Router();

// Отдельная аутентификация для ботов: заголовок Authorization: Bot <токен>
// (не путать с Bearer <JWT> обычных пользователей — это разные механизмы)
function botAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bot ') ? header.slice(4) : null;
  if (!token) return res.status(401).json({ error: 'Нужен заголовок Authorization: Bot <токен>' });

  const bot = db.prepare('SELECT * FROM users WHERE bot_token = ? AND is_bot = 1').get(token);
  if (!bot) return res.status(401).json({ error: 'Неверный токен бота' });
  if (bot.is_banned) return res.status(403).json({ error: 'Бот заблокирован администрацией' });

  req.bot = bot;
  next();
}

router.use(botAuth);

router.get('/me', (req, res) => {
  res.json({
    login: req.bot.login,
    username: req.bot.username,
    description: req.bot.bot_description,
    walletId: req.bot.wallet_id,
    walletBalance: req.bot.wallet_balance,
  });
});

// Отправить сообщение пользователю от имени бота
router.post('/messages', (req, res) => {
  const { toLogin, content, type } = req.body || {};
  if (!toLogin || !content) return res.status(400).json({ error: 'Укажи toLogin и content' });

  const recipient = db.prepare('SELECT * FROM users WHERE login = ?').get(toLogin);
  if (!recipient) return res.status(404).json({ error: 'Пользователь не найден' });

  const blocked = db
    .prepare(
      'SELECT id FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)'
    )
    .get(req.bot.id, recipient.id, recipient.id, req.bot.id);
  if (blocked) return res.status(403).json({ error: 'Пользователь заблокировал этого бота (или наоборот)' });

  const info = db
    .prepare('INSERT INTO messages (from_id, to_id, type, content) VALUES (?, ?, ?, ?)')
    .run(req.bot.id, recipient.id, type || 'text', content);

  const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ message: msg });
});

// История переписки с конкретным пользователем — чтобы бот видел, на что отвечать
router.get('/messages/:withLogin', (req, res) => {
  const other = db.prepare('SELECT * FROM users WHERE login = ?').get(req.params.withLogin);
  if (!other) return res.status(404).json({ error: 'Пользователь не найден' });

  const rows = db
    .prepare(
      `SELECT * FROM messages
       WHERE deleted = 0 AND ((from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?))
       ORDER BY created_at ASC LIMIT 200`
    )
    .all(req.bot.id, other.id, other.id, req.bot.id);

  res.json({ messages: rows });
});

module.exports = router;
