const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');

const router = express.Router();

function isBlocked(aId, bId) {
  return !!db
    .prepare(
      'SELECT id FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)'
    )
    .get(aId, bId, bId, aId);
}

// Список диалогов текущего пользователя: последний обмен с каждым собеседником
router.get('/', auth, (req, res) => {
  const rows = db
    .prepare(
      `SELECT m.*,
              CASE WHEN m.from_id = ? THEN m.to_id ELSE m.from_id END as other_id
       FROM messages m
       WHERE m.deleted = 0 AND (m.from_id = ? OR m.to_id = ?)
       ORDER BY m.created_at DESC`
    )
    .all(req.user.id, req.user.id, req.user.id);

  const seen = new Map();
  for (const row of rows) {
    if (!seen.has(row.other_id)) seen.set(row.other_id, row);
  }

  const conversations = [...seen.values()].map((row) => {
    const other = db.prepare('SELECT login, username, avatar_url FROM users WHERE id = ?').get(row.other_id);
    return {
      login: other?.login,
      username: other?.username,
      avatarUrl: other?.avatar_url,
      lastMessage: row.content,
      lastMessageType: row.type,
      lastMessageAt: row.created_at,
      lastMessageMine: row.from_id === req.user.id,
    };
  });

  res.json({ conversations });
});

router.get('/:withLogin', auth, (req, res) => {
  const other = db.prepare('SELECT * FROM users WHERE login = ?').get(req.params.withLogin);
  if (!other) return res.status(404).json({ error: 'Пользователь не найден' });

  const rows = db
    .prepare(
      `SELECT * FROM messages
       WHERE deleted = 0 AND ((from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?))
       ORDER BY created_at ASC LIMIT 200`
    )
    .all(req.user.id, other.id, other.id, req.user.id);

  res.json({ messages: rows });
});

// REST fallback отправки (основной путь — WebSocket, см. src/ws/index.js)
router.post('/:toLogin', auth, (req, res) => {
  const { content, type } = req.body || {};
  if (!content) return res.status(400).json({ error: 'Пустое сообщение' });

  const recipient = db.prepare('SELECT * FROM users WHERE login = ?').get(req.params.toLogin);
  if (!recipient) return res.status(404).json({ error: 'Пользователь не найден' });
  if (recipient.id === req.user.id) return res.status(400).json({ error: 'Нельзя написать самому себе' });
  if (isBlocked(req.user.id, recipient.id)) {
    return res.status(403).json({ error: 'Переписка недоступна: пользователь заблокирован' });
  }

  const info = db
    .prepare('INSERT INTO messages (from_id, to_id, type, content) VALUES (?, ?, ?, ?)')
    .run(req.user.id, recipient.id, type || 'text', content);

  const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ message: msg });
});

router.patch('/:id', auth, (req, res) => {
  const { content } = req.body || {};
  if (!content) return res.status(400).json({ error: 'Пустое сообщение' });

  const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(req.params.id);
  if (!msg) return res.status(404).json({ error: 'Сообщение не найдено' });
  if (msg.from_id !== req.user.id) return res.status(403).json({ error: 'Можно редактировать только свои сообщения' });

  db.prepare('UPDATE messages SET content = ?, edited = 1 WHERE id = ?').run(content, msg.id);
  res.json({ ok: true });
});

router.delete('/:id', auth, (req, res) => {
  const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(req.params.id);
  if (!msg) return res.status(404).json({ error: 'Сообщение не найдено' });
  if (msg.from_id !== req.user.id) return res.status(403).json({ error: 'Можно удалять только свои сообщения' });

  db.prepare('UPDATE messages SET deleted = 1 WHERE id = ?').run(msg.id);
  res.json({ ok: true });
});

module.exports = router;
module.exports.isBlocked = isBlocked;
