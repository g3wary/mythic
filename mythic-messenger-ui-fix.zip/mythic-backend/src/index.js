require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');

const { router: authRouter } = require('./routes/auth');
const walletRouter = require('./routes/wallet');
const reportsRouter = require('./routes/reports');
const adminRouter = require('./routes/admin');
const supportRouter = require('./routes/support');
const messagesRouter = require('./routes/messages');
const usersRouter = require('./routes/users');
const communitiesRouter = require('./routes/communities');
const postsRouter = require('./routes/posts');
const { router: accountRouter } = require('./routes/account');
const botsRouter = require('./routes/bots');
const botApiRouter = require('./routes/bot-api');
const stickersRouter = require('./routes/stickers');
const { router: proRouter } = require('./routes/pro');
const { router: uploadRouter, UPLOAD_ROOT } = require('./routes/upload');
const { attachWebSocket } = require('./ws');

if (!process.env.JWT_SECRET) {
  console.warn('[warn] JWT_SECRET не задан в .env — используй .env.example как шаблон!');
}

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

app.get('/health', (req, res) => res.json({ ok: true, service: 'mythic-backend' }));

app.use('/auth', authRouter);
app.use('/wallet', walletRouter);
app.use('/reports', reportsRouter);
app.use('/admin', adminRouter);
app.use('/support', supportRouter);
app.use('/messages', messagesRouter);
app.use('/users', usersRouter);
app.use('/communities', communitiesRouter);
app.use('/posts', postsRouter);
app.use('/account', accountRouter);
app.use('/bots', botsRouter);
app.use('/bot-api', botApiRouter);
app.use('/sticker-packs', stickersRouter);
app.use('/pro', proRouter);
app.use('/upload', uploadRouter);
app.use('/uploads', express.static(UPLOAD_ROOT));

app.use((req, res) => res.status(404).json({ error: 'Роут не найден' }));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});

const server = http.createServer(app);
attachWebSocket(server);

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`Mythic backend запущен на порту ${PORT}`);
  console.log(`WebSocket доступен на ws://<host>:${PORT}/ws?token=<JWT>`);
});
