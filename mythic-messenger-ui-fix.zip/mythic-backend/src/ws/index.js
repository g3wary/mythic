const { WebSocketServer } = require('ws');
const jwt = require('jsonwebtoken');
const url = require('url');
const db = require('../db');
const { isBlocked } = require('../routes/messages');
const { getMembership, canPost } = require('../routes/communities');

// userId -> Set<ws>
const connections = new Map();

function attachWebSocket(server) {
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    const { query } = url.parse(req.url, true);
    let userId;

    try {
      const payload = jwt.verify(query.token, process.env.JWT_SECRET);
      userId = payload.uid;
    } catch (e) {
      ws.close(4001, 'invalid_token');
      return;
    }

    if (!connections.has(userId)) connections.set(userId, new Set());
    connections.get(userId).add(ws);

    ws.on('close', () => {
      connections.get(userId)?.delete(ws);
    });

    ws.on('message', (raw) => {
      let data;
      try {
        data = JSON.parse(raw);
      } catch {
        return;
      }

      if (data.type === 'community') {
        const { communityId, content, msgType } = data;
        const community = db.prepare('SELECT * FROM communities WHERE id = ?').get(communityId);
        if (!community) return;
        const membership = getMembership(communityId, userId);

        if (!canPost(community, membership)) {
          ws.readyState === 1 &&
            ws.send(
              JSON.stringify({
                type: 'error',
                error:
                  community.type === 'channel'
                    ? 'Постить в канал могут только владелец и совладельцы'
                    : 'Владелец группы отключил сообщения для участников',
              })
            );
          return;
        }

        const info = db
          .prepare(
            'INSERT INTO community_messages (community_id, from_id, type, content) VALUES (?, ?, ?, ?)'
          )
          .run(communityId, userId, msgType || 'text', content);

        const sender = db.prepare('SELECT login, username FROM users WHERE id = ?').get(userId);
        const payload = JSON.stringify({
          type: 'community',
          id: info.lastInsertRowid,
          communityId,
          fromLogin: sender.login,
          fromUsername: sender.username,
          content,
          msgType: msgType || 'text',
          createdAt: new Date().toISOString(),
        });

        // рассылаем всем участникам/подписчикам, кто сейчас онлайн
        const memberIds = db
          .prepare('SELECT user_id FROM community_members WHERE community_id = ?')
          .all(communityId)
          .map((r) => r.user_id);

        memberIds.forEach((uid) => {
          connections.get(uid)?.forEach((sock) => sock.readyState === 1 && sock.send(payload));
        });
        return;
      }

      if (data.type !== 'dm') return;

      const { toLogin, content, msgType } = data;
      const recipient = db.prepare('SELECT * FROM users WHERE login = ?').get(toLogin);
      if (!recipient) return;
      if (isBlocked(userId, recipient.id)) {
        ws.readyState === 1 &&
          ws.send(JSON.stringify({ type: 'error', error: 'Переписка недоступна: пользователь заблокирован' }));
        return;
      }

      const info = db
        .prepare(
          'INSERT INTO messages (from_id, to_id, type, content) VALUES (?, ?, ?, ?)'
        )
        .run(userId, recipient.id, msgType || 'text', content);

      const sender = db.prepare('SELECT login, username FROM users WHERE id = ?').get(userId);

      const payload = JSON.stringify({
        type: 'dm',
        id: info.lastInsertRowid,
        fromLogin: sender.login,
        fromUsername: sender.username,
        toLogin: recipient.login,
        content,
        msgType: msgType || 'text',
        createdAt: new Date().toISOString(),
      });

      // доставляем получателю всем его активным соединениям
      connections.get(recipient.id)?.forEach((sock) => sock.readyState === 1 && sock.send(payload));
      // эхо отправителю (для синхронизации между устройствами)
      connections.get(userId)?.forEach((sock) => sock.readyState === 1 && sock.send(payload));
    });
  });

  return wss;
}

module.exports = { attachWebSocket };
