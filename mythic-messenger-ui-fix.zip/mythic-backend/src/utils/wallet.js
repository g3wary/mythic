function randomSegment(len) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let out = '';
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

// Формат: MYT-XXXXX-XXXXX
function generateWalletId() {
  return `MYT-${randomSegment(5)}-${randomSegment(5)}`;
}

// Формат: TX-XXXXXXXXXX
function generateTxId() {
  return `TX-${randomSegment(10)}`;
}

// Токен бота — длинный и с явным префиксом, чтобы сразу было видно, что это за строка
function generateBotToken() {
  return `mythic_bot_${randomSegment(24)}`;
}

module.exports = { generateWalletId, generateTxId, generateBotToken };
