const jwt = require('jsonwebtoken');
const db = require('../db');

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Нет токена авторизации' });

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.uid);
    if (!user) return res.status(401).json({ error: 'Пользователь не найден' });
    if (user.is_banned) return res.status(403).json({ error: 'Аккаунт заблокирован' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Невалидный или истёкший токен' });
  }
}

function requireAdmin(req, res, next) {
  if (!req.user?.is_admin) return res.status(403).json({ error: 'Требуются права администратора' });
  next();
}

module.exports = { auth, requireAdmin };
