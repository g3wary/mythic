# Mythic Backend

Node.js + Express + SQLite (better-sqlite3) + WebSocket. Все настройки — через `.env`, в коде ничего менять не нужно.

## Запуск на VPS (или любой другой нейросетью/агентом)

```bash
cd mythic-backend
cp .env.example .env
# при желании поменяй PORT, JWT_SECRET, ADMIN_LOGIN, ADMIN_PASSWORD в .env
npm install
npm start
```

Сервер поднимется на порту из `.env` (по умолчанию 4000) и создаст файл `mythic.db` рядом с проектом при первом запуске. Первый администратор создаётся автоматически из `.env` (по умолчанию логин `Admin`, пароль `Admin123`).

Чтобы держать процесс живым после закрытия SSH-сессии — `pm2`:
```bash
npm install -g pm2
pm2 start src/index.js --name mythic-backend
pm2 save
```

## Как подключить к мобильному приложению
В `mythic-messenger/src/api.js` пропиши адрес сервера:
```js
export const API_BASE_URL = 'https://твой-домен-или-ip:4000';
export const WS_BASE_URL = 'wss://твой-домен-или-ip:4000';
```
Если сервер без HTTPS (голый IP:порт) — используй `http://` и `ws://`.

## Эндпоинты

| Метод | Путь | Что делает |
|---|---|---|
| POST | /auth/register | Регистрация (login, username, password, age) |
| POST | /auth/login | Вход (login, password) |
| GET | /auth/me | Текущий пользователь (нужен Bearer-токен) |
| GET | /wallet/me | Баланс и ID кошелька |
| POST | /wallet/transfer | Перевод мификов { toWalletId, amount } |
| GET | /wallet/transfers | История переводов |
| POST | /reports | Пожаловаться на пользователя { targetLogin, reason } |
| GET | /users/search?q= | Поиск пользователей по логину/юзернейму |
| GET | /users/:login | Публичный профиль (репутация, галочка, блокировка ли уже) |
| POST | /users/:login/block | Заблокировать пользователя |
| DELETE | /users/:login/block | Разблокировать |
| GET | /messages | Список диалогов текущего пользователя (последнее сообщение с каждым) |
| GET | /messages/:withLogin | История переписки с пользователем |
| POST | /messages/:withLogin | Отправить сообщение (REST-запасной путь, основной — WS) |
| PATCH | /messages/:id | Редактировать своё сообщение |
| DELETE | /messages/:id | Удалить своё сообщение |
| POST | /communities | Создать группу/канал { type: 'group'\|'channel', name, description } |
| GET | /communities/mine | Мои группы и каналы |
| GET | /communities/search?q=&type= | Поиск публичных групп/каналов |
| GET | /communities/:id | Инфо о группе/канале + моя роль |
| POST | /communities/:id/join | Вступить в группу / подписаться на канал |
| POST | /communities/:id/leave | Выйти / отписаться (владелец не может) |
| DELETE | /communities/:id | Удалить группу/канал (владелец) |
| PATCH | /communities/:id | Настройки: name, description, writeEnabled (владелец) |
| POST | /communities/:id/co-owners | Назначить совладельца канала { login } (владелец) |
| DELETE | /communities/:id/co-owners/:login | Снять совладельца (владелец) |
| GET | /communities/:id/members | Список участников/подписчиков |
| GET | /communities/:id/messages | История сообщений группы/канала |
| POST | /communities/:id/messages | Отправить сообщение (REST-запасной путь) |
| DELETE | /communities/:id/messages/:msgId | Удалить сообщение (автор или владелец) |
| POST | /upload | Загрузить файл (multipart/form-data, поле `file`) — вернёт `{ url, kind, name, size, mimeType }` |
| GET | /uploads/... | Раздача загруженных файлов (статика) |
| POST | /posts | Создать пост { content, attachmentUrl, attachmentType, attachmentName, attachmentSize } — хештеги (#слово) вытаскиваются из content автоматически |
| GET | /posts?hashtag=&author=&before= | Лента (без скрытых), фильтр по хештегу/автору, пагинация по `before=<id>` |
| GET | /posts/mine | Мои посты, включая скрытые |
| GET | /posts/:id | Один пост |
| PATCH | /posts/:id | Скрыть/показать свой пост { hidden: true\|false } |
| DELETE | /posts/:id | Удалить свой пост |
| PATCH | /account/profile | Логин/юзернейм/пароль (со старым паролем)/аватар |
| POST | /account/email/request | Заявка на привязку почты { email } — падает админу тикетом |
| POST | /account/email/confirm | Подтвердить почту кодом { code } |
| POST | /account/public-key | Сохранить публичный ключ E2E-шифрования { publicKey } |
| POST | /bots | Создать бота { name, description, username } → вернёт токен |
| GET | /bots/mine | Мои боты |
| PATCH | /bots/:id | Сменить юзернейм/ник/описание/аватар бота { username, nickname, description, avatarUrl } |
| POST | /bots/:id/regenerate-token | Перевыпустить токен (старый перестаёт работать) |
| DELETE | /bots/:id | Удалить бота вместе с перепиской и постами |

## Bot API (для кода самого бота, не для приложения)
Отдельный мини-API с собственной авторизацией — заголовок `Authorization: Bot <токен>` (токен из бот-студии), не путать с `Bearer <JWT>` обычных пользователей.

| Метод | Путь | Что делает |
|---|---|---|
| GET | /bot-api/me | Инфо о самом боте |
| POST | /bot-api/messages | Отправить сообщение пользователю от имени бота { toLogin, content, type } |
| GET | /bot-api/messages/:withLogin | История переписки с конкретным пользователем (чтобы бот видел, на что отвечать) |

## Sticker Studio

| Метод | Путь | Что делает |
|---|---|---|
| POST | /sticker-packs | Создать пак/стикер { kind: 'pack'\|'single', name, isPrivate, isPaid, price, imageUrls } — imageUrls берутся из `/upload` |
| GET | /sticker-packs/mine | Мои паки |
| GET | /sticker-packs/collection | Всё доступное к использованию: свои + добавленные + купленные |
| GET | /sticker-packs/discover?q= | Поиск публичных (не приватных) паков |
| GET | /sticker-packs/:id | Один пак (403, если приватный и не твой/не куплен) |
| POST | /sticker-packs/:id/collect | Добавить бесплатный публичный пак в коллекцию |
| DELETE | /sticker-packs/:id/collect | Убрать из коллекции |
| POST | /sticker-packs/:id/purchase | Купить платный пак — перевод мификов автору через кошелёк, атомарная транзакция |
| PATCH | /sticker-packs/:id | Название/приватность/платность/цена (владелец) |
| DELETE | /sticker-packs/:id/stickers/:stickerId | Удалить один стикер из пака (владелец) |
| DELETE | /sticker-packs/:id | Удалить пак целиком (владелец) |

Логика водяного знака и приватности — целиком на сервере: поле `needsWatermark` в ответе `true`, если пак платный и текущий пользователь его ещё не купил и не владелец — водяной знак рисует клиент по этому флагу, а не хранится в самой картинке (снялся автоматически после покупки, без переливки файла). Приватный пак недоступен чужим ни через `/discover`, ни при прямом запросе по id (кроме владельца и тех, кто уже успел добавить/купить).

## Mythic Pro

| Метод | Путь | Что делает |
|---|---|---|
| GET | /pro/status | { isPro, expiresAt, price, durationDays } |
| POST | /pro/subscribe | Списывает `PRO_PRICE_MIFIKS` (по умолчанию 500) с кошелька, продлевает на `PRO_DURATION_DAYS` (по умолчанию 30) дней. Если подписка уже активна — продление идёт от даты её окончания, а не от сегодня, так что купить впрок не в убыток |

Разблокирует:
- **Анимированные стикеры** — `POST /sticker-packs` с `isAnimated: true` возвращает 402, если `isProActive(user)` ложно
- **Постинг в ленту от чужого имени** — `POST /posts` с `asKind: 'bot'|'community'`, `asId: <id>`. Без Pro — 402. С Pro всё равно дополнительно проверяется владение: для бота — `bot_owner_id === req.user.id`, для группы/канала — роль `owner` или `co_owner` в `community_members`. Настоящий автор (`posts.author_id`) всегда остаётся реальным человеком — это только отображаемое лицо (`author_kind`/`author_ref_id`), поэтому модерация и статистика «моих постов» продолжают работать без дублирования логики

Администратор может выдать/снять Pro вручную командой `/pro <login> on|off [дней]` в консоли — например для тестирования без реальной траты мификов.

Технически бот — это обычная строка в таблице `users` с флагом `is_bot = 1`: он появляется в поиске пользователей, у него есть профиль, ему можно написать в личку — вся существующая инфраструктура сообщений переиспользуется без дублирования кода. Пароль у бота случайный и нерабочий (залогиниться им через `/auth/login` нельзя), это чисто внутренний артефакт схемы.

## E2E-шифрование личных сообщений
Реализовано на `tweetnacl` (X25519 + XSalsa20-Poly1305, стандартный NaCl `box` — не самописная криптография). Сервер хранит только публичные ключи (`users.public_key`) и видит лишь шифротекст в `content` личных сообщений; расшифровать их не может. Групповые чаты и каналы шифрованием не покрыты (как в большинстве мессенджеров — Telegram-группы тоже не E2E, только secret chats). Вложения (фото/файлы) пока не шифруются — сами байты лежат на сервере как есть, шифруется только текст переписки.

## Загрузка файлов
Файлы кладутся на диск сервера в `UPLOAD_DIR` (по умолчанию `./uploads`), разложены по подпапкам `image/`, `video/`, `audio/`, `file/` — по MIME-типу. Лимит размера — `MAX_UPLOAD_MB` в `.env` (по умолчанию 50 МБ). Отдаются напрямую через `/uploads/...` как статика.

Для продакшена с нагрузкой стоит перенести на S3-совместимое хранилище (в код это добавляется заменой `multer.diskStorage` на `multer-s3` в `src/routes/upload.js`, остальной API не меняется).
| POST | /support | Обращение в техподдержку { subject, message } |
| GET | /support/mine | Мои обращения |
| POST | /admin/console | Команда админ-консоли { command } — только is_admin |
| GET | /admin/logs | Логи команд администраторов |
| GET | /admin/support-tickets | Все обращения в техподдержку (админ) |
| WS | /ws?token=JWT | Реалтайм личные сообщения |

### Формат WS-сообщения для отправки
```json
{ "type": "dm", "toLogin": "username_получателя", "content": "текст", "msgType": "text" }
```
Сервер рассылает обратно объект с `type: "dm"`, `fromLogin`, `toLogin`, `content`, `msgType`, `createdAt` — и отправителю (эхо для синхронизации между устройствами), и получателю.

Для групп/каналов — то же самое, но `type: "community"`:
```json
{ "type": "community", "communityId": 5, "content": "текст", "msgType": "text" }
```
Право постить проверяется на сервере: в канале — только владелец/совладелец, в группе — владелец всегда, участник — если `writeEnabled` включён.

## Команды админ-консоли (уже реализованы)
```
/give <login|wallet> <amount>
/ban <login>
/unban <login>
/repup <login> <amount>
/repdown <login> <amount>
/verify <login>
/checkmark <login> on|off
/emailcode <login> <код>
/pro <login> on|off [дней]
```
Флоу привязки почты: пользователь отправляет заявку из настроек → тебе в `/admin/support-tickets` падает тикет с адресом → ты вручную отправляешь код с любой своей почты на указанный адрес → вводишь `/emailcode <login> <код>` → пользователь вводит этот код в приложении → почта подтверждена.

Новые команды добавляются в `src/routes/admin.js` в `switch(cmd)` — структура одинаковая для всех.

## Что ещё не реализовано (следующие этапы)
- E2E-шифрование содержимого сообщений (сейчас content хранится как есть — для продакшена нужно шифровать на клиенте перед отправкой и расшифровывать после получения, сервер должен видеть только шифротекст)
- Группы/каналы, лента с хештегами, бот-студио, sticker studio, загрузка файлов/медиа (нужно объектное хранилище, например S3-совместимое)
- Подтверждение почты (сейчас есть только `email_verified` флаг и команда `/verify`, самого флоу отправки кода с почты админа ещё нет)
- Блокировки (`/users/:login/block`) уже работают на уровне сообщений (заблокированные не могут писать друг другу ни через WS, ни через REST), но список заблокированных пока не выводится отдельным экраном
